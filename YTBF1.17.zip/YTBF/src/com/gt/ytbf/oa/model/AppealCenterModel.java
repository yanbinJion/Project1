package com.gt.ytbf.oa.model;

import java.io.Serializable;

import com.gt.ytbf.oa.tools.BeanUtils;

/**
 * Created by root on 16-6-20.
 */
public class AppealCenterModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5535061125776240068L;
	private String appealId;
	private String title;
    private String companyName;
    private String area;
    private String appealType;
    private String appealContent;
    private String appealState;
    private String appealTime;
    private String bizId;
    private String timeLimit;
    private String tzt;

    public AppealCenterModel() {

    }

    public AppealCenterModel(String appealId,String title,String companyName, String area,
			String appealType, String appealContent, String appealState,
			String appealTime,String bizId,String tzt) {
		super();
		this.appealId=appealId;
		this.title=title;
		this.companyName = companyName;
		this.area = area;
		this.appealType = appealType;
		this.appealContent = appealContent;
		this.appealState = appealState;
//		this.appealTime = appealTime;
		if (!BeanUtils.isNullOrEmpty(appealTime) && appealTime.contains(" ")) {
			this.appealTime = appealTime.split(" ")[0];
		}
		this.bizId=bizId;
		this.tzt=tzt;
	}
    
    //近期诉求
    public AppealCenterModel(String bizId,String title,String appealType, String appealContent,
			String appealState, String appealTime) {
		super();
		this.bizId=bizId;
		this.title=title;
		this.appealType = appealType;
		this.appealContent = appealContent;
		this.appealState = appealState;
		this.appealTime = appealTime;
	}

	public String getStatusType(){
    	if ("0".equals(appealState)) {
    		return "市级待派发";
    	}
    	if ("1".equals(appealState)) {
    		return "县级待派发";
    	}
    	if ("2".equals(appealState)) {
    		return "市级已派发";
    	}
    	if ("3".equals(appealState)) {
    		return "县级已派发";
    	}
    	if ("4".equals(appealState)) {
    		return "待评价";
    	}
    	if ("5".equals(appealState)) {
    		return "已办结";
    	}
    	if ("10".equals(appealState)) {
    		return "已保存";
    	}
    	if ("11".equals(appealState)) {
    		return "处理中";
    	}
    	if ("12".equals(appealState)) {
    		return "终止";
    	}
    	if ("13".equals(appealState)) {
    		return "上报";
    	}
		return null;
    }
    
    
	public String getTzt() {
		return tzt;
	}

	public void setTzt(String tzt) {
		this.tzt = tzt;
	}

	public String getTimeLimit() {
		return timeLimit;
	}

	public void setTimeLimit(String timeLimit) {
		this.timeLimit = timeLimit;
	}

	public String getAppealId() {
		return appealId;
	}

	public void setAppealId(String appealId) {
		this.appealId = appealId;
	}

	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}

	public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAppealNo() {
        return area;
    }

    public void setAppealNo(String appealNo) {
        this.area = appealNo;
    }

    public String getAppealType() {
        return appealType;
    }

    public void setAppealType(String appealType) {
        this.appealType = appealType;
    }

    public String getAppealContent() {
        return appealContent;
    }

    public void setAppealContent(String appealContent) {
        this.appealContent = appealContent;
    }

    public String getAppealState() {
        return appealState;
    }

    public void setAppealState(String appealState) {
        this.appealState = appealState;
    }

    public String getAppealTime() {
        return appealTime;
    }

    public void setAppealTime(String appealTime) {
        this.appealTime = appealTime;
    }



	public String getBizId() {
		return bizId;
	}

	public void setBizId(String bizId) {
		this.bizId = bizId;
	}

	@Override
	public String toString() {
		return "AppealCenterModel [title=" + title + ", companyName="
				+ companyName + ", area=" + area + ", appealType=" + appealType
				+ ", appealContent=" + appealContent + ", appealState="
				+ appealState + ", appealTime=" + appealTime + ", bizId="
				+ bizId + "]";
	}



	
    
}
