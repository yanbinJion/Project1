package com.gt.ytbf.oa.model;

import java.io.Serializable;

/** 用户信息*/
public class UserInfo implements Serializable{

	/** 员工编号*/
	private String userNo;
	/** 登录密码*/
	private String password;
	/** 员工姓名*/
	private String userName;
	/** 部门编号*/
	private String deptNo;
	/** 部门名称*/
	private String deptName;
	/** 职位*/
	private String place;
	/** 认证*/
	private String sessionId;
	
	private String authtoken;
	/** 挂点部门和职能部门是否可以切换*/
	private boolean isSwitch;
	
	public String getAuthtoken() {
		return authtoken;
	}

	public void setAuthtoken(String authtoken) {
		this.authtoken = authtoken;
	}

	public boolean isSwitch() {
		return isSwitch;
	}

	public void setSwitch(boolean isSwitch) {
		this.isSwitch = isSwitch;
	}

	public String getOrgCode() {
		return orgCode;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getUserLevel() {
		return userLevel;
	}

	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getUserSortNo() {
		return userSortNo;
	}

	public void setUserSortNo(String userSortNo) {
		this.userSortNo = userSortNo;
	}

	private String orgCode;
	private String state;
	private String userLevel;
	private String userCode;
	private String userId;
	public String getDepLevel() {
		return depLevel;
	}

	public void setDepLevel(String depLevel) {
		this.depLevel = depLevel;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInvalid() {
		return invalid;
	}

	public void setInvalid(String invalid) {
		this.invalid = invalid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsDispatch() {
		return isDispatch;
	}

	public void setIsDispatch(String isDispatch) {
		this.isDispatch = isDispatch;
	}

	private String userPwd;
	private String userSortNo;
	private String departMentId;
	private String depLevel;
	private String id;
	private String invalid;
	private String name;
	private String isDispatch;
	public UserInfo() {}
	
	public UserInfo(String userNo, String password, String userName) {
		this.userNo = userNo;
		this.password = password;
		this.userName = userName;
	}
	
	public String getUserNo() {
		return userNo;
	}
	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	
	public String getDepartMentId() {
		return departMentId;
	}

	public void setDepartMentId(String departMentId) {
		this.departMentId = departMentId;
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		String blank = "  ";
		buffer.append("userNo:").append(userNo).append(blank);
		buffer.append("userName:").append(userName).append(blank);
		buffer.append("deptNo:").append(deptNo).append(blank);
		buffer.append("deptName:").append(deptName).append(blank);
		buffer.append("place:").append(place).append(blank);
		buffer.append("sessionId:").append(sessionId).append(blank);
		
		buffer.append("authtoken:").append(authtoken).append(blank);
		buffer.append("orgCode:").append(orgCode).append(blank);
		buffer.append("state:").append(state).append(blank);
		buffer.append("userevel:").append(userLevel).append(blank);
		buffer.append("userCode:").append(userCode).append(blank);
		buffer.append("userId:").append(userId).append(blank);
		buffer.append("userPwd:").append(userPwd).append(blank);
		buffer.append("userSortNo:").append(userSortNo).append(blank);
		buffer.append("departMentId").append(departMentId).append(blank);
		buffer.append("depLevel").append(depLevel).append(blank);
		buffer.append("id").append(id).append(blank);
		buffer.append("invalid").append(invalid).append(blank);
		buffer.append("name").append(name).append(blank);
		buffer.append("isDispatch").append(isDispatch).append(blank);
		return buffer.toString();
	}
	
}
