package com.gt.ytbf.oa.model;

import android.graphics.Bitmap;

import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;

public class TaskFileInfo {
	public TaskFileInfo(String fileCode, String fileTitle, String fileName) {
		this.fileCode = fileCode;
		this.fileTitle = fileTitle;
		this.fileName = fileName;
		if (!BeanUtils.isEmpty(fileCode)) {
			if (BeanUtils.isEmpty(fileName)) {// 没有扩展名
				localFileName = new String(fileCode);
				localFullPath = new String(
						Constants.SDCARD_DIR_IMAGE_DOWNLOAD + localFileName);
			} else {// 添加扩展名
				int start = fileName.lastIndexOf(".");
				if (start > 0) {
					localFileName = new String(fileCode
							+ fileName.substring(start));// 加上扩展名
					localFullPath = new String(
							Constants.SDCARD_DIR_IMAGE_DOWNLOAD
									+ localFileName);
				} else {
					localFileName = new String(fileCode);// 没有扩展名
					localFullPath = new String(
							Constants.SDCARD_DIR_IMAGE_DOWNLOAD
									+ localFileName);
				}
			}
		}
	}

	public String fileCode = null;
	public String fileTitle = null;
	public String fileName = null;
	public String localFullPath = null;// 完整的本地路径
	public String localFileName = null;// 本地的文件名，含有扩展名
	public Bitmap fileBmp = null;
}
