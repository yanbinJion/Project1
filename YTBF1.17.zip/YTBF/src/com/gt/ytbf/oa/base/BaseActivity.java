package com.gt.ytbf.oa.base;
	
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gt.ytbf.oa.OADroid;
import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.LogUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.SharePreferenceUtil;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.LoginActivity;
import com.gt.ytbf.oa.ui.LoginGesturesPasswordActivity;
import com.gt.ytbf.oa.ui.MainActivity;
import com.gt.ytbf.oa.ui.SettingsActivity;
	
/**	
 * 基础类，实现各个activity的基本信息
 * */
public abstract class BaseActivity extends Activity {
	
	private final String tag = "BaseActivity";
    public static final int DIALOG_ERROR = 11111;
    public static final int DIALOG_POWER = 22222;
	public ImageView backBtn;
	public ImageView rightBtn;
    public ImageView customBtn;
	public TextView titleTxt;
    protected String errorMessage;
    protected InvokeHelper helper;
    protected SharePreferenceUtil spUtils;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD);
		this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        helper = new InvokeHelper(this);
		OADroid.getInstance().addActivity(this);
	}
	
	/**
	 * 初始化title
	 * */
	public void initTitleBar(int titleRes, OnClickListener backListener, OnClickListener rightListener) {
		backBtn = (ImageView) findViewById(R.id.system_back);
		rightBtn = (ImageView) findViewById(R.id.btn_top_right);
        customBtn = (ImageView) findViewById(R.id.btn_custom_right);
		titleTxt = (TextView) findViewById(R.id.tv_top_title);
		if (titleRes > 0) {
			titleTxt.setText(titleRes);
		}
		if (null != backListener) {
			backBtn.setOnClickListener(backListener);
			backBtn.setVisibility(View.VISIBLE);
		}
		if (null != rightListener) {
			rightBtn.setOnClickListener(rightListener);
			rightBtn.setVisibility(View.VISIBLE);
		}	
	}		
			
    /**		
     * 设置自定义的返回按钮
     * */	
    public void setBackBtn(int res, OnClickListener listener) {
        if (res > 0) {
            backBtn.setBackgroundResource(res);
        }
        backBtn.setOnClickListener(listener);
        backBtn.setVisibility(View.VISIBLE);
    }

    /**
     * 设置自定义的返回按钮
     * */
    public void setRightBtn(int res, OnClickListener listener) {
        rightBtn.setImageResource(res);
        rightBtn.setOnClickListener(listener);
        rightBtn.setVisibility(View.VISIBLE);
    }

     /**
     * 验证返回的数据是否正常
     *
     * @ param resultItems
     * @return
     */
    @SuppressWarnings("deprecation")
    public boolean checkResult(ResultItem item) {
        try {
            if (!BeanUtils.isEmpty(item)) {
                String code = item.getString("code");
                if (!Constants.SUCCESS_CODE.equals(code)) {
                    errorMessage = item.getString("message");
                    //令牌失效
                    if (Constants.LOGIN_FAIL_CODE.equals(code)) {
                        errorMessage = "认证失败，请重新登录！";
                        showDialog(DIALOG_POWER);
                    } else {
                        showDialog(DIALOG_ERROR);
                    }
                    return false;
                }
            } else {
                errorMessage = getString(R.string.system_request_error_message);
                showDialog(DIALOG_ERROR);
                return false;
            }
        } catch (Exception e) {

        }
        return true;
    }

    public void showErrorMessage(String message) {
        errorMessage = message;
        showDialog(DIALOG_ERROR);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_POWER :
                return new AlertDialog.Builder(BaseActivity.this)
//                        .setIcon(R.drawable.icon_laucher4)
                        .setTitle(R.string.app_name)
                        .setMessage(errorMessage)
                        .setPositiveButton(R.string.system_dialog_confirm,
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int whichButton) {
                                    	LoginUtils.getInstance().logout();
                                		OADroid.getInstance().onTerminate();
                                    	MainActivity.getInstance().finish();
                                    	Intent intent = new Intent(BaseActivity.this, LoginActivity.class);
                                    	startActivity(intent);
                                    	finish();
                                    }
                                }).create();
            case DIALOG_ERROR :
                Toast.makeText(BaseActivity.this, errorMessage,
                        Toast.LENGTH_SHORT).show();
                break;
            default :
                break;
        }
        return super.onCreateDialog(id);
    }
	
	/**
	 * 初始化title
	 * */
	public void initTitleBar(String titleRes, OnClickListener backListener, OnClickListener rightListener) {
		backBtn = (ImageView) findViewById(R.id.system_back);
		rightBtn = (ImageView) findViewById(R.id.btn_top_right);
        customBtn = (ImageView) findViewById(R.id.btn_custom_right);
		titleTxt = (TextView) findViewById(R.id.tv_top_title);
		if (!StringUtils.isNullOrEmpty(titleRes)) {
			titleTxt.setText(titleRes);
		}
		if (null != backListener) {
			backBtn.setOnClickListener(backListener);
			backBtn.setVisibility(View.VISIBLE);
		}
		if (null != rightListener) {
			rightBtn.setOnClickListener(rightListener);
			rightBtn.setVisibility(View.VISIBLE);
		}
	}

    public void setCustom(OnClickListener listener, int imgRes) {
        customBtn.setOnClickListener(listener);
        if (imgRes > 0) {
            customBtn.setImageResource(imgRes);
        }
        customBtn.setVisibility(View.VISIBLE);
    }
    
    public void setMainNavigator() {
    	backBtn.setImageResource(R.drawable.white_icon_i);
    	backBtn.setVisibility(View.VISIBLE);
    	backBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(BaseActivity.this, SettingsActivity.class);
				startActivity(intent);
			}
    		
    	});
    	rightBtn.setImageResource(R.drawable.white_icon_search);
    	rightBtn.setVisibility(View.VISIBLE);
    	rightBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
			}
    		
    	});
    }
	
    /** 
     * 检测网络是否连接 
     * @return 
     */  
    public boolean checkNetworkState() {  
        boolean flag = false;  
        //得到网络连接信息  
        ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);  
        //去进行判断网络是否连接  
        if (manager.getActiveNetworkInfo() != null) {  
            flag = manager.getActiveNetworkInfo().isAvailable();  
        }  
        if (!flag) {  
        	errorMessage = "网络不给力，请检查网络设置";
            showDialog(DIALOG_ERROR); 
        }  
  
        return flag;  
    }  
	@Override
	protected void onDestroy() {
		super.onDestroy();
		OADroid.getInstance().removeActivity(this);
	}
	
	@Override
	protected void onRestart() {
		super.onRestart();
		if (null == spUtils) {
			spUtils = new SharePreferenceUtil(this);
		}
		boolean flag = LoginUtils.getInstance().getIsGround();
		boolean state = spUtils.getPatternState();
		String pwd = spUtils.getPatternPwd();
		LogUtils.d(tag, "=================onRestart flag: " + flag + " state " + state);
		if (flag && state && !StringUtils.isNullOrEmpty(pwd)) {
			Intent intent = new Intent(this, LoginGesturesPasswordActivity.class);
//			intent.setFlags(Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY);
			startActivity(intent);
		}
	}

	@Override
	protected void onStop() {
		super.onStop();
		LogUtils.d(tag, "onStop()");
		boolean flag = LoginUtils.getInstance().isAppOnForeground(this, getPackageName());
		LoginUtils.getInstance().setIsGround(!flag);
	}
}
