package com.gt.ytbf.oa.network;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.HashMap;

import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.model.TaskFileInfo;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;


/**
 * 参考地址：http://blog.csdn.net/wangkuifeng0118/article/details/7648618
 */
@SuppressLint("DefaultLocale")
public class AsyncBitmapLoader {
	/**
	 * 内存图片软引用缓冲
	 */
	private HashMap<String, SoftReference<Bitmap>> imageCache = null;

	public AsyncBitmapLoader() {
		imageCache = new HashMap<String, SoftReference<Bitmap>>();
	}

	public Bitmap loadBitmap(final TaskFileInfo fileInfo,
			final String imageURL, final ImageCallBack2 imageCallBack2) {
		// 在内存缓存中，则返回Bitmap对象
		if (imageCache.containsKey(imageURL)) {
			SoftReference<Bitmap> reference = imageCache.get(imageURL);
			Bitmap bitmap = reference.get();
			if (bitmap != null) {
				fileInfo.fileBmp = bitmap;
				return bitmap;
			}
		} else {
			/**
			 * 加上一个对本地目录的查找
			 */
			if (fileInfo.localFullPath != null) {
				File localFile = new File(fileInfo.localFullPath);
				if (localFile != null && localFile.exists()
						&& localFile.isFile()) {
					fileInfo.fileBmp = BitmapFactory
							.decodeFile(fileInfo.localFullPath);
					return BitmapFactory.decodeFile(fileInfo.localFullPath);
				}
			}
		}

		final Handler handler = new Handler() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see android.os.Handler#handleMessage(android.os.Message)
			 */
			@Override
			public void handleMessage(Message msg) {
				imageCallBack2.imageLoad(fileInfo, (Bitmap) msg.obj);
			}
		};

		// 如果不在内存缓存中，也不在本地（被jvm回收掉），则开启线程下载图片
		new Thread() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Thread#run()
			 */
			@Override
			public void run() {
				InputStream bitmapIs = HttpUtils.getStreamFromURL(imageURL);

				Bitmap bitmap = BitmapFactory.decodeStream(bitmapIs);
				imageCache.put(imageURL, new SoftReference<Bitmap>(bitmap));

				File fileDir = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD);// 附件图片目录

				if (!fileDir.exists()) {
					fileDir.mkdirs();
				}

				File bitmapFile = new File(fileInfo.localFullPath);
				if (!bitmapFile.exists()) {
					try {
						bitmapFile.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

				FileOutputStream fos = null;
				try {
					fos = new FileOutputStream(bitmapFile);
					if (fileInfo.localFullPath.toLowerCase().endsWith(".jpg")) {
						bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
					} else if (fileInfo.localFullPath.toLowerCase().endsWith(
							".png")) {
						bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
					} else {
						bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
					}
					fos.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

				// 下载完成，通知回调
				Message msg = handler.obtainMessage(0, bitmap);
				handler.sendMessage(msg);
			}
		}.start();

		return null;
	}

	public Bitmap loadBitmap(final ImageView imageView, final String imageURL,
			final ImageCallBack imageCallBack) {
		// 在内存缓存中，则返回Bitmap对象
		if (imageCache.containsKey(imageURL)) {
			SoftReference<Bitmap> reference = imageCache.get(imageURL);
			Bitmap bitmap = reference.get();
			if (bitmap != null) {
				return bitmap;
			}
		} else {
			/**
			 * 加上一个对本地缓存的查找
			 */
			String bitmapName = imageURL
					.substring(imageURL.lastIndexOf("/") + 1);
			File cacheDir = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD);
			File[] cacheFiles = cacheDir.listFiles();
			int i = 0;
			if (null != cacheFiles) {
				for (; i < cacheFiles.length; i++) {
					if (bitmapName.equals(cacheFiles[i].getName())) {
						break;
					}
				}

				if (i < cacheFiles.length) {
					return BitmapFactory
							.decodeFile(Constants.SDCARD_DIR_IMAGE_DOWNLOAD
									+ bitmapName);
				}
			}
		}

		final Handler handler = new Handler() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see android.os.Handler#handleMessage(android.os.Message)
			 */
			@Override
			public void handleMessage(Message msg) {
				imageCallBack.imageLoad(imageView, (Bitmap) msg.obj);
			}
		};

		// 如果不在内存缓存中，也不在本地（被jvm回收掉），则开启线程下载图片
		new Thread() {
			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Thread#run()
			 */
			@Override
			public void run() {
				InputStream bitmapIs = HttpUtils.getStreamFromURL(imageURL);

				Bitmap bitmap = BitmapFactory.decodeStream(bitmapIs);
				imageCache.put(imageURL, new SoftReference<Bitmap>(bitmap));

				File fileDir = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD);
				if (!fileDir.exists()) {
					fileDir.mkdirs();
				}

				File bitmapFile = new File(Constants.SDCARD_DIR_IMAGE_DOWNLOAD
						+ imageURL.substring(imageURL.lastIndexOf("/") + 1));
				if (!bitmapFile.exists()) {
					try {
						bitmapFile.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

				FileOutputStream fos = null;
				try {
					fos = new FileOutputStream(bitmapFile);
					bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
					fos.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

				// 下载完成，通知回调
				Message msg = handler.obtainMessage(0, bitmap);
				handler.sendMessage(msg);
			}
		}.start();

		return null;
	}

	public interface ImageCallBack {
		public void imageLoad(ImageView imageView, Bitmap bitmap);
	}

	public interface ImageCallBack2 {
		public void imageLoad(TaskFileInfo fileInfo, Bitmap bitmap);
	}
}