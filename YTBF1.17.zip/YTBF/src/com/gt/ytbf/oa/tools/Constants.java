package com.gt.ytbf.oa.tools;

import android.os.Environment;

/**
 * 常量定义工具类
 * **/

public class Constants {

	/** 请求服务器返回成功编码 **/
	public static final String SUCCESS_CODE = "0";
	
	/** 程序数据保存的根路径 */
	public static final String SDString = Environment.getExternalStorageDirectory() + "";
	/** SDCARD 路径 */
	public final static String SDCARD_DIR = SDString.concat("/GTOA");
	/** 新建文档的路径 */
	public final static String SDCARD_DIR_NEW_FILE = SDCARD_DIR.concat("/filecache/");
	/** 网络下载公文的文件夹 */
	public final static String SDCARD_DIR_DOCUMENT_DOWNLOAD = SDCARD_DIR.concat("/doc_download/");
	/** 下载的附件图片文件夹 */
	public final static String	SDCARD_DIR_IMAGE_DOWNLOAD	= SDCARD_DIR.concat("/img_download/");
	/** 下载的附件文本文件夹 */
	public final static String	SDCARD_DIR_TXT_DOWNLOAD	= SDCARD_DIR.concat("/txt_download/");
	/** 创建临时文件 */
	public final static String SDCARD_TEMP_FILE = "temp.doc";

    public final static String NAME_SPACE = "http://webservice.fwlm.ytmh.platform.powerrich.com";
    public final static int TIME_OUT = 6 * 1000;
    //测试库
//    public final static String BASE_URL = "http://218.17.204.4:8889/platform/services";
    //正式库
    public final static String BASE_URL = "http://218.87.176.153/platform/services";
    public final static String URL = BASE_URL + "/appLogin";
    public final static String URL_GETCOMPANYINFO = BASE_URL + "/handleAppeal";
    public final static String URL_APPEAL = BASE_URL + "/appQuery";

	/** 临时文件打开标识 */
	public final static String TAG_TEMP_FILE = "temp";
	
}
