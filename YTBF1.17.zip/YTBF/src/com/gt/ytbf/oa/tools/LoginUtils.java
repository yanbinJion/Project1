package com.gt.ytbf.oa.tools;

import java.util.List;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;

import com.gt.ytbf.oa.model.UserInfo;

/**
 * 用户登陆工具类
 * */
public class LoginUtils {

	private static final String TAG = LoginUtils.class.getSimpleName();
	/**
	 * 登陆用户信息实例
	 * */
	private static UserInfo userInfo;
	/**
	 * 当前类实例对象
	 * */
	private static LoginUtils instance;
	/**
	 * 登陆是否成功
	 * */
	private static boolean loginSuccess;
	/**
	 * 
	 * */
	private static boolean isGround;
	
	private LoginUtils() {
		
	}
	
	/**
	 * 获取操作对象
	 * */
	public static LoginUtils getInstance() {
		if (null == instance) {
			instance = new LoginUtils();
		}
		return instance;
	}

	/**
	 * 获取当前用户信息
	 * */
	public UserInfo getUserInfo() {
		if(null == userInfo){
			userInfo =  new UserInfo();
		}
		return userInfo;
	}

	/**
	 * 设置当前用户信息
	 * */
	public void setUserInfo(UserInfo info) {
		userInfo = info;
	}

	/**
	 * 检查登陆账号和密码的正确性
	 * */
	public static boolean checkAcountAndPwd(String userNo, String pwd) {
		if (StringUtils.isNullOrEmpty(userNo) || StringUtils.isNullOrEmpty(pwd)) {
			return false;
		}
		String regex = "[\\d]{1,}";
		if (userNo.trim().matches(regex)) {
			return true;
		}
		return false;
	}

	/**
	 * 保存当前用户信息
	 * */
	public void saveUserInfo(boolean isSavePwd) {
		if (null != userInfo) {
			String id = userInfo.getUserNo();
			String pwd = userInfo.getPassword();
			String userName = userInfo.getUserName();
			id = Base64Utils.encode(id.getBytes());
			if (isSavePwd) {
				pwd = Base64Utils.encode(pwd.getBytes());
			} else {
				pwd = "";
			}
			SharePreferenceUtil pref = new SharePreferenceUtil();
			pref.saveUserInfo(new UserInfo(id, pwd,userName));
			LogUtils.d(TAG, "saveUserInfo: success: userName " + (id == null)
					+ " pwd " + (null == pwd));
		} else {
			LogUtils.w(TAG, "saveUserInfo failed!!");
		}
	}

	/**
	 * 退出系统
	 * */
	public void logout() {
		if (null != userInfo) {
			userInfo = null;
		}
	}

	/**
	 * 清除用户信息
	 * */
	public void clearUserInfo() {
		SharePreferenceUtil pref = new SharePreferenceUtil();
		pref.clearUserInfo();
		logout();
	}

	/**
	 * 检测是否自动登陆
	 * */
//	public UserInfo checkAutoLogin() {
//		userInfo = new UserInfo();
//		SharePreferenceUtil pref = new SharePreferenceUtil();
//		UserInfo user = pref.getUserInfo();
//		String getUserNo() = user.getUserNo();
//		String pwd = user.getPassword();
//		String userName = user.userName;
//		if (!StringUtils.isNullOrEmpty(getUserNo())) {
//			userInfo.getUserNo() = new String(Base64Utils.decode(getUserNo()));
//		} else {
//			userInfo.getUserNo() = "";
//		}
//		if (!StringUtils.isNullOrEmpty(pwd)) {
//			userInfo.getPassword() = new String(Base64Utils.decode(pwd));
//		} else {
//			userInfo.getPassword() = "";
//		}
//		if (!StringUtils.isNullOrEmpty(userName)) {
//			userInfo.userName = userName;
//		} else {
//			userInfo.userName = "";
//		}		
//		return userInfo;
//	}

	/**
	 * 是否需要自动登陆
	 * */
	public boolean isNeedAutoLogin() {
		return null != userInfo && !StringUtils.isNullOrEmpty(userInfo.getUserNo())
				&& !StringUtils.isNullOrEmpty(userInfo.getPassword());
	}
	
	/**
	 * 是否登陆成功
	 * */
	public boolean isLoginSuccess() {
		return loginSuccess;
	}
	
	public void setIsLoginSuccess(boolean flag) {
		loginSuccess = flag;
	}
	
	public void setIsGround(boolean flag) {
		isGround = flag;
	}
	
	public boolean getIsGround() {
		return isGround;
	}
	
	public boolean isAppOnForeground(Context context, String packageName) {
		ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		if (activityManager == null) {
			return false;
		}
		List<RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
		if (appProcesses == null) {
			return false;
		}
		for (RunningAppProcessInfo appProcess : appProcesses) {
			if (appProcess.processName.equals(packageName)
					&& appProcess.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
				return true;
			}
		}
		return false;
	}
}
