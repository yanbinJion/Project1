package com.gt.ytbf.oa.tools;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gt.ytbf.oa.OADroid;
import com.gt.ytbf.oa.common.ResultItem;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;

/**
 * FileName : ResourceUtils Description : 对象数据处理对象
 **/
@SuppressLint("DefaultLocale")
public class BeanUtils {

	/**
	 * 通用资源的关闭操作
	 * 
	 * @param closeable
	 */
	public static void close(Closeable closeable) {
		if (closeable != null) {
			try {
				closeable.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 反射对象
	 * 
	 * @param className
	 * @return
	 */
	public static Object loadClass(String className) {
		Object obj = null;
		try {
			@SuppressWarnings("rawtypes")
			Class classs = Class.forName(className);
			obj = classs.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("加载【" + className + "】失败!");
		}
		return obj;
	}

	/**
	 * 判断数据是否为空
	 * 
	 * @param obj
	 * @return
	 */
	@SuppressWarnings("all")
	public static boolean isEmpty(Object obj) {
		boolean flag = true;
		if (obj != null) {
			if (obj instanceof String) {
				flag = (obj.toString().trim().length() == 0);
			} else if (obj instanceof Collection<?>) {
				flag = ((Collection) obj).size() == 0;
			} else {
				flag = false;
			}
		}
		return flag;
	}

	/**
	 * 方法说明：<br>
	 * 判断字符串
	 * 
	 * @param str
	 * @return
	 */
	public static String isEmptyStr(String str) {
		if (str == null || "null".equals(str.toLowerCase()) || str.trim().length() == 0) {
			//TODO 去掉暂无，但有些地方无数据时，感觉很别扭；
			return "";
		}
		return str;
	}

	/**
	 * 日期转换
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String formatDate(Date date, String format) {
		String result = "";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			result = sdf.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 字符串转换日期
	 * 
	 * @param dateStr
	 * @param formatStr
	 * @return
	 */
	public static Date parseDate(String dateStr, String formatStr) {
		Date result = null;
		try {
			if (dateStr.length() < formatStr.length()) {
				dateStr = "0" + dateStr;
			}
			SimpleDateFormat sdf = new SimpleDateFormat(formatStr);
			result = sdf.parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 文件保存
	 * 
	 * @param message
	 */
	public static void saveFile(InputStream inps, String filePath) {
		OutputStream out = null;
		try {
			out = new FileOutputStream(filePath);
			int i = 0;
			while ((i = inps.read()) != -1) {
				out.write(i);
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(inps);
			close(out);
		}
	}

	/**
	 * 文件保存
	 * 
	 * @param fileContent
	 */
	public static void saveFile(String fileContent, String filePath) {
		if (!BeanUtils.isEmpty(fileContent)) {
			saveFile(fileContent.getBytes(), filePath);
		}
	}

	/** 解析文件名称 */
	public static String parseFileName(String url) {
		String fileName = "";
		int lastSplit = url.lastIndexOf("/");
		int lastSplit1 = url.lastIndexOf("\\");
		lastSplit = lastSplit > lastSplit1 ? lastSplit : lastSplit1;
		fileName = url.substring(lastSplit + 1);
		return fileName;
	}

	/** 删除除什么路径之外的文件 */
	public static void deleteFile(String filePath, String excludePath) {
		try {
			File file = new File(filePath);
			if (file.exists()) {
				boolean isExclude = !file.getAbsolutePath().endsWith(
						excludePath)
						|| BeanUtils.isEmpty(excludePath);
				if (file.isDirectory() && isExclude) {
					String[] tempList = file.list();
					File temp = null;
					for (int i = 0; i < tempList.length; i++) {
						if (filePath.endsWith(File.separator)) {
							temp = new File(filePath + tempList[i]);
						} else {
							temp = new File(filePath + File.separator
									+ tempList[i]);
						}
						if (temp.isFile()) {
							temp.delete();
						}
						if (temp.isDirectory()) {
							deleteFile(filePath + File.separator + tempList[i],
									excludePath);
						}
					}
				}
				if (isExclude) {
					file.delete();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/** 删除文件 */
	public static void deleteFile(String filePath) {
		deleteFile(filePath, "");
	}

	/**
	 * 文件保存
	 * 
	 * @param byes
	 */
	public static void saveFile(byte[] byes, String filePath) {
		OutputStream output = null;
		try {
			output = new FileOutputStream(filePath);
			output.write(byes);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(output);
		}
	}

	/**
	 * 将Base64编码解析
	 * 
	 * @param value
	 * @return
	 */
	public static String decodeBase64(String value) {
		if (!BeanUtils.isEmpty(value)) {
			try {
				byte[] srcbyties = Base64.decode(value, Base64.DEFAULT);
				value = new String(srcbyties);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return value;
	}

	/**
	 * 将Base64编码解析
	 * 
	 * @param value
	 * @return
	 */
	public static byte[] decodeBase64Data(String value) {
		byte[] srcbyties = null;
		try {
			srcbyties = Base64.decode(value, Base64.DEFAULT);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return srcbyties;
	}

	/**
	 * 获取对象的属性
	 * 
	 * @param obj
	 * @param key
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Object getFieldValue(Object obj, String key) {
		if (obj != null) {
			if (obj instanceof Map<?, ?>) {
				return ((Map<String, Object>) obj).get(key);
			} else if (obj instanceof ResultItem) {
				return ((ResultItem) obj).get(key);
			} else if (obj instanceof String) {
				return obj;
			}
		}
		return null;
	}

	/** 获取文件路径 */
	public static String getFileContext(String filePath) {
		String message = "";
		try {
			message = getFileContext(new FileInputStream(filePath));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	/** 获取文件内容 */
	public static String getFileContext(InputStream input) {
		String mesage = "";
		ByteArrayOutputStream outStrem = null;
		try {
			outStrem = new ByteArrayOutputStream();
			int i = 0;
			while ((i = input.read()) != -1) {
				outStrem.write(i);
			}
			mesage = new String(outStrem.toByteArray());
			return mesage;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("");
		} finally {
			try {
				input.close();
				outStrem.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * URl的拼接
	 * 
	 * @param url
	 * @param parts
	 * @return
	 */
	public static String urlAppend(String url, String parts) {
		url = url.trim();
		if (!BeanUtils.isEmpty(parts)) {
			if (url.indexOf("?") < 0) {
				url += "?";
			} else {
				url += "&";
			}
		}
		return url + parts;
	}

	/**
	 * 验证文件路径是否存在，不存在则进行创建操作
	 * 
	 * @param filePath
	 */
	public static void checkFileExist(String filePath) {
		File file = new File(filePath);
		if (!file.exists()) {
			file.mkdirs();
		}
	}

	public static boolean isFileExist(String filePath) {
		boolean hasFile = false;
		try {
			File file = new File(filePath);
			hasFile = file.exists();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hasFile;
	}

	/**
	 * 将数据库的查询内容转换为具体的数据内容
	 * 
	 * @param cursor
	 * @return
	 */
	public static List<ResultItem> convertCursor(Cursor cursor) {
		List<ResultItem> results = new ArrayList<ResultItem>();
		if (cursor != null && cursor.getCount() > 0) {
			for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor
					.moveToNext()) {
				int size = cursor.getColumnCount();
				ResultItem item = new ResultItem();
				for (int i = 0; i < size; i++) {
					item.addValue(cursor.getColumnName(i), cursor.getString(i));
				}
				results.add(item);
			}
		}
		return results;
	}

	/***
	 * 生成32位的MD5加密内容
	 * 
	 * @param str
	 * @return
	 */
	public static String md532(String source) {
		char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f'};
		try {
			byte[] strTemp = source.getBytes();
			// 使用MD5创建MessageDigest对象
			MessageDigest mdTemp = MessageDigest.getInstance("MD5");
			mdTemp.update(strTemp);
			byte[] md = mdTemp.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte b = md[i];
				// 将没个数(int)b进行双字节加密
				str[k++] = hexDigits[b >> 4 & 0xf];
				str[k++] = hexDigits[b & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}

	/***
	 * 对称加密
	 * 
	 * @param key
	 * @param desConstants
	 * @return
	 */
	public static String desEncrypt(String key, String desConstants) {
		byte[] values = new byte[10];
		try {
			SecureRandom sr = new SecureRandom();
			DESKeySpec dks = new DESKeySpec(desConstants.getBytes());
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(dks);
			Cipher cipher = Cipher.getInstance("DES");
			cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
			values = cipher.doFinal(key.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Base64.encodeToString(values, Base64.DEFAULT);
	}

	/***
	 * 对称解密
	 * 
	 * @param key
	 * @param desConstants
	 * @return
	 */
	public static String desDecrypt(String key, String desConstants) {
		byte[] values = new byte[10];
		try {
			SecureRandom sr = new SecureRandom();
			DESKeySpec dks = new DESKeySpec(desConstants.getBytes());
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(dks);
			Cipher cipher = Cipher.getInstance("DES");
			cipher.init(Cipher.DECRYPT_MODE, securekey, sr);
			values = cipher.doFinal(Base64.decode(key, Base64.DEFAULT));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String(values, 0, values.length);
	}

	/** 根据流获取文本内容 */
	public static String getContent(InputStream in, String encode) {
		StringBuffer mesage = new StringBuffer();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(in, encode));
			int i = 0;
			while ((i = reader.read()) != -1) {
				mesage.append((char) i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			BeanUtils.close(in);
		}
		return mesage.toString();
	}

	/** 将JsonObject转换成ResultItem */
	@SuppressWarnings("unchecked")
	public static ResultItem convertJSONObject(JSONObject jsonObj) {
		ResultItem resultItem = new ResultItem();
		if (jsonObj != null) {
			// 遍历所有的KEY值
			Iterator<String> keys = jsonObj.keys();
			while (keys.hasNext()) {
				String key = keys.next();
				try {
					// 获取具体对象
					Object obj = jsonObj.get(key);
					if (obj != null) {
						if (obj instanceof JSONObject) {
							// 添加属性(递归添加)
							resultItem.addValue(key,
									convertJSONObject((JSONObject) obj));

						} else if (obj instanceof JSONArray) {
							// 列表对象
							List<ResultItem> listItems = new ArrayList<ResultItem>();
							// 将JSONArray足个解析
							JSONArray tempArray = (JSONArray) obj;
							for (int i = 0; i < tempArray.length(); i++) {
								// 递归添加
								listItems.add(convertJSONObject(tempArray
										.getJSONObject(i)));
							}
							resultItem.addValue(key, listItems);

						} else {
							resultItem.addValue(key, obj.toString());
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return resultItem;
	}

	/** 根据json对象生成ResultItem对象 */
	public static ResultItem getResultItemByJson(String context) {
		ResultItem item = new ResultItem();
		try {
			// 生成jsonObject
			JSONObject jsonObj = new JSONObject(context);
			// 转换为统一的ResultItem
			item = BeanUtils.convertJSONObject(jsonObj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return item;
	}

	/**
	 * 检查指定的字符串列表是否不为空。
	 */
	public static boolean areNotEmpty(String... values) {
		boolean result = true;
		if (values == null || values.length == 0) {
			result = false;
		} else {
			for (String value : values) {
				result &= !isEmpty(value);
			}
		}
		return result;
	}

	/**
	 * 从URL中提取所有的参数。
	 * 
	 * @param query
	 *            URL地址
	 * @return 参数映射
	 */
	public static Map<String, String> splitUrlQuery(String query) {
		Map<String, String> result = new HashMap<String, String>();
		String[] pairs = query.split("&");
		if (pairs != null && pairs.length > 0) {
			for (String pair : pairs) {
				String[] param = pair.split("=", 2);
				if (param != null && param.length == 2) {
					result.put(param[0], param[1]);
				}
			}
		}
		return result;
	}

	/** 判断是否是Https请求 */
	public static boolean isHttps(String url) {
		return !BeanUtils.isEmpty(url) && url.toLowerCase().startsWith("https");
	}

	private static final Map<String, String> MIME_MAP = new HashMap<String, String>();

	static {
		MIME_MAP.put(".3gp", "video/3gpp");
		MIME_MAP.put(".apk", "application/vnd.android.package-archive");
		MIME_MAP.put(".asf", "video/x-ms-asf");
		MIME_MAP.put(".avi", "video/x-msvideo");
		MIME_MAP.put(".bin", "application/octet-stream");
		MIME_MAP.put(".bmp", "image/bmp");
		MIME_MAP.put(".c", "text/plain");
		MIME_MAP.put(".class", "application/octet-stream");
		MIME_MAP.put(".conf", "text/plain");
		MIME_MAP.put(".cpp", "text/plain");
		MIME_MAP.put(".doc", "application/msword");
		MIME_MAP.put(".docx", "application/msword");
		MIME_MAP.put(".exe", "application/octet-stream");
		MIME_MAP.put(".gif", "image/gif");
		MIME_MAP.put(".gtar", "application/x-gtar");
		MIME_MAP.put(".gz", "application/x-gzip");
		MIME_MAP.put(".h", "text/plain");
		MIME_MAP.put(".htm", "text/html");
		MIME_MAP.put(".html", "text/html");
		MIME_MAP.put(".jar", "application/java-archive");
		MIME_MAP.put(".java", "text/plain");
		MIME_MAP.put(".jpeg", "image/jpeg");
		MIME_MAP.put(".jpg", "image/jpeg");
		MIME_MAP.put(".js", "application/x-javascript");
		MIME_MAP.put(".log", "text/plain");
		MIME_MAP.put(".m3u", "audio/x-mpegurl");
		MIME_MAP.put(".m4a", "audio/mp4a-latm");
		MIME_MAP.put(".m4b", "audio/mp4a-latm");
		MIME_MAP.put(".m4p", "audio/mp4a-latm");
		MIME_MAP.put(".m4u", "video/vnd.mpegurl");
		MIME_MAP.put(".m4v", "video/x-m4v");
		MIME_MAP.put(".mov", "video/quicktime");
		MIME_MAP.put(".mp2", "audio/x-mpeg");
		MIME_MAP.put(".mp3", "audio/x-mpeg");
		MIME_MAP.put(".mp4", "video/mp4");
		MIME_MAP.put(".mpc", "application/vnd.mpohun.certificate");
		MIME_MAP.put(".mpe", "video/mpeg");
		MIME_MAP.put(".mpeg", "video/mpeg");
		MIME_MAP.put(".mpg", "video/mpeg");
		MIME_MAP.put(".mpg4", "video/mp4");
		MIME_MAP.put(".mpga", "audio/mpeg");
		MIME_MAP.put(".msg", "application/vnd.ms-outlook");
		MIME_MAP.put(".ogg", "audio/ogg");
		MIME_MAP.put(".pdf", "application/pdf");
		MIME_MAP.put(".png", "image/png");
		MIME_MAP.put(".pps", "application/vnd.ms-powerpoint");
		MIME_MAP.put(".ppt", "application/vnd.ms-powerpoint");
		MIME_MAP.put(".pptx", "application/vnd.ms-powerpoint");
		MIME_MAP.put(".prop", "text/plain");
		MIME_MAP.put(".rar", "application/x-rar-compressed");
		MIME_MAP.put(".rc", "text/plain");
		MIME_MAP.put(".rmvb", "audio/x-pn-realaudio");
		MIME_MAP.put(".rtf", "application/rtf");
		MIME_MAP.put(".sh", "text/plain");
		MIME_MAP.put(".tar", "application/x-tar");
		MIME_MAP.put(".tgz", "application/x-compressed");
		MIME_MAP.put(".txt", "text/plain");
		MIME_MAP.put(".wav", "audio/x-wav");
		MIME_MAP.put(".wma", "audio/x-ms-wma");
		MIME_MAP.put(".wmv", "audio/x-ms-wmv");
		MIME_MAP.put(".wps", "application/vnd.ms-works");
		MIME_MAP.put(".xml", "text/xml");
		MIME_MAP.put(".xml", "text/plain");
		MIME_MAP.put(".xls", "application/vnd.ms-excel");
		MIME_MAP.put(".xlsx", "application/vnd.ms-excel");
		MIME_MAP.put(".z", "application/x-compress");
		MIME_MAP.put(".zip", "application/zip");
		MIME_MAP.put(".vsd", "application/vnd.visio");
	}

	/**
	 * 获取对应的mimetype
	 */
	public static String getMimeType(String key) {
		String obj = (String) MIME_MAP.get(key);
		return obj != null ? obj : "*/*";
	}

	/**
	 * 判断手机号码
	 * 
	 * @param mobiles
	 * @return
	 */
	public static boolean isMobileNO(String mobiles) {
		Pattern p = Pattern
				.compile("^((13[0-9])|(15[^4,\\D])|(18[0-9]))\\d{8}$");
		Matcher m = p.matcher(mobiles);
		return m.matches();
	}
	
	/** 
     * 电话号码验证 
     *  
     * @param  str 
     * @return 验证通过返回true 
     */  
    public static boolean isPhone(String str) {   
        Pattern p1 = null,p2 = null;  
        Matcher m = null;  
        boolean b = false;    
        p1 = Pattern.compile("^[0][1-9]{2,3}-[0-9]{5,10}$");  // 验证带区号的  
        p2 = Pattern.compile("^[1-9]{1}[0-9]{5,8}$");         // 验证没有区号的  
        if(str.length() >9)  
        {   m = p1.matcher(str);  
            b = m.matches();    
        }else{  
            m = p2.matcher(str);  
            b = m.matches();   
        }    
        return b;  
    }

	/**
	 * 去除重复的
	 * 
	 * @param mobiles
	 * @return
	 */
	public static String clearSameData(String origistr, String str) {
		if (isEmpty(origistr)) {
			return str;
		}
		if (isEmpty(str)) {
			return "";
		}

		String[] origistrs = origistr.split(",");
		String[] strs = str.split(",");
		for (int i = 0; i < strs.length; i++) {
			boolean isSame = false;
			for (int j = 0; j < origistrs.length; j++) {
				if (origistrs[j].equals(strs[i])) {
					isSame = true;
					break;
				}
			}
			if (!isSame) {
				if (isEmpty(origistr)) {
					origistr = strs[i];
				} else {
					origistr = origistr + "," + strs[i];
				}
			}
		}

		return origistr;
	}

	/**
	 * 验证是否整数：采用正则表达式进行验证
	 * 
	 * @param num
	 * @param type
	 *            整数类型："0+":非负整数 "+":正整数 "-0":非正整数 "-":负整数 "":整数
	 * @return
	 */
	public static boolean checkNumber(String num, String type) {
		if (isEmpty(num)) {// 空
			return false;
		}
		String eL = "";
		if ("0+".equals(type)) {
			eL = "^\\d+$";// 非负整数
		} else if ("+".equals(type)) {
			eL = "^\\d*[1-9]\\d*$";// 正整数
		} else if ("-0".equals(type)) {
			eL = "^((-\\d+)|(0+))$";// 非正整数
		} else if ("-".equals(type)) {
			eL = "^-\\d*[1-9]\\d*$";// 负整数
		} else {
			eL = "^-?\\d+$";// 整数
		}
		// Pattern p = Pattern.compile(eL);
		// Matcher m = p.matcher(num);
		// boolean b = m.matches();
		// return b;
		return Pattern.compile(eL).matcher(num).matches();
	}

	/**
	 * 验证是否整数：采用正则表达式进行验证
	 * 
	 * @param num
	 * @return
	 */
	public static boolean checkNumber(String num) {
		if (isEmpty(num)) {// 空
			return false;
		}
		return checkNumber(num, null);
	}

	/**
	 * 验证是否浮点数：采用正则表达式进行验证
	 * 
	 * @param num
	 * @param type
	 *            浮点数类型："0+":非负浮点数 "+":正浮点数 "-0":非正浮点数 "-":负浮点数 "":浮点数
	 * @return
	 */
	public static boolean checkFloat(String num, String type) {
		if (isEmpty(num)) {// 空
			return false;
		}
		String eL = "";
		if ("0+".equals(type)) {
			eL = "^\\d+(\\.\\d+)?$";// 非负浮点数
		} else if ("+".equals(type)) {
			eL = "^((\\d+\\.\\d*[1-9]\\d*)|(\\d*[1-9]\\d*\\.\\d+)|(\\d*[1-9]\\d*))$";// 正浮点数
		} else if ("-0".equals(type)) {
			eL = "^((-\\d+(\\.\\d+)?)|(0+(\\.0+)?))$";// 非正浮点数
		} else if ("-".equals(type)) {
			eL = "^(-((\\d+\\.\\d*[1-9]\\d*)|(\\d*[1-9]\\d*\\.\\d+)|(\\d*[1-9]\\d*)))$";// 负浮点数
		} else {
			eL = "^(-?\\d+)(\\.\\d+)?$";// 浮点数
		}
		// Pattern p = Pattern.compile(eL);
		// Matcher m = p.matcher(num);
		// boolean b = m.matches();
		// return b;
		return Pattern.compile(eL).matcher(num).matches();
	}

	/**
	 * 验证是否浮点数：采用正则表达式进行验证
	 * 
	 * @param num
	 * @return
	 */
	public static boolean checkFloat(String num) {
		if (isEmpty(num)) {// 空
			return false;
		}
		return checkFloat(num, null);
	}

	/**
	 * 验证是否浮点数，如果不是，将返回默认值
	 * 
	 * @param num
	 * @param defaultValue
	 * @return
	 */
	public static Float checkFloat4Get(String num, Float defaultValue) {
		if (checkFloat(num, null)) {
			return Float.valueOf(num);
		} else {
			return defaultValue;
		}
	}

	/**
	 * 验证是否整数，如果不是，将返回默认值
	 * 
	 * @param num
	 * @param defaultValue
	 * @return
	 */
	public static Integer checkNumber4Get(String num, Integer defaultValue) {
		if (checkNumber(num, null)) {
			return Integer.valueOf(num);
		} else {
			return defaultValue;
		}
	}

	/**
	 * 浮点数转换为整数，如果转换失败，将返回默认值
	 * 
	 * @param num
	 * @param defaultValue
	 * @return
	 */
	public static Integer floatToInt(String num, Integer defaultValue) {
		if (checkFloat(num, null)) {
			return Float.valueOf(num).intValue();// 数据的准确性无法保证
		} else {
			return defaultValue;
		}
	}

	/**
	 * 浮点数转换为整数，如果转换失败，将返回0
	 * 
	 * @param num
	 * @return
	 */
	public static Integer floatToInt(String num) {
		return floatToInt(num, 0);
	}

	/**
	 * 浮点数转换为整数，如果转换失败，将返回默认值
	 * 
	 * @param num
	 * @param defaultValue
	 * @return
	 */
	public static String floatToInt4Str(String num, String defaultValue) {
		if (checkFloat(num, null)) {
			// 方法一：数据的准确性无法保证
			// Integer result = Float.valueOf(num).intValue();//数据的准确性无法保证
			// return result.toString();
			// 方法二：数据的准确性可以保证
			if (num.indexOf('.') != -1) {
				return num.substring(0, num.indexOf('.'));// 数据的准确性可以保证
			} else {
				return num;
			}
		} else {
			return defaultValue;
		}
	}

	/**
	 * 浮点数转换为整数，如果转换失败，将返回空字符串""
	 * 
	 * @param num
	 * @return
	 */
	public static String floatToInt4Str(String num) {
		return floatToInt4Str(num, "");
	}

	/**
	 * 验证是否为空，如果是，将返回默认值
	 * 
	 * @param value
	 * @param defaultValue
	 * @return
	 */
	public static String isEmpty4Get(String value, String defaultValue) {
		if (isEmpty(value)) {
			return defaultValue;
		} else {
			return value;
		}
	}

	/**
	 * 验证是否为空，如果是，将返回空字符串""
	 * 
	 * @param value
	 * @return
	 */
	public static String isEmpty4Get(String value) {
		if (isEmpty(value)) {
			return "";
		} else {
			return value;
		}
	}
	
	
	/**
	 * 判断当前是否是平板设备
	 * @param context
	 * @return
	 */
	public static boolean isTabletDevice(Context context) {
        TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        int type = telephony.getPhoneType();
        /**
         * 返回移动终端的类型
         * 
         * PHONE_TYPE_CDMA 手机制式为CDMA，电信  2
         * PHONE_TYPE_GSM 手机制式为GSM，移动和联通 1
         * PHONE_TYPE_NONE 手机制式未知  0
         */
        if (type == TelephonyManager.PHONE_TYPE_NONE) {
            return true;
        } else {
        	DisplayMetrics dm = new DisplayMetrics();
        	((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(dm);
            double diagonalPixels = Math.sqrt(Math.pow(dm.widthPixels, 2.0)
                    + Math.pow(dm.heightPixels, 2.0));
            double screenSize = diagonalPixels / (160 * dm.density);
            //如果大于7寸的手机，则试用pad版本
            if(screenSize >= 7){
            	 return true;
            }else{
            	return false;
            }
        }
	}
	
	/**
	 * 设置横竖屏幕
	 * @param context
	 * @return
	 */
	public static void setPortraitAndLandscape(Context context) {
		//如果不是pad版本，横竖屏都可以
        if (!isTabletDevice(context)) {
        	//竖屏
        	((Activity) context).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
	}

    public static boolean isNullOrEmpty(String content) {
        return (null == content || content.length() == 0);
    }
    
    public static void loadimg(String uri, ImageView imageView) {
		DisplayImageOptions options = OADroid.options;
		ImageLoader imageLoader = OADroid.mImageLoader;
		imageLoader.displayImage(uri, imageView, options,
				new SimpleImageLoadingListener() {
					@Override
					public void onLoadingStarted(String imageUri, View view) {
						super.onLoadingStarted(imageUri, view);
					}

					@Override
					public void onLoadingFailed(String imageUri, View view,
							FailReason failReason) {
						super.onLoadingFailed(imageUri, view, failReason);
						String message = null;
						switch (failReason.getType()) { // 获取图片失败类型
						case IO_ERROR: // 文件I/O错误
							message = "Input/Output error";
							break;
						case DECODING_ERROR: // 解码错误
							message = "Image can't be decoded";
							break;
						case NETWORK_DENIED: // 网络延迟
							message = "Downloads are denied";
							break;
						case OUT_OF_MEMORY: // 内存不足
							message = "Out Of Memory error";
							break;
						case UNKNOWN: // 原因不明
							message = "Unknown error";
							break;
						}
						LogUtils.w("BeanUtils", message);
					}

					@Override
					public void onLoadingComplete(String imageUri, View view,
							Bitmap loadedImage) {
						super.onLoadingComplete(imageUri, view, loadedImage);
					}
				});
	}

}
