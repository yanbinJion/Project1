package com.gt.ytbf.oa.tools;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.gt.ytbf.oa.OADroid;
import com.gt.ytbf.oa.model.UserInfo;


public class SharePreferenceUtil {
	/** 当前用户账号*/
	public static final String USER_ID = "user_id";
	/** 当前用户密码*/
	public static final String USER_PASSWORD = "user_pwd";
	
	/** 当前用户名*/
	public static final String USER_NAME = "user_name";
	/** 系统配置文件的默认名称*/
	private static final String DEFAULT_FILE_NAME = "settings";
	/** 是否开启图片锁状态*/
	public static final String PATTERN_STATE = "pattern_state";
	/** 图片锁密码*/
	public static final String PATTERN_PWD = "state";
	/** 合同审批通知状态*/
	public static final String CONTRACT_STATE = "contract_state";
	/** 新消息通知*/
	public static final String MESSAGE_NOTIFY = "message_notify";
	/** 新消息通知*/
	public static final String RING_NOTIFY = "ring_notify";
	/** 新消息通知*/
	public static final String VIBERATE_NOTIFY = "viberate_notify";
	private SharedPreferences sp;
	private Context context;
	private Editor edit;
	/**最近联系人*/
	public static final String RECENT_CONTACTS = "recent_contacts";

	public SharePreferenceUtil(Context context, String file) {
		this.context = context;
		sp = context.getSharedPreferences(file, Context.MODE_PRIVATE);
		edit = sp.edit();
	}
	
	public SharePreferenceUtil(Context context) {
		this(context, DEFAULT_FILE_NAME);
	}
	
	public SharePreferenceUtil() {
		this(OADroid.getInstance());
	}
	
	// clear
	public void clear() {
		// TODO Auto-generated method stub
		edit.clear().commit();
	}
	
	/**
	 * 保存图片锁是否开启状态
	 * */
	public void savePatternState(boolean flag) {
		edit.putBoolean(PATTERN_STATE, flag);
		edit.commit();
	}
	
	/**
	 * 获取图片锁是否开启状态
	 * */
	public boolean getPatternState() {
		if (null != sp) {
			return sp.getBoolean(PATTERN_STATE, false);
		}
		return false;
	}
	
	/**
	 * 保存图片锁密码
	 * */
	public void savePatternPwd(String pwd) {
		pwd = new String(Base64Utils.encode(pwd.getBytes()));
		String userId = LoginUtils.getInstance().getUserInfo().getUserId();
		edit.putString(PATTERN_PWD + userId, pwd);
		edit.commit();
	}
	
	/**
	 * 获取图片锁密码
	 * */
	public String getPatternPwd() {
		String userId = LoginUtils.getInstance().getUserInfo().getUserId();
		String pwd = sp.getString(PATTERN_PWD + userId, "");
		if (!StringUtils.isNullOrEmpty(pwd)) {
			pwd = new String(Base64Utils.decode(pwd));
		}
		return pwd;
	}
	
	public void saveInfo(String name, String value) {
		//Editor edit = sp.edit();
		if (!StringUtils.isNullOrEmpty(name)) {
			edit.putString(name, value);
			edit.commit();
		}
	}
	
	/**
	 * 将用户信息保存到文件中，用于自动登陆
	 * */
	public void saveUserInfo(UserInfo info) {
		if (null != info) {
			//Editor edit = sp.edit();
			edit.putString(USER_ID, info.getUserNo());
			edit.putString(USER_PASSWORD, info.getPassword());
			edit.putString(USER_NAME, info.getUserName());
			edit.commit();
		}
	}
	
	/**
	 * 获取文件中的用户信息
	 * */
	public UserInfo getUserInfo() {
		String userId = sp.getString(USER_ID, "");
		String pwd = sp.getString(USER_PASSWORD, "");
		String userName = sp.getString(USER_NAME, "");
		return new UserInfo(userId, pwd, userName);
	}
	
	/**
	 * 清除用户信息
	 * */
	public void clearUserInfo() {
		//Editor editor = sp.edit();
		edit.putString(USER_ID, "");
		edit.putString(USER_PASSWORD, "");
		edit.putBoolean(PATTERN_STATE, false);
		edit.putString(PATTERN_PWD, "");
		edit.commit();
	}
	
}
