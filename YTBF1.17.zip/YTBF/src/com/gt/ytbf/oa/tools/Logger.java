package com.gt.ytbf.oa.tools;

import android.util.Log;

public class Logger {

	public static void w(String tAG, String string) {
		Log.w(tAG, string);
	}
	
	public static void e(String tAG, String string) {
		Log.e(tAG, string);
	}
	
	public static void d(String tAG, String string) {
		Log.d(tAG, string);
	}
	
	public static void i(String tAG, String string) {
		Log.i(tAG, string);
	}
	
	public static void v(String tAG, String string) {
		Log.v(tAG, string);
	}

	public static void w(String tag, String string, Exception e) {
		Log.w(tag,string, e);
	}


	public static void e(String tag, String string, Exception e) {
		Log.e(tag,string, e);
	}

}
