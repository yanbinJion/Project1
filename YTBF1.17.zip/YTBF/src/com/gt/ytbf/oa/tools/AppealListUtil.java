package com.gt.ytbf.oa.tools;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Color;
import android.widget.ListView;

import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;

public class AppealListUtil {

	public static ListView setProperty(PullToRefreshListView pTListView) {
		pTListView.setPullRefreshEnabled(true);
		pTListView.setPullLoadEnabled(false);
		pTListView.setScrollLoadEnabled(true);
		ListView myAppealList = pTListView.getRefreshableView();
		myAppealList.setCacheColorHint(Color.TRANSPARENT);
		myAppealList.setFadingEdgeLength(0);
		myAppealList.setSelector(android.R.color.transparent);
		return myAppealList;
	}
	
	public static void checkDatas(List<ResultItem> resultItems,
			PullToRefreshListView pToRefreshListView,int index,String size) {
		float pageSize=Float.valueOf(size)/Constants.COMMON_PAGE_SIZE;
		if (BeanUtils.isEmpty(resultItems) || resultItems.size() < Constants.COMMON_PAGE_SIZE||index==pageSize) {
			// 已经全部加载完成，关闭UI组件的下拉加载更多功能
				pToRefreshListView.onPullDownRefreshComplete();
				pToRefreshListView.onPullUpRefreshComplete();
				pToRefreshListView.setHasMoreData(false);
		} else {
			// 还有更多数据，继续打开“下拉加载更多”功能
			pToRefreshListView.onPullDownRefreshComplete();
			pToRefreshListView.onPullUpRefreshComplete();
			pToRefreshListView.setHasMoreData(true);
		}
	}
	
	public static List<AppealCenterModel> getAppeal(List<ResultItem> resultItems) {
		List<AppealCenterModel> mAppeals=new ArrayList<AppealCenterModel>(resultItems.size());
			for (ResultItem item : resultItems) {
				String id = item.getString("ID");
				String companyName = item.getString("COMPANY_NAME");
				String content = item.getString("CONTENT");
				String appealType = item.getString("APPEALTYPE");
				String status = item.getString("STATUS");
				String area_name = item.getString("AREA_NAME");
				String create_time = item.getString("CREATE_TIME");
				String title = item.getString("TITLE");
				String bizId = item.getString("BIZID");
				String tzt=item.getString("TZT");
				mAppeals.add(new AppealCenterModel(id, title, companyName,
						area_name, appealType, content, status, create_time, bizId,tzt));
			}
		return mAppeals;
	}
	
}
