package com.gt.ytbf.oa.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * 字符串处理工具类
 * **/

public class StringUtils {
	
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");

	/** 判断字符串是否为空 */
	public static boolean isNullOrEmpty(String str) {
		if (null == str || str.length() <= 0) {
			return true;
		}
		return false;
	}
	
    /**
     * 根据流转换成字符串
     * @param [is] 流
     * @param [encodeing] 编码
     * @return
     * @throws Exception 
     */
    public static String convertStreamToString(InputStream is, String encodeing) throws Exception {
		StringBuffer out = new StringBuffer();

		byte[] b = new byte[4096];
		for (int n; (n = is.read(b)) != -1;) {
			out.append(new String(b, 0, n));
		}
		String clob =  new String(out.toString().getBytes(encodeing), "UTF-8");
		return clob; 
    }

    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line).append(LINE_SEPARATOR);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
            	if(null!=reader){
            		reader.close();
            	}
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
