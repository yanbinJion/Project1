package com.gt.ytbf.oa.tools;

import android.util.Log;

/** 
 * 控制APP软件日志的打印工具类
 * */

public class LogUtils {

	/** 通过配置是否输出调试日志，级别为错误的始终打印*/
	private static final boolean isDebug = true;
	private static final String tag = "LogUtils";
	
	public static void v(String log) {
		v(tag, log);
	}
	
	public static void v(String tag, String log) {
		if (isDebug) {
			Log.v(tag, log);
		}
	}
	
	public static void i(String log) {
		i(tag, log);
	}
	
	public static void i(String tag, String log) {
		if (isDebug) {
			Log.i(tag, log);
		}
	}
	
	public static void d(String log) {
		d(tag, log);
	}
	
	public static void d(String tag, String log) {
		if (isDebug) {
			Log.d(tag, log);
		}
	}
	
	public static void w(String log) {
		w(tag, log);
	}
	
	public static void w(String tag, String log) {
		if (isDebug) {
			Log.w(tag, log);
		}
	}
	
	public static void e(String log) {
		e(tag, log);
	}
	
	public static void e(String tag, String log) {
		Log.e(tag, log);
	}
	
	public static void w(String tag, String string, Exception e) {
		Log.w(tag,string, e);
	}

	public static void e(String tag, String string, Exception e) {
		Log.e(tag,string, e);
	}
	
}
