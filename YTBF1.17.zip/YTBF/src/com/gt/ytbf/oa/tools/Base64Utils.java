package com.gt.ytbf.oa.tools;

/**
 * base64 加解密工具类
 * */
public class Base64Utils {
	
	/**
	 * Base64 encode
	 * */
	public static String encode(byte[] input) {
		byte[] result = Base64.encode(input);
		return new String(result);
	}
	
	/**
	 * Base64 decode
	 * */
	public static byte[] decode(String string) {
		byte[] ret = Base64.decode(string);
		return ret;
	}
}
