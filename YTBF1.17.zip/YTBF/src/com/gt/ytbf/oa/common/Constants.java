package com.gt.ytbf.oa.common;

import java.util.HashMap;

import android.annotation.SuppressLint;
import android.os.Environment;


/**
 * Filename : Constants.java
 * 
 * @Description : 常量
 * @Author : 刘剑
 * @Version ：1.0
 * @Date ：2012-6-6 下午10:00:24
 */
public class Constants {

	public static final int BASE_WHAT_CODE = 998;
	
	/** 成功编码 */
	public static final String SUCCESS_CODE = "0";

	/** 失败编码 */
	public static final String LOGIN_FAIL_CODE = "-1";

	/** 返回XML的error code key */
	public static final String XML_ERROR_CODE_KEY = "Code";
	/** 返回XML的error message key */
	public static final String XML_ERROR_MESSAGE_KEY = "Descr";
	/** 返回XML的 tag */
	public static final String XML_TAG_KEY = "TAG_NAME";
	/** 返回XML的error tag key */
	public static final String XML_ERROR_TAG_KEY = "Error";
	/** 返回XML的textContent */
	public static final String XML_TEXT_CONTENT = "TEXT_CONTENT";
	/** 返回XML的children */
	public static final String XML_CHILDREN = "CHILDREN";

	/** 返回XML的decode key */
	public static final String XML_BASE64_KEY = "decode";
	/** 返回XML的base64 */
	public static final String XML_BASE64_VALUE = "base64";

	/** 系统请求数据源类型 */
	public static final String DATASOURCE_HTTP = "HTTP";
	public static final String DATASOURCE_HTTPS = "HTTPS";
	public static final String DATASOURCE_SOCKET = "SOCKET";
	public static final String DATASOURCE_SQLITE = "SQLITE";
	public static final String DATASOURCE_WEBSERVICE = "WEBSERVICE";
	public static final String DATASOURCE_IO = "IO";
	/**vpn是否打开 1，打开*/
	public static final String VPN_OPEN = "1";
	
	/**vpn返回*/
	public static final int WHAT_VPN = 6123;
	/** 默认的what */
	public static final int WHAT_DEFAULT = 0;

	public static final String DOCUMENT_TYPE = "DOCUMENT_TYPE";

	/** 公共常量：分页查询的每页的个数 */
	public static final int COMMON_PAGE_SIZE = 15;

	/** 手势密码登录 */
	public static final int GESTURES_OPTTYPE_LOGIN = 123;
	/** 手势密码设置 */
	public static final int GESTURES_OPTTYPE_SETPWD = 456;
	/** 手势密码修改 */
	public static final int GESTURES_OPTTYPE_MODPWD = 789;

	/**
	 * 标志：是否采用门户接口<br>
	 * （1）是为true，则采用门户的登录接口，但OA的StaffNo值需要转换<br>
	 * （2）否为false，则采用OA的登录接口，不需要转换StaffNo值
	 */
	public final static boolean IS_USER_PORTAL = false;

	/** 登陆门户：别忘了修改上面的IS_USER_PORTAL为true */
	public final static int WHAT_LOGIN_PORTAL = 2344;

	/** 登陆OA：别忘了修改上面的IS_USER_PORTAL为false */
	public final static int WHAT_LOGIN_OA = 2345;

	/** 门户登录转换：门户登录成功之后需要转换StaffNo值 */
	public final static int WHAT_LOGIN_CONVERT = 2346;
	
	/**
	 * 模块ID格式： 2位一级模块（底部，11起递增） + 2位二级模块（顶部，01起递增） + 2位三级模块（接顶部，01起递增） 示例说明：
	 * 110101：即11-01-01，对应为：待办事宜（底部）-待办（顶部）-待办列表（接顶部）
	 * 110102：即11-01-02，对应为：待办事宜（底部）-待阅（顶部）-待阅列表（接顶部）
	 * 120101：即12-01-01，对应为：公文管理（底部）-公文管理（顶部）-发文（接顶部）
	 * 120102：即12-01-02，对应为：公文管理（底部）-公文管理（顶部）-来文（接顶部）
	 * 120103：即12-01-03，对应为：公文管理（底部）-公文管理（顶部）-已办（接顶部）
	 */

	/** 待办事宜 */
	public final static int WHAT_REQUEST_WAIT = 1101;

	/** 公文管理 */
	public final static int WHAT_REQUEST_GWGL = 1201;

	/** 公文管理-发文 */
	public final static int WHAT_REQUEST_GWGL_FAWEN = 12011;
	/** 公文管理-来文 */
	public final static int WHAT_REQUEST_GWGL_LAIWEN = 12012;
	/** 公文管理-已办 */
	public final static int WHAT_REQUEST_GWGL_YIBAN = 12013;
	

	/** 会议管理 */
	public final static int WHAT_REQUEST_HYGL = 1301;
	/** 会议管理-主办会议 */
	public final static int WHAT_REQUEST_HYGL_ZBHY = 13011;
	/** 会议管理-会议通知 */
	public final static int WHAT_REQUEST_HYGL_HYTZ = 13012;
	/** 会议管理-已办会议 */
	public final static int WHAT_REQUEST_HYGL_YBHY = 13013;

	/** 公文传阅 */
	public final static int WHAT_REQUEST_GWCY = 1401;
	/** 公文传阅-待阅 */
	public final static int WHAT_REQUEST_GWCY_DY = 14011;
	/** 公文传阅-已阅 */
	public final static int WHAT_REQUEST_GWCY_YY = 14012;
	/** 公文传阅-已传 */
	public final static int WHAT_REQUEST_GWCY_YC = 14013;

	/** 常用意见 */
	public final static int WHAT_REQUEST_CYYJ = 1501;

	/** 通知公告 */
	public final static int WHAT_REQUEST_TZGG = 1601;

	/** 任务管理 */
	public final static int WHAT_REQUEST_RWGL = 1701;

	/** 综合查询 */
	public final static int WHAT_REQUEST_ZHCX = 1801;

	/** 待办事宜：待办 */
	public static final int OPT_TYPE_WAIT_DB = 110101;
	/** 待办事宜：待阅 */
	public static final int OPT_TYPE_WAIT_DY = 110102;

	/** 公文管理：发文 */
	public static final int OPT_TYPE_GWGL_FW = 120101;
	/** 公文管理：来文 */
	public static final int OPT_TYPE_GWGL_LW = 120102;
	/** 公文管理：已办 */
	public static final int OPT_TYPE_GWGL_YB = 120103;

	/** 会议管理：主办会议 */
	public static final int OPT_TYPE_HYGL_ZBHY = 130101;
	/** 会议管理：会议通知 */
	public static final int OPT_TYPE_HYGL_HYTZ = 130102;
	/** 会议管理：已办会议 */
	public static final int OPT_TYPE_HYGL_YBHY = 130103;
	/** 会议管理 */
	public static final String OPT_TYPE_HYGL = "OPT_TYPE_HYGL";
	

	/** 个人任务：任务信息 */
	public static final int OPT_TYPE_TASKINFO = 130111;
	/** 个人任务：事件信息 */
	public static final int OPT_TYPE_EVENTINFO = 130112;
	/** 个人任务：进度信息 */
	public static final int OPT_TYPE_JINDUINFO = 130113;
	/** 个人任务：办理信息 */
	public static final int OPT_TYPE_BANLIINFO = 130113;
	
    public static final int OPT_TYPE_SEND_TASK = 1790;
    public static final int OPT_TYPE_RECEIVER_TASK = 1791;

	/** 任务管理 */
    public static final int WHAT_REQUEST_SEND_TASK = 1710;
    public static final int WHAT_REQUEST_RECEIVER_TASK = 1711;
    public static final int WHAT_REQUEST_QUERY_TASK = 1712;
    public static final int WHAT_REQUEST_ADD_TASK = 1713;

	/** 公文传阅：待阅 */
	public static final int OPT_TYPE_GWCY_DY = 140101;
	/** 公文传阅：已阅 */
	public static final int OPT_TYPE_GWCY_YY = 140102;
	/** 公文传阅：已传 */
	public static final int OPT_TYPE_GWCY_YC = 140103;
	
	/** 调转到请假的详情 */
	public static final int OPT_TYPE_LEAVE_DETAIL = 190103;

	/** 待阅状态：1：待阅 */
	public static final int PASSREAD_STATE_NOTREAD = 1;
	/** 待阅状态：2：已阅 */
	public static final int PASSREAD_STATE_READ = 2;
	/** 待阅状态：3：已传 */
	public static final int PASSREAD_STATE_SPREAD = 3;

	/** 常用意见-操作类型：新增 */
	public static final int OPT_TYPE_CYYJ_ADD = 0;
	/** 常用意见-操作类型：编辑 */
	public static final int OPT_TYPE_CYYJ_EDIT = 1;
	/** 常用意见-操作类型：删除 */
	public static final int OPT_TYPE_CYYJ_DEL = 2;

	/** 通知公告-操作类型：新增 */
	public static final int OPT_TYPE_TZGG_ADD = 0;
	/** 通知公告-操作类型：编辑 */
	public static final int OPT_TYPE_TZGG_EDIT = 1;
	/** 通知公告-操作类型：删除 */
	public static final int OPT_TYPE_TZGG_DEL = 2;

	/** 请假操作类型 1添加 */
	public static final String LEAVE_OPERATETYPE_ADD = "1";

	/** 请假操作类型 2修改 */
	public static final String LEAVE_OPERATETYPE_MOD = "2";

	
	
	/** 程序数据保存的根路径 */
	public static final String SDString = Environment.getExternalStorageDirectory() + "";
	/** SDCARD 路径 */
	public final static String SDCARD_DIR = SDString.concat("/GTOA");
	/** 新建文档的路径 */
	public final static String SDCARD_DIR_NEW_FILE = SDCARD_DIR.concat("/filecache/");
	/** 网络下载公文的文件夹 */
	public final static String SDCARD_DIR_DOCUMENT_DOWNLOAD = SDCARD_DIR.concat("/doc_download/");
	/** 下载的附件图片文件夹 */
	public final static String	SDCARD_DIR_IMAGE_DOWNLOAD	= SDCARD_DIR.concat("/img_download/");
	/** 下载的附件文本文件夹 */
	public final static String	SDCARD_DIR_TXT_DOWNLOAD	= SDCARD_DIR.concat("/txt_download/");
	/** 创建临时文件 */
	public final static String SDCARD_TEMP_FILE = "temp.doc";

	/** 临时文件打开标识 */
	public final static String TAG_TEMP_FILE = "temp";
	
	
	public final static String WPS_READ_ONLY = "ReadOnly";
	public final static String WPS_NORMAL = "Normal";
	public final static String WPS_READMODE = "ReadMode";
	public final static String WPS_SAVE_ONLY = "SaveOnly";
	
	

	public static boolean UPLOAD_FLAG = false;
	
	/**领导政务查询类型 0:按政务查询*/
	public static int GOVAFFAIR_STATE_DEFAULT = 0; 
	
	/** 领导政务查询类型 1：按领导查询*/
	public static int GOVAFFAIR_STATE_LEADER = 1;
	
	/** 会议类型  [0:主办会议]*/
	public static int MEETING_TYPE_ZBHY = 0;
	
	/** 会议类型  [1:会议通知]*/
	public static int MEETING_TYPE_HYTZ = 1;
	
	
	/** 公共的公文ID */
	public static String DOCUMENT_ID;
	
	/** 流程编号ID */
	public static String TRACE_NO;
	
	/**锁屏*/
	public static String LOCK_SCREEN = "LOCK_SCREEN";
	
	/**来文编号 2006083005302033*/
	public static String LW_CODE = "2006083005302033";
	
	
	/** 消息通知 */
	public static final String SET_NOTIFY = "KEY_SET_NOTIFY";
	/** 提示音 */
	public static final String SET_TIPS = "KEY_SET_TIPS";
	/** 夜间仿打扰 */
	public static final String SET_NIGHT = "KEY_SET_NIGHT";
	
	
	/************  数据库名称和版本号  ************* */
	public static String DB_NAME = "gtoa.db";
	public static int DB_VERSION = 7;
	
	
	/**
	 * 下载最大数
	 */
	public final static int DOWNLOAD_MAX_SIZE = 5;
	
	/** 用于通知入口登陆判断 */
	public static boolean NOTIFY_LOGIN = false;
	/** 用于通知详情返回，进入MainActivity主界面 */
	public static boolean NOTIFY_DETAIL_BACK = false;
	
	
	
	// 0：年休假，1探亲假，2：婚假，3产假，4：丧假，5：病假，6：事假
	@SuppressWarnings("serial")
	@SuppressLint("UseSparseArrays")
	public static HashMap<Integer, String> LEAVE_TYPE_MAP = new HashMap<Integer, String>() {
		{
			put(0, "年休假");
			put(1, "探亲假");
			put(2, "婚假");
			put(3, "产假");
			put(4, "丧假");
			put(5, "病假");
			put(6, "事假");
		}
	};

}
