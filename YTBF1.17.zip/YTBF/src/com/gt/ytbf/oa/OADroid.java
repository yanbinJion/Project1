package com.gt.ytbf.oa;

import java.util.ArrayList;

import com.gt.ytbf.oa.tools.LogUtils;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

import android.app.Activity;
import android.app.Application;
import android.graphics.Bitmap;

/**
 * 类描述：<br>
 * 初始化程序 
 * @author  Fitz
 * @date    2014-08-14
 */
public class OADroid extends Application {
	
	public static OADroid mInstance;
	/**
	 *  保存當前已經啟動的activity集合
	 * */
	private ArrayList<Activity> activityCache = new ArrayList<Activity>();
	public static ImageLoader mImageLoader;
	public static DisplayImageOptions options;
	
	@Override
	public void onCreate() {
		super.onCreate();
		Thread.setDefaultUncaughtExceptionHandler(MyExceptionHandler.getInstance(getApplicationContext()));
		mImageLoader = ImageLoader.getInstance();
		options = new DisplayImageOptions.Builder()
		.showStubImage(R.drawable.ic_launcher)
		.showImageForEmptyUri(R.drawable.ic_launcher)
		.showImageOnFail(R.drawable.ic_launcher)
		.resetViewBeforeLoading(true).cacheOnDisc(true)
//		.imageScaleType(ImageScaleType.EXACTLY)
		.imageScaleType(ImageScaleType.IN_SAMPLE_INT)
		.bitmapConfig(Bitmap.Config.RGB_565)
		.displayer(new FadeInBitmapDisplayer(300)).build();
	}
	
	public static OADroid getInstance() {
		if (null == mInstance) {
			mInstance = new OADroid();
		}
		return mInstance;
	}
	
	public void addActivity(Activity act) {
		if(!activityCache.contains(act)) {
			LogUtils.d("OADroid", "addActivity " + act.getLocalClassName());
			activityCache.add(act);
		}
	}
	
	public void removeActivity(Activity act) {
		activityCache.remove(act);
	}
	
	/*
	 * 手动调用
	 * **/
	@Override  
	public void onTerminate() {  
		super.onTerminate();  
		for (Activity activity : activityCache) {
			if (null != activity && !activity.isFinishing()) {
				LogUtils.d("OADroid", "remove Activity " + activity.getLocalClassName());
				activity.finish();
			}
		}  
	}

}