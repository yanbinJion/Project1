package com.gt.ytbf.oa.bean;

public class MainIndustryInfo {
	
	public String zbmc;
	public String fl;
   //主营
	public String qygs;
	public String zbylj;
	public String zqntq;
	public String ztb;
	
	//工业
	public String gbylj;
	public String gqntq;
	public String gtb;
	//利税
	public String lbylj;
	public String lqntq;
	public String ltb;
	
	public String getZbmc() {
		return zbmc;
	}
	public void setZbmc(String zbmc) {
		this.zbmc = zbmc;
	}
	public String getFl() {
		return fl;
	}
	public void setFl(String fl) {
		this.fl = fl;
	}
	public String getQygs() {
		return qygs;
	}
	public void setQygs(String qygs) {
		this.qygs = qygs;
	}
	public String getZbylj() {
		return zbylj;
	}
	public void setZbylj(String zbylj) {
		this.zbylj = zbylj;
	}
	public String getZqntq() {
		return zqntq;
	}
	public void setZqntq(String zqntq) {
		this.zqntq = zqntq;
	}
	public String getZtb() {
		return ztb;
	}
	public void setZtb(String ztb) {
		this.ztb = ztb;
	}
	public String getGbylj() {
		return gbylj;
	}
	public void setGbylj(String gbylj) {
		this.gbylj = gbylj;
	}
	public String getGqntq() {
		return gqntq;
	}
	public void setGqntq(String gqntq) {
		this.gqntq = gqntq;
	}
	public String getGtb() {
		return gtb;
	}
	public void setGtb(String gtb) {
		this.gtb = gtb;
	}
	public String getLbylj() {
		return lbylj;
	}
	public void setLbylj(String lbylj) {
		this.lbylj = lbylj;
	}
	public String getLqntq() {
		return lqntq;
	}
	public void setLqntq(String lqntq) {
		this.lqntq = lqntq;
	}
	public String getLtb() {
		return ltb;
	}
	public void setLtb(String ltb) {
		this.ltb = ltb;
	}
	public MainIndustryInfo(String zbmc, String fl, String qygs, String zbylj, String zqntq, String ztb, String gbylj,
			String gqntq, String gtb, String lbylj, String lqntq, String ltb) {
		super();
		this.zbmc = zbmc;
		this.fl = fl;
		this.qygs = qygs;
		this.zbylj = zbylj;
		this.zqntq = zqntq;
		this.ztb = ztb;
		this.gbylj = gbylj;
		this.gqntq = gqntq;
		this.gtb = gtb;
		this.lbylj = lbylj;
		this.lqntq = lqntq;
		this.ltb = ltb;
	}
	
	public MainIndustryInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
