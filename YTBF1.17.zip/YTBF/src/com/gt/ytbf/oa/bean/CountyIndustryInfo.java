package com.gt.ytbf.oa.bean;

public class CountyIndustryInfo {
	public String zbmc;
//主营
	public String zndmb;
	public String ztbzz;
	public String zwc;
	public String zzllqspm;
	public String zwcmbjd;
	public String zzflqspm;
//利税
	public String lndmb;
	public String ltbzz;
	public String lwc;
	public String lwcmbjd;
	public String lzllqspm;
	public String lzflqspm;
//工业
	public String gndmb;
	public String gtbzz;
	public String gwc;
	public String gwcmbjd;
	public String gzllqspm;
	public String gzflqspm;
	
	public CountyIndustryInfo(String zbmc, String zndmb, String ztbzz, String zwc, String zzllqspm, String zwcmbjd,
			String zzflqspm, String lndmb, String ltbzz, String lwc, String lwcmbjd, String lzllqspm, String lzflqspm,
			String gndmb, String gtbzz, String gwc, String gwcmbjd, String gllqspm, String gzflqspm) {
		super();
		this.zbmc = zbmc;
		this.zndmb = zndmb;
		this.ztbzz = ztbzz;
		this.zwc = zwc;
		this.zzllqspm = zzllqspm;
		this.zwcmbjd = zwcmbjd;
		this.zzflqspm = zzflqspm;
		this.lndmb = lndmb;
		this.ltbzz = ltbzz;
		this.lwc = lwc;
		this.lwcmbjd = lwcmbjd;
		this.lzllqspm = lzllqspm;
		this.lzflqspm = lzflqspm;
		this.gndmb = gndmb;
		this.gtbzz = gtbzz;
		this.gwc = gwc;
		this.gwcmbjd = gwcmbjd;
		this.gzllqspm = gllqspm;
		this.gzflqspm = gzflqspm;
	}
	
	
	public String getZbmc() {
		return zbmc;
	}


	public void setZbmc(String zbmc) {
		this.zbmc = zbmc;
	}


	public String getZndmb() {
		return zndmb;
	}


	public void setZndmb(String zndmb) {
		this.zndmb = zndmb;
	}


	public String getZtbzz() {
		return ztbzz;
	}


	public void setZtbzz(String ztbzz) {
		this.ztbzz = ztbzz;
	}


	public String getZwc() {
		return zwc;
	}


	public void setZwc(String zwc) {
		this.zwc = zwc;
	}


	public String getZzllqspm() {
		return zzllqspm;
	}


	public void setZzllqspm(String zzllqspm) {
		this.zzllqspm = zzllqspm;
	}


	public String getZwcmbjd() {
		return zwcmbjd;
	}


	public void setZwcmbjd(String zwcmbjd) {
		this.zwcmbjd = zwcmbjd;
	}


	public String getZzflqspm() {
		return zzflqspm;
	}


	public void setZzflqspm(String zzflqspm) {
		this.zzflqspm = zzflqspm;
	}


	public String getLndmb() {
		return lndmb;
	}


	public void setLndmb(String lndmb) {
		this.lndmb = lndmb;
	}


	public String getLtbzz() {
		return ltbzz;
	}


	public void setLtbzz(String ltbzz) {
		this.ltbzz = ltbzz;
	}


	public String getLwc() {
		return lwc;
	}


	public void setLwc(String lwc) {
		this.lwc = lwc;
	}


	public String getLwcmbjd() {
		return lwcmbjd;
	}


	public void setLwcmbjd(String lwcmbjd) {
		this.lwcmbjd = lwcmbjd;
	}


	public String getLzllqspm() {
		return lzllqspm;
	}


	public void setLzllqspm(String lzllqspm) {
		this.lzllqspm = lzllqspm;
	}


	public String getLzflqspm() {
		return lzflqspm;
	}


	public void setLzflqspm(String lzflqspm) {
		this.lzflqspm = lzflqspm;
	}


	public String getGndmb() {
		return gndmb;
	}


	public void setGndmb(String gndmb) {
		this.gndmb = gndmb;
	}


	public String getGtbzz() {
		return gtbzz;
	}


	public void setGtbzz(String gtbzz) {
		this.gtbzz = gtbzz;
	}


	public String getGwc() {
		return gwc;
	}


	public void setGwc(String gwc) {
		this.gwc = gwc;
	}


	public String getGwcmbjd() {
		return gwcmbjd;
	}


	public void setGwcmbjd(String gwcmbjd) {
		this.gwcmbjd = gwcmbjd;
	}


	public String getGzllqspm() {
		return gzllqspm;
	}


	public void setGzllqspm(String gllqspm) {
		this.gzllqspm = gllqspm;
	}


	public String getGzflqspm() {
		return gzflqspm;
	}


	public void setGzflqspm(String gzflqspm) {
		this.gzflqspm = gzflqspm;
	}


	public CountyIndustryInfo() {
		super();
	}
	
	
}
