package com.gt.ytbf.oa.bean;

public class WholeElectricInfo {
	
	public String name;
	public String monthTotal;
	public String addTotal;
	public String commonRise;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMonthTotal() {
		return monthTotal;
	}
	public void setMonthTotal(String monthTotal) {
		this.monthTotal = monthTotal;
	}
	public String getAddTotal() {
		return addTotal;
	}
	public void setAddTotal(String addTotal) {
		this.addTotal = addTotal;
	}
	public String getCommonRise() {
		return commonRise;
	}
	public void setCommonRise(String commonRise) {
		this.commonRise = commonRise;
	}
	
	public WholeElectricInfo() {
		super();
	}
	
	public WholeElectricInfo(String name, String monthTotal, String addTotal, String commonRise) {
		super();
		this.name = name;
		this.monthTotal = monthTotal;
		this.addTotal = addTotal;
		this.commonRise = commonRise;
	}
	
	@Override
	public String toString() {
		return "WholeElectricInfo [name=" + name + ", monthTotal=" + monthTotal + ", addTotal=" + addTotal
				+ ", commonRise=" + commonRise + "]";
	}
	
	
}
