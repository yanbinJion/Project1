package com.gt.ytbf.oa.bean;

public class CountyEconomyInfo {

		public String yf;
	    //主营业务
		public String companyName;
		public String yearTaget;
		public String mouthComplete;
		public String addPercent;
		public String completePlan;
		//工业增加值
		public String gCompanyName;
		public String gYearTaget;
		public String gMouthComplete;
		public String gAddPercent;
		public String gCompletePlan;
		//利税
		public String lCompanyName;
		public String lYearTaget;
		public String lMouthComplete;
		public String lAddPercent;
		public String lCompletePlan;
		
		
		public String getYf() {
			return yf;
		}

		public void setYf(String yf) {
			this.yf = yf;
		}

		public CountyEconomyInfo() {
			super();
			// TODO Auto-generated constructor stub
		}

		public String getCompanyName() {
			return companyName;
		}

		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}

		public String getYearTaget() {
			return yearTaget;
		}

		public void setYearTaget(String yearTaget) {
			this.yearTaget = yearTaget;
		}

		public String getMouthComplete() {
			return mouthComplete;
		}

		public void setMouthComplete(String mouthComplete) {
			this.mouthComplete = mouthComplete;
		}

		public String getAddPercent() {
			return addPercent;
		}

		public void setAddPercent(String addPercent) {
			this.addPercent = addPercent;
		}

		public String getCompletePlan() {
			return completePlan;
		}

		public void setCompletePlan(String completePlan) {
			this.completePlan = completePlan;
		}

		public String getgCompanyName() {
			return gCompanyName;
		}

		public void setgCompanyName(String gCompanyName) {
			this.gCompanyName = gCompanyName;
		}

		public String getgYearTaget() {
			return gYearTaget;
		}

		public void setgYearTaget(String gYearTaget) {
			this.gYearTaget = gYearTaget;
		}

		public String getgMouthComplete() {
			return gMouthComplete;
		}

		public void setgMouthComplete(String gMouthComplete) {
			this.gMouthComplete = gMouthComplete;
		}

		public String getgAddPercent() {
			return gAddPercent;
		}

		public void setgAddPercent(String gAddPercent) {
			this.gAddPercent = gAddPercent;
		}

		public String getgCompletePlan() {
			return gCompletePlan;
		}

		public void setgCompletePlan(String gCompletePlan) {
			this.gCompletePlan = gCompletePlan;
		}

		public String getlCompanyName() {
			return lCompanyName;
		}

		public void setlCompanyName(String lCompanyName) {
			this.lCompanyName = lCompanyName;
		}

		public String getlYearTaget() {
			return lYearTaget;
		}

		public void setlYearTaget(String lYearTaget) {
			this.lYearTaget = lYearTaget;
		}

		public String getlMouthComplete() {
			return lMouthComplete;
		}

		public void setlMouthComplete(String lMouthComplete) {
			this.lMouthComplete = lMouthComplete;
		}

		public String getlAddPercent() {
			return lAddPercent;
		}

		public void setlAddPercent(String lAddPercent) {
			this.lAddPercent = lAddPercent;
		}

		public String getlCompletePlan() {
			return lCompletePlan;
		}

		public void setlCompletePlan(String lCompletePlan) {
			this.lCompletePlan = lCompletePlan;
		}

		public CountyEconomyInfo(String companyName, String yearTaget,
				String mouthComplete, String addPercent, String completePlan,
				String gCompanyName, String gYearTaget, String gMouthComplete,
				String gAddPercent, String gCompletePlan, String lCompanyName,
				String lYearTaget, String lMouthComplete, String lAddPercent,
				String lCompletePlan) {
			super();
			this.companyName = companyName;
			this.yearTaget = yearTaget;
			this.mouthComplete = mouthComplete;
			this.addPercent = addPercent;
			this.completePlan = completePlan;
			this.gCompanyName = gCompanyName;
			this.gYearTaget = gYearTaget;
			this.gMouthComplete = gMouthComplete;
			this.gAddPercent = gAddPercent;
			this.gCompletePlan = gCompletePlan;
			this.lCompanyName = lCompanyName;
			this.lYearTaget = lYearTaget;
			this.lMouthComplete = lMouthComplete;
			this.lAddPercent = lAddPercent;
			this.lCompletePlan = lCompletePlan;
		}

		@Override
		public String toString() {
			return "CountyEconomyInfo [companyName=" + companyName
					+ ", yearTaget=" + yearTaget + ", mouthComplete="
					+ mouthComplete + ", addPercent=" + addPercent
					+ ", completePlan=" + completePlan + ", gCompanyName="
					+ gCompanyName + ", gYearTaget=" + gYearTaget
					+ ", gMouthComplete=" + gMouthComplete + ", gAddPercent="
					+ gAddPercent + ", gCompletePlan=" + gCompletePlan
					+ ", lCompanyName=" + lCompanyName + ", lYearTaget="
					+ lYearTaget + ", lMouthComplete=" + lMouthComplete
					+ ", lAddPercent=" + lAddPercent + ", lCompletePlan="
					+ lCompletePlan + "]";
		}

		
		
		
}
