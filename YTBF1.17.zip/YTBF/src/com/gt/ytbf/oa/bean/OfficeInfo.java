package com.gt.ytbf.oa.bean;

/**
 * Created by ch on 2016/6/12.
 */
public class OfficeInfo {

    private int icon;
    private String content;
    private String data;
    private String id;
    private String destype;
    private String type;
    
    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDestype() {
		return destype;
	}

	public void setDestype(String destype) {
		this.destype = destype;
	}

	public OfficeInfo(int icon, String content, String data, String id,String destype,String type) {
		super();
		this.icon = icon;
		this.content = content;
		this.data = data;
		this.id = id;
		this.destype =destype;
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public OfficeInfo(int icon, String content, String data) {
        this.icon = icon;
        this.content = content;
        this.data = data;
    }

    public OfficeInfo() {
	}

	public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "OfficeInfo{" +
                "icon=" + icon +
                ", content='" + content + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}
