package com.gt.ytbf.oa.bean;

public class UpdateInfo {

	private String apkSize;
	private String content;
	private String dateTime;
	private String url;
	private String verCode;
	private String verName;
	private String isforce;
	public UpdateInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UpdateInfo(String apkSize, String content, String dateTime,
			String url, String verCode, String verName) {
		super();
		this.apkSize = apkSize;
		this.content = content;
		this.dateTime = dateTime;
		this.url = url;
		this.verCode = verCode;
		this.verName = verName;
	}
	public UpdateInfo(String apkSize, String content, String dateTime,
			String url, String verCode, String verName, String isforce) {
		super();
		this.apkSize = apkSize;
		this.content = content;
		this.dateTime = dateTime;
		this.url = url;
		this.verCode = verCode;
		this.verName = verName;
		this.isforce = isforce;
	}
	public String getApkSize() {
		return apkSize;
	}
	public void setApkSize(String apkSize) {
		this.apkSize = apkSize;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getVerCode() {
		return verCode;
	}
	public void setVerCode(String verCode) {
		this.verCode = verCode;
	}
	public String getVerName() {
		return verName;
	}
	public void setVerName(String verName) {
		this.verName = verName;
	}
	
	public String getIsforce() {
		return isforce;
	}
	public void setIsforce(String isforce) {
		this.isforce = isforce;
	}
	@Override
	public String toString() {
		return "UpdateInfo [apkSize=" + apkSize + ", content=" + content
				+ ", dateTime=" + dateTime + ", url=" + url + ", verCode="
				+ verCode + ", verName=" + verName + ",isforce=" + isforce + "]";
	}
		
	
	
}
