package com.gt.ytbf.oa.bean;

public class AppealChartInfo {

	public String count;
	public String status;
	public String typeName;
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public AppealChartInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AppealChartInfo(String count, String status, String typeName) {
		super();
		this.count = count;
		this.status = status;
		this.typeName = typeName;
	}
	@Override
	public String toString() {
		return "AppealChartInfo [count=" + count + ", status=" + status + ", typeName=" + typeName + "]";
	}
	
}
