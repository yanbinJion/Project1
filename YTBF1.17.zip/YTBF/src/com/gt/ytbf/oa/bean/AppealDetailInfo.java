package com.gt.ytbf.oa.bean;

public class AppealDetailInfo {
	
	private String appealId;
	private String appealTime;
	private String appealContent;
	private String appealNext;
	private String appealState;
	private String advice;
	private String type;
	private String leadContent;
	public AppealDetailInfo() {
	}
	public AppealDetailInfo(String id, String appealTime, String appealContent,
			String appealNext, String appealState,String advice, String type,String leadContent) {
		this.appealId = id;
		this.appealTime = appealTime;
		this.appealContent = appealContent;
		this.appealNext = appealNext;
		this.appealState = appealState;
		this.advice=advice;
		this.type = type;
		this.leadContent=leadContent;
	}
	
	public String getLeadContent() {
		return leadContent;
	}
	public void setLeadContent(String leadContent) {
		this.leadContent = leadContent;
	}
	public String getAppealId() {
		return appealId;
	}
	public void setAppealId(String appealId) {
		this.appealId = appealId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAppealTime() {
		return appealTime;
	}
	public void setAppealTime(String appealTime) {
		this.appealTime = appealTime;
	}
	public String getAppealContent() {
		return appealContent;
	}
	public void setAppealContent(String appealContent) {
		this.appealContent = appealContent;
	}
	public String getAppealNext() {
		return appealNext;
	}
	public void setAppealNext(String appealNext) {
		this.appealNext = appealNext;
	}
	public String getAppealState() {
		return appealState;
	}
	public void setAppealState(String appealState) {
		this.appealState = appealState;
	}
	
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	@Override
	public String toString() {
		return "AppealDetailInfo [appealTime=" + appealTime
				+ ", appealContent=" + appealContent + ", appealNext="
				+ appealNext + ", appealState=" + appealState + ", advice="
				+ advice + "]";
	}
	
	
	
	
	
}
