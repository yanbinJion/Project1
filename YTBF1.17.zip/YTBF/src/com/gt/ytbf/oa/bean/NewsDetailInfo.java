package com.gt.ytbf.oa.bean;

public class NewsDetailInfo {

	private String id;
	private String type;
	private String title;
	private String summary;
	private String ctime;
	private String content;
	private String createbt;
	public NewsDetailInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NewsDetailInfo(String id, String type, String title, String summary,
			String ctime, String content, String createbt) {
		super();
		this.id = id;
		this.type = type;
		this.title = title;
		this.summary = summary;
		this.ctime = ctime;
		this.content = content;
		this.createbt = createbt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getCtime() {
		return ctime;
	}
	public void setCtime(String ctime) {
		this.ctime = ctime;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreatebt() {
		return createbt;
	}
	public void setCreatebt(String createbt) {
		this.createbt = createbt;
	}
	@Override
	public String toString() {
		return "NewsDetailInfo [id=" + id + ", type=" + type + ", title="
				+ title + ", summary=" + summary + ", ctime=" + ctime
				+ ", content=" + content + ", createbt=" + createbt + "]";
	}
	
}
