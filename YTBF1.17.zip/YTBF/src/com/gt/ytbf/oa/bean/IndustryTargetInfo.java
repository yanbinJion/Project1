package com.gt.ytbf.oa.bean;

public class IndustryTargetInfo {
	//主营业务
	public String company;
	public String monthData;
	public String sortOne;
	public String addPercent;
	public String sortTwo;
	public String completePlan;
	//工业增加值
	public String gMonthData;
	public String gSortOne;
	public String gAddPercent;
	public String gSortTwo;
	public String gCompletePlan;
	//利税
	public String lMonthData;
	public String lSortOne;
	public String lAddPercent;
	public String lSortTwo;
	public String lCompletePlan;
	
	public String getgMonthData() {
		return gMonthData;
	}
	public void setgMonthData(String gMonthData) {
		this.gMonthData = gMonthData;
	}
	public String getgSortOne() {
		return gSortOne;
	}
	public void setgSortOne(String gSortOne) {
		this.gSortOne = gSortOne;
	}
	public String getgAddPercent() {
		return gAddPercent;
	}
	public void setgAddPercent(String gAddPercent) {
		this.gAddPercent = gAddPercent;
	}
	public String getgSortTwo() {
		return gSortTwo;
	}
	public void setgSortTwo(String gSortTwo) {
		this.gSortTwo = gSortTwo;
	}
	public String getgCompletePlan() {
		return gCompletePlan;
	}
	public void setgCompletePlan(String gCompletePlan) {
		this.gCompletePlan = gCompletePlan;
	}
	public String getlMonthData() {
		return lMonthData;
	}
	public void setlMonthData(String lMonthData) {
		this.lMonthData = lMonthData;
	}
	public String getlSortOne() {
		return lSortOne;
	}
	public void setlSortOne(String lSortOne) {
		this.lSortOne = lSortOne;
	}
	public String getlAddPercent() {
		return lAddPercent;
	}
	public void setlAddPercent(String lAddPercent) {
		this.lAddPercent = lAddPercent;
	}
	public String getlSortTwo() {
		return lSortTwo;
	}
	public void setlSortTwo(String lSortTwo) {
		this.lSortTwo = lSortTwo;
	}
	public String getlCompletePlan() {
		return lCompletePlan;
	}
	public void setlCompletePlan(String lCompletePlan) {
		this.lCompletePlan = lCompletePlan;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getMonthData() {
		return monthData;
	}
	public void setMonthData(String monthData) {
		this.monthData = monthData;
	}
	public String getSortOne() {
		return sortOne;
	}
	public void setSortOne(String sortOne) {
		this.sortOne = sortOne;
	}
	public String getAddPercent() {
		return addPercent;
	}
	public void setAddPercent(String addPercent) {
		this.addPercent = addPercent;
	}
	public String getSortTwo() {
		return sortTwo;
	}
	public void setSortTwo(String sortTwo) {
		this.sortTwo = sortTwo;
	}
	public String getCompletePlan() {
		return completePlan;
	}
	public void setCompletePlan(String completePlan) {
		this.completePlan = completePlan;
	}
	
	@Override
	public String toString() {
		return "IndustryTargetInfo [company=" + company + ", monthData=" + monthData + ", sortOne=" + sortOne
				+ ", addPercent=" + addPercent + ", sortTwo=" + sortTwo + ", completePlan=" + completePlan + "]";
	}
	
	public IndustryTargetInfo() {
		super();
	}
	
	public IndustryTargetInfo(String company, String monthData, String sortOne, String addPercent, String sortTwo,
			String completePlan) {
		super();
		this.company = company;
		this.monthData = monthData;
		this.sortOne = sortOne;
		this.addPercent = addPercent;
		this.sortTwo = sortTwo;
		this.completePlan = completePlan;
	}
	
	
	
}
