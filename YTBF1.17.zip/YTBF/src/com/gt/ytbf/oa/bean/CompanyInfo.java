package com.gt.ytbf.oa.bean;

/**
 * Created by ch on 2016/6/14.
 */
public class CompanyInfo {

    private int icon;
    private String name;
    private String registerTime;
    private String registerMoney;
    private String allMoney;
    private String owenershipType;
    private String orgCode;
    private String bankCreditGrating;
    private String employeesNum;
    private String contact;
    private String manager;
    private String address;
    private String phone;
    private String company_profile;
	public CompanyInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CompanyInfo(int icon, String name, String address, String phone,String orgCode) {
		super();
		this.icon = icon;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.orgCode=orgCode;
	}
	
	
	
	public CompanyInfo(String name, String registerTime, String registerMoney,
			String allMoney, String owenershipType, String orgCode,
			String bankCreditGrating, String employeesNum, String contact,
			String manager, String address,String company_profile) {
		super();
		this.name = name;
		this.registerTime = registerTime;
		this.registerMoney = registerMoney;
		this.allMoney = allMoney;
		this.owenershipType = owenershipType;
		this.orgCode = orgCode;
		this.bankCreditGrating = bankCreditGrating;
		this.employeesNum = employeesNum;
		this.contact = contact;
		this.manager = manager;
		this.address = address;
		this.company_profile=company_profile;
	}
	public int getIcon() {
		return icon;
	}
	public void setIcon(int icon) {
		this.icon = icon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(String registerTime) {
		this.registerTime = registerTime;
	}
	public String getRegisterMoney() {
		return registerMoney;
	}
	public void setRegisterMoney(String registerMoney) {
		this.registerMoney = registerMoney;
	}
	public String getAllMoney() {
		return allMoney;
	}
	public void setAllMoney(String allMoney) {
		this.allMoney = allMoney;
	}
	public String getOwenershipType() {
		return owenershipType;
	}
	public void setOwenershipType(String owenershipType) {
		this.owenershipType = owenershipType;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getBankCreditGrating() {
		return bankCreditGrating;
	}
	public void setBankCreditGrating(String bankCreditGrating) {
		this.bankCreditGrating = bankCreditGrating;
	}
	public String getEmployeesNum() {
		return employeesNum;
	}
	public void setEmployeesNum(String employeesNum) {
		this.employeesNum = employeesNum;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	
	public String getCompany_profile() {
		return company_profile;
	}
	public void setCompany_profile(String company_profile) {
		this.company_profile = company_profile;
	}
	@Override
	public String toString() {
		return "CompanyInfo [icon=" + icon + ", name=" + name
				+ ", registerTime=" + registerTime + ", registerMoney="
				+ registerMoney + ", allMoney=" + allMoney
				+ ", owenershipType=" + owenershipType + ", orgCode=" + orgCode
				+ ", bankCreditGrating=" + bankCreditGrating
				+ ", employeesNum=" + employeesNum + ", contact=" + contact
				+ ", manager=" + manager + ", address=" + address + ", phone="
				+ phone + "]";
	}
	

    
}
