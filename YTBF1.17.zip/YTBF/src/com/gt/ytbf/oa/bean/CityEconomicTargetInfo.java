package com.gt.ytbf.oa.bean;

public class CityEconomicTargetInfo {

	public String yf;
	public String city;
	public String companyTotal;
	// 工业增加值	
	public String monthData;
	public String addPercent;
	public String completePlan;
	// 主营业务
	public String zMonthData;
	public String zAddPercent;
	public String zCompletePlan;
	
	// 利税
	public String lMonthData;
	public String lAddPercent;
	
	public CityEconomicTargetInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CityEconomicTargetInfo(String yf, String city, String companyTotal,
			String monthData, String addPercent, String completePlan,
			String zMonthData, String zAddPercent, String zCompletePlan,
			String lMonthData, String lAddPercent) {
		super();
		this.yf = yf;
		this.city = city;
		this.companyTotal = companyTotal;
		this.monthData = monthData;
		this.addPercent = addPercent;
		this.completePlan = completePlan;
		this.zMonthData = zMonthData;
		this.zAddPercent = zAddPercent;
		this.zCompletePlan = zCompletePlan;
		this.lMonthData = lMonthData;
		this.lAddPercent = lAddPercent;
	}
	public String getYf() {
		return yf;
	}
	public void setYf(String yf) {
		this.yf = yf;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCompanyTotal() {
		return companyTotal;
	}
	public void setCompanyTotal(String companyTotal) {
		this.companyTotal = companyTotal;
	}
	public String getMonthData() {
		return monthData;
	}
	public void setMonthData(String monthData) {
		this.monthData = monthData;
	}
	public String getAddPercent() {
		return addPercent;
	}
	public void setAddPercent(String addPercent) {
		this.addPercent = addPercent;
	}
	public String getCompletePlan() {
		return completePlan;
	}
	public void setCompletePlan(String completePlan) {
		this.completePlan = completePlan;
	}
	public String getzMonthData() {
		return zMonthData;
	}
	public void setzMonthData(String zMonthData) {
		this.zMonthData = zMonthData;
	}
	public String getzAddPercent() {
		return zAddPercent;
	}
	public void setzAddPercent(String zAddPercent) {
		this.zAddPercent = zAddPercent;
	}
	public String getzCompletePlan() {
		return zCompletePlan;
	}
	public void setzCompletePlan(String zCompletePlan) {
		this.zCompletePlan = zCompletePlan;
	}
	public String getlMonthData() {
		return lMonthData;
	}
	public void setlMonthData(String lMonthData) {
		this.lMonthData = lMonthData;
	}
	public String getlAddPercent() {
		return lAddPercent;
	}
	public void setlAddPercent(String lAddPercent) {
		this.lAddPercent = lAddPercent;
	}
	@Override
	public String toString() {
		return "CityEconomicTargetInfo [yf=" + yf + ", city=" + city
				+ ", companyTotal=" + companyTotal + ", monthData=" + monthData
				+ ", addPercent=" + addPercent + ", completePlan="
				+ completePlan + ", zMonthData=" + zMonthData
				+ ", zAddPercent=" + zAddPercent + ", zCompletePlan="
				+ zCompletePlan + ", lMonthData=" + lMonthData
				+ ", lAddPercent=" + lAddPercent + "]";
	}
	
	
	
}
