package com.gt.ytbf.oa.bean;

/**
 * Created by ch on 2016/6/17.
 */
public class WarningInfo {
    private String companyName;
    private int icon;
    private String indNow;
    private String busNow;
    private String tax;
    private String profit;
    private String year;
    private String month;
    
    public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getIndNow() {
		return indNow;
	}

	public void setIndNow(String indNow) {
		this.indNow = indNow;
	}

	public String getBusNow() {
		return busNow;
	}

	public void setBusNow(String busNow) {
		this.busNow = busNow;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getProfit() {
		return profit;
	}

	public void setProfit(String profit) {
		this.profit = profit;
	}

	public WarningInfo(String companyName, int icon) {
        this.companyName = companyName;
        this.icon = icon;
    }

    public WarningInfo() {
	}

	public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

	@Override
	public String toString() {
		return "WarningInfo [companyName=" + companyName + ", icon=" + icon
				+ ", indNow=" + indNow + ", busNow=" + busNow + ", tax=" + tax
				+ ", profit=" + profit + ", year=" + year + ", month=" + month
				+ "]";
	}
    
}
