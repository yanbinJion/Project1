package com.gt.ytbf.oa.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.SharePreferenceUtil;
import com.gt.ytbf.oa.ui.view.ContentView;
import com.gt.ytbf.oa.ui.view.GestureDrawl.GestureCallBack;


/**
 * Filename : SetGesturesPasswordActivity
 * 
 * @Description : 设置手势密码
 */
public class SetGesturesPasswordActivity extends BaseActivity {

	private FrameLayout gesturespwdLayout;

	private ContentView content;

	private TextView msgView;
	
	/** 操作次数 */
	private int successNumber = 1;

	//忘记手势密码进入
	private SharePreferenceUtil spUtils;
	
	private boolean isModifyPwd;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gestures_password);
		((RelativeLayout) findViewById(R.id.user_name_layout)).setVisibility(View.GONE);
		findViewById(R.id.tv_forget_pass).setVisibility(View.GONE);
		findViewById(R.id.tv_change_user).setVisibility(View.GONE);
		
		spUtils = new SharePreferenceUtil(this);
		gesturespwdLayout = (FrameLayout) findViewById(R.id.gesturespwd_layout);
		msgView = (TextView) findViewById(R.id.pwdMsgView);
		int option = Constants.GESTURES_OPTTYPE_SETPWD;
		if (!BeanUtils.isNullOrEmpty(spUtils.getPatternPwd())) {
			isModifyPwd = true;
			option = Constants.GESTURES_OPTTYPE_LOGIN;
			msgView.setText(R.string.gestures_current_password);
		} else {
			msgView.setText(R.string.gesturespassword_seting_title);
		}
		// 初始化一个显示各个点的viewGroup
		content = new ContentView(option, this,
				spUtils.getPatternPwd(), new GestureCallBack() {
					@Override
					public void checkedSuccess() {
						if (isModifyPwd) {
							isModifyPwd = false;
							msgView.setText(R.string.gesturespassword_mod_oldsuccess);
							content.setType(Constants.GESTURES_OPTTYPE_MODPWD);
						} else {
							msgView.setText(R.string.gesturespassword_set_again);
							successNumber++;
						}
						content.clearAll();//清除页面所有的画线
						msgView.setTextColor(Color.parseColor(getString(R.color.white)));
					}

					@Override
					public void checkedFail() {
						// 如果等于1，表示密码第一次设置就没有成功过，就失败，提示：必须大于几个点
						if (isModifyPwd) {
							msgView.setText(R.string.gesturespassword_mod_oldfail);
						} else if (successNumber == 1) {
							msgView.setText(R.string.gesturespassword_min_points);
						} else {
							msgView.setText(R.string.gesturespassword_set_notsame);
							successNumber = 1;
						}
						msgView.setTextColor(Color.parseColor(getString(R.color.red)));
					}

					@Override
					public void checkedSuccessBack(String param) {
						if (!BeanUtils.isNullOrEmpty(spUtils.getPatternPwd())) {
							msgView.setText(R.string.gesturespassword_mod_success);
						} else {
							msgView.setText(R.string.gesturespassword_set_success);
						}
						msgView.setTextColor(Color.parseColor(getString(R.color.white)));
						spUtils.savePatternPwd(param);
						finish();
					}
				});
		// 设置手势解锁显示到哪个布局里面
		content.setParentView(gesturespwdLayout);
	}

}
