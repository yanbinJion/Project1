package com.gt.ytbf.oa.ui;
	
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import android.R.integer;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.RollItem;
import com.gt.ytbf.oa.common.LoadDataListener;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AdInfo;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.AppealListUtil;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.adapter.AppealAdapter;
import com.gt.ytbf.oa.ui.adapter.FunctionAdapter;
import com.gt.ytbf.oa.ui.adapter.ViewPagerAdapter;
import com.gt.ytbf.oa.ui.view.AutoRollLayout;
import com.gt.ytbf.oa.ui.view.ImageViewPagerHelper;
import com.gt.ytbf.oa.ui.view.MyScrollView;
import com.gt.ytbf.oa.ui.view.ImageViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.view.MyScrollView.OnScrollListener;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;
import com.gt.ytbf.oa.ui.view.NoScrollGridView;
import com.gt.ytbf.oa.ui.view.NoScrollListView;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
	
/**
 * 首页
 * */
public class MainEntryActivityZN extends BaseActivity implements LoadDataListener{
	
	private final String TAG = "MainEntryActivity";
	private final String FIRST = "11";
    private final String SECOND = "12";
    private final String THIRD = "13";
    private final String FOURTH = "14";
    private static final int TYPE = 3;
    private static final int FIRST_PAGE = 1;
    private static final int GET_WAITPROCESS=0;
	private static final int GET_PROCESSED=1;
	private static final int GET_PROCESSOVER=2;
    private int firstIndex = 1;
	private int secondIndex = 1;
	private int thirdIndex = 1;
	private int fourthIndex = 1;
	private ViewPager viewPager;
	/**
	 * 图片轮播适配器
	 * */
	private ViewPagerAdapter adapter;
	/**
	 * 功能列表
	 * */
	private NoScrollGridView mGridView;
	/**
	 * 功能列表适配器
	 * */
	private FunctionAdapter mGridAdapter;
    private LinearLayout mTabLayout;
    private ImageViewPagerHelper viewHelper;
	/**
	 * 图片轮播资源
	 * */
	private List<AdInfo> list = new ArrayList<AdInfo>();
	
	/**
	 * 定时循环显示图片
	 * */
	
	private String[] strings;
	private int[] res;
	private List<View> views;
	private PullToRefreshListView waitProcessView;
	private PullToRefreshListView processingView;
	private PullToRefreshListView processedView;
	private PullToRefreshListView processOverView;
	private AppealAdapter waitProcessAdapter;
    private AppealAdapter processingAdapter;
    private AppealAdapter processedAdapter;
    private AppealAdapter processOverAdapter;
	
    
    
	private AutoRollLayout mAutoRollLayout;
	private int mTabLayoutTop;
	private LinearLayout linearlayout;
	private LinearLayout linearlayout_gone;
    
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_entry);
		initTitleBar(R.string.tab_home_title, null, null);
        mTabLayout = (LinearLayout) findViewById(R.id.main_tab_layout);
        viewHelper = new ImageViewPagerHelper(this, mTabLayout);
        viewHelper.onCreate(savedInstanceState);
        setMainNavigator();
		initView();
	}
	
	private void initView() {
		
		
		mAutoRollLayout = (AutoRollLayout) findViewById(R.id.autorolllayout);
		MainActivity.getInstance().setRollLayout(mAutoRollLayout);
//		MyScrollView myScrollView = (MyScrollView) findViewById(R.id.myScrollView);
//		myScrollView.setOnScrollListener(this);
		linearlayout = (LinearLayout) findViewById(R.id.linearlayout);
		linearlayout_gone = (LinearLayout) findViewById(R.id.linearlayout_gone);
		
		View view0 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view1 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view2 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view3 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view4 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		
			strings = new String[] {"待受理", "已受理", "已办结", "诉求中心"};
			res = new int[] {R.drawable.dsl_selector, R.drawable.ysl_selector, R.drawable.ybj_selector, R.drawable.qyxx_selector};
			views = new ArrayList<View>();
			views.add(view0);
//			views.add(view1);
			views.add(view2);
			views.add(view3);
			views.add(view4);
			
       
        waitProcessView = (PullToRefreshListView) view0.findViewById(R.id.common_pullToRefresh_list);
        waitProcessList = AppealListUtil.setProperty(waitProcessView);
        waitProcessView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            // 下拉刷新数据
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		firstIndex=1;
            		waitProcesses.clear();
            		getDatas(FIRST, firstIndex, callBack,GET_WAITPROCESS);
            	}else {
            		waitProcessView.onPullDownRefreshComplete();
				}
            }

            // 上拉加载下一页的数据
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		firstIndex+=1;
            		getDatas(FIRST, firstIndex, callBack,GET_WAITPROCESS);
            	}else {
            		waitProcessView.onPullUpRefreshComplete();
				}
            }
        });
//        processingView = (PullToRefreshListView) view1.findViewById(R.id.common_pullToRefresh_list);
//        processingList = setProperty(processingView);
        processedView = (PullToRefreshListView) view2.findViewById(R.id.common_pullToRefresh_list);
        processedList = AppealListUtil.setProperty(processedView);
        processedView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            // 下拉刷新数据
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		thirdIndex=1;
            		processedes.clear();
            		getDatas(THIRD, thirdIndex, callBack,GET_PROCESSED);
            	}else {
            		processedView.onPullDownRefreshComplete();
				}
            }

            // 上拉加载下一页的数据
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		thirdIndex+=1;
            		getDatas(THIRD, thirdIndex, callBack,GET_PROCESSED);
            	}else {
            		processedView.onPullUpRefreshComplete();
				}
            }
        });
        
        processOverView = (PullToRefreshListView) view3.findViewById(R.id.common_pullToRefresh_list);
        processOverList = AppealListUtil.setProperty(processOverView);
        processOverView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            // 下拉刷新数据
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		fourthIndex=1;
            		processOvers.clear();
            		getDatas(FOURTH, fourthIndex, callBack,GET_PROCESSOVER);
            	}else {
            		processOverView.onPullDownRefreshComplete();
				}
            }

            // 上拉加载下一页的数据
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		fourthIndex+=1;
            		getDatas(FOURTH, fourthIndex, callBack,GET_PROCESSOVER);
            	}else {
            		processOverView.onPullUpRefreshComplete();
				}
            }
        });
        updateUI();
        
	}
	
	protected void getDatas(String index, int pageIndex,
			IRequestCallBack callBack,int what) {
		invoke.invokeWidthDialog(OAInterface.getAppeals(index, pageIndex),callBack,what);
	}

	private void updateUI() {
		//加载轮播图数据
//		 List<RollItem> rollItemList=new ArrayList<RollItem>();
//		 rollItemList.add(new RollItem("全市降低企业成本优化发展环境政策宣讲会召开",R.drawable.main_homebanner_01));
//		 rollItemList.add(new RollItem("洪礼和赴挂点联系园区调研并作政策宣讲动员",R.drawable.news_02));
//		 rollItemList.add(new RollItem("陈兴超到高新区调研", R.drawable.main_homebanner_03));
//		 mAutoRollLayout.setData(rollItemList);
		List<ImageViewPagerHelper.PagerModel> pages = new ArrayList<ImageViewPagerHelper.PagerModel>();
        for (int i = 0; i < strings.length; i++) {
            pages.add(viewHelper.new PagerModel(strings[i], res[i], views.get(i), null));
            
        }
        
        viewHelper.showViews(pages,TYPE);
//       loadData();
        
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
						ResultItem countItem = (ResultItem) item.get("lstCount");
						parserUnread(countItem);
						List<ResultItem> resultItems=item.getItems("data");
						if (what==GET_WAITPROCESS) {
							showWaitProcessList(resultItems);
						}else if (what==GET_PROCESSED) {
							showProcessedList(resultItems);
						}else if (what==GET_PROCESSOVER) {
							showprocessOverList(resultItems);
						}
					}
				}
		}
		
	};
//	private IRequestCallBack secondCallBack = new BaseRequestCallBack() {
//		
//		@Override
//		public void process(HttpResponse response, int what) {
//			ResultItem item = response.getResultItem(ResultItem.class);
//			if (checkResult(item)) {
//				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
//					List<ResultItem> resultItems=item.getItems("data");
//					showProcessingList(resultItems);
//				}
//			}
//		}
//		
//	};
	
	private void parserUnread(ResultItem item) {
		if (null != item) {
			String wait = item.getString("znbmdsl");
			String processed = item.getString("znbmysl");
			String over = item.getString("znbmybj");
			int[] count = {
					StringUtils.isNullOrEmpty(wait) ? 0 : Integer.valueOf(wait),
					StringUtils.isNullOrEmpty(processed) ? 0 : Integer.valueOf(processed),
					StringUtils.isNullOrEmpty(over) ? 0 : Integer.valueOf(over) };
			viewHelper.updateText(count);
		}
	}
	 private void loadDatas(int position) {
			invoke = new InvokeHelper(this);
			 if (0 == position) {
				 firstIndex=1;
				 if (!BeanUtils.isEmpty(waitProcesses)) {
					 waitProcesses.clear();
				 }
				 invoke.invoke(OAInterface.getAppeals(FIRST, FIRST_PAGE),callBack,GET_WAITPROCESS);
			 } else if (1 == position) {
				 thirdIndex=1;
				 if (!BeanUtils.isEmpty(processedes)) {
					 processedes.clear();
				 }
				 invoke.invoke(OAInterface.getAppeals(THIRD,FIRST_PAGE), callBack,GET_PROCESSED);
			 } else  if (2 == position){
				 fourthIndex=1;
				 if (!BeanUtils.isEmpty(processOvers)) {
					 processOvers.clear();
				 }
				 invoke.invoke(OAInterface.getAppeals(FOURTH,FIRST_PAGE), callBack,GET_PROCESSOVER);
			}
			 
			 
		 }
	private List<AppealCenterModel> waitProcesses = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> processings = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> processedes = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> processOvers = new ArrayList<AppealCenterModel>();
	private ListView waitProcessList;
	private ListView processingList;
	private ListView processedList;
	private ListView processOverList;
	private InvokeHelper invoke;
	//列表个数，默认为0
	private String fourthSize="0";
	private String thirdSize="0";
	private String firstSize="0";
	
	protected void showprocessOverList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,processOverView,fourthIndex,fourthSize);
			processOverAdapter.setData(processOvers);
			return;
		}
		processOvers.addAll(AppealListUtil.getAppeal(resultItems));
		fourthSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == processOverAdapter) {
	            processOverAdapter = new AppealAdapter(this, processOvers);
	            processOverList.setAdapter(processOverAdapter);
	            processOverList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (processOvers.size() > position) {
							Intent intent = new Intent(new Intent(MainEntryActivityZN.this,AppealCenterActivity.class));
							Bundle bundle = new Bundle();
							bundle.putSerializable("appealInfo", processOvers.get(position));
							intent.putExtras(bundle);
							startActivity(intent);
						}
					}
				});
	            
	        } else {
	            processOverAdapter.setData(processOvers);
	        }
		AppealListUtil.checkDatas(resultItems,processOverView,fourthIndex,fourthSize);
	}

	protected void showProcessedList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,processedView,thirdIndex,thirdSize);
			processedAdapter.setData(processedes);
			return;
		}
		processedes.addAll(AppealListUtil.getAppeal(resultItems));
		thirdSize = resultItems.get(0).getString("ID_PR_ALL");
		 if (null == processedAdapter) {
	            processedAdapter = new AppealAdapter(this, processedes);
	            processedList.setAdapter(processedAdapter);
	            processedList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (processedes.size() <= position) {
							return;
						}
						Intent intent = new Intent(new Intent(MainEntryActivityZN.this,AppealCenterActivity.class));
						Bundle bundle = new Bundle();
						bundle.putSerializable("appealInfo", processedes.get(position));
						bundle.putBoolean("isHandler", true);
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
	            
	        } else {
	            processedAdapter.setData(processedes);
	        }
		 AppealListUtil.checkDatas(resultItems,processedView,thirdIndex,thirdSize);
	}

//	protected void showProcessingList(List<ResultItem> resultItems) {
//		if (BeanUtils.isEmpty(resultItems)) {
//			return;
//		}
//		
//		 for (ResultItem item : resultItems) {
//			String id = item.getString("ID");
//			String companyName = item.getString("COMPANY_NAME");
//			String content = item.getString("CONTENT");
//			String appealType = item.getString("APPEALTYPE");
//			String status = item.getString("STATUS");
//			String area_name = item.getString("AREA_NAME");
//			String create_time = item.getString("CREATE_TIME");
//			String title = item.getString("TITLE");
//			String bizId = item.getString("BIZID");
//			allId = item.getString("ID_PR_ALL");
//			AppealCenterModel appeal = new AppealCenterModel(id,title,companyName, area_name, appealType, content,status,create_time,bizId);
//			appeal.setTzt(item.getString("TZT"));
//			processings.add(appeal);
//		}
//		 viewHelper.updateText(1, Integer.valueOf(allId));
//		 if (null == processingAdapter) {
//	            processingAdapter = new AppealAdapter(this, processings);
//	            processingList.setAdapter(processingAdapter);
//	            processingList.setOnItemClickListener(new OnItemClickListener() {
//
//					@Override
//					public void onItemClick(AdapterView<?> parent, View view,
//							int position, long id) {
//						if (processings.size() <= position) {
//							return;
//						}
//						Intent intent = new Intent(new Intent(MainEntryActivityZN.this,AppealCenterActivity.class));
//						Bundle bundle = new Bundle();
//						bundle.putSerializable("appealInfo", processings.get(position));
//						bundle.putBoolean("isHandler", true);
//						intent.putExtras(bundle);
//						startActivity(intent);
//					}
//				});
//	            processingView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
//		            // 下拉刷新数据
//		            @Override
//		            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
//		            	secondIndex=1;
//		            	processings.clear();
//		            	invoke.invokeWidthDialog(OAInterface.getAppeals(SECOND,secondIndex),secondCallBack );
//		            	processingView.onPullDownRefreshComplete();
//		            	Toast.makeText(MainEntryActivityZN.this, "刷新成功", Toast.LENGTH_SHORT).show();
//		            }
//
//		            // 上拉加载下一页的数据
//		            @Override
//		            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
//		            	secondIndex+=1;
//		            	invoke.invokeWidthDialog(OAInterface.getAppeals(SECOND,secondIndex), secondCallBack);
//		            	processingView.onPullUpRefreshComplete();
//		            }
//		        });
//	        } else {
//	            processingAdapter.setData(processings);
//	        }
//	}

	protected void showWaitProcessList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,waitProcessView,firstIndex,firstSize);
			waitProcessAdapter.setData(waitProcesses);
			return;
		}
		waitProcesses.addAll(AppealListUtil.getAppeal(resultItems));
		firstSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == waitProcessAdapter) {
	        	waitProcessAdapter = new AppealAdapter(this, waitProcesses);
	            waitProcessList.setAdapter(waitProcessAdapter);
	            waitProcessList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (waitProcesses.size() <= position) {
							return;
						}
						Intent intent = new Intent(new Intent(MainEntryActivityZN.this,AppealCenterActivity.class));
						Bundle bundle = new Bundle();
						bundle.putSerializable("appealInfo", waitProcesses.get(position));
						bundle.putBoolean("isHandler", true);
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
	            
	        } else {
	        	waitProcessAdapter.setData(waitProcesses);
	        }
		AppealListUtil.checkDatas(resultItems,waitProcessView,firstIndex,firstSize);
	}

	
	@Override
	protected void onResume() {
		super.onResume();
		viewHelper.updateUI();
		loadDatas(viewHelper.getCurrentIndex());
	}
	
	@Override
	public void onBackPressed() {
		MainActivity.getInstance().onBackPressed();
	}

	@Override
	public void loadData(int position) {
		loadDatas(position);
	}
}
