package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.MainIndustryInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.MainIndustryAdapter;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainIndustryActivity extends BaseActivity{
	
	private ListView lv_midustry;
	private InvokeHelper invoke;
	List<MainIndustryInfo> mList = new ArrayList<MainIndustryInfo>();
	List<String> mData = new ArrayList<String>();
	List<String> sort = new ArrayList<String>();
	private MainIndustryAdapter mAdapter;
	
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_industry);
		initTitleBar(R.string.industry_target_title, backListener, null);
		invoke = new InvokeHelper(this);
		loadData();
		initView();
	}
	
	private void initView() {
		lv_midustry = (ListView) findViewById(R.id.lv_midustry);
		lv_midustry.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				  Intent intent = new Intent(MainIndustryActivity.this, MainIndustryDetailActivity.class);
				  intent.putExtra("ZBMC", mData.get(position));
				  startActivity(intent);
			}
		});
	}
	
	private void loadData() {
		invoke.invoke(OAInterface.getQueryStatistics("6", "", ""), callBack);
	}
	
	private  IRequestCallBack callBack = new BaseRequestCallBack(){
		 
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
					if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("DATA");
						for (ResultItem resultItem : items) {
							MainIndustryInfo info = new MainIndustryInfo();
							info.setZbmc(resultItem.getString("ZBMC"));
							mList.add(info);
							
						}
						
						for (int i = 0; i < mList.size(); i++) {
							if(!mData.contains(mList.get(i).getZbmc())){
								mData.add(mList.get(i).getZbmc());
							}
						}
						
						if(mAdapter== null){
							mAdapter = new MainIndustryAdapter(MainIndustryActivity.this , mData);
							lv_midustry.setAdapter(mAdapter);
						}else{
							mAdapter.notifyDataSetChanged();
						}
					}
				}
			}
		}
     };
	
}
