package com.gt.ytbf.oa.ui.adapter;

import android.content.Context;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.CompanyInfo;
import com.gt.ytbf.oa.bean.NewsInfo;
import com.gt.ytbf.oa.model.AppealCenterModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-6-20.
 */
public class CompanyInfoAdapter extends BaseAdapter {

    private Context mContext;
    private List<CompanyInfo> mData;
    private String mSearchText;

    public CompanyInfoAdapter(Context context, List<CompanyInfo> data,String searchText) {
        mContext = context;
        mData = new ArrayList<CompanyInfo>();
        mSearchText=searchText;
        setData(data);
    }

    public void setData(List<CompanyInfo> data) {
        if (null != data) {
            mData.clear();
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        CompanyInfo info = mData.get(i);
        ViewHolder holder = null;
        if (null == view) {
            view = LayoutInflater.from(mContext).inflate(R.layout.company_list_item, null);
            holder = new ViewHolder();
            holder.iv_icon = (ImageView) view.findViewById(R.id.iv_icon);
            holder.tv_name = (TextView) view.findViewById(R.id.tv_name);
            holder.tv_address = (TextView) view.findViewById(R.id.tv_address);
            holder.tv_phone = (TextView) view.findViewById(R.id.tv_phone);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.iv_icon.setImageResource(info.getIcon());
//        holder.tv_name.setText(info.getName());
        //设置高亮
        if (info.getName() != null && mSearchText!=null && info.getName().contains(mSearchText)) {  
        	  
            int index = info.getName().indexOf(mSearchText);  

            int len = mSearchText.length();  
              
            Spanned temp = Html.fromHtml(info.getName().substring(0, index)  
                    + "<u><font color=#FF0000>"  
                    + info.getName().substring(index, index + len) + "</font></u>"  
                    + info.getName().substring(index + len, info.getName().length()));  

            holder.tv_name.setText(temp);  
        } else {  
            holder.tv_name.setText(info.getName());  
        }  
        holder.tv_address.setText(info.getAddress());
        holder.tv_phone.setText(info.getPhone());
        return view;
    }

    class ViewHolder {
        public ImageView iv_icon;
        public TextView tv_name;
        public TextView tv_address;
        public TextView tv_phone;
    }
}
