package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.OfficeInfo;
import com.gt.ytbf.oa.bean.TargetInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.ui.adapter.EconomicIndicatorAdapter;

public class EconomicIndicator extends BaseActivity implements OnClickListener {

	private ListView econ_indicator;
    private List<String> list = new ArrayList<String>();
    private InvokeHelper invoke;
    private ImageView system_back;
	private ImageView btn_top_right;
	private static EconomicIndicator mContext;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_economic_indicator);
		initTitleBar(R.string.function_economical_operation_list, this, this);
		xtype = getIntent().getStringExtra("XTYPE");
		initView();
//		intData();
		mContext=this;
//		invoke = new InvokeHelper(this);
//		invoke.invoke(OAInterface.getQueryStatistics("2", "", ""), callBack);
		econ_indicator = (ListView) findViewById(R.id.econ_indicator);
//		econ_indicator.setAdapter(new EconomicIndicatorAdapter(EconomicIndicator.this,list));
		econ_indicator.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				String xType = getIntent().getStringExtra("XTYPE");
				Intent intent = new Intent(EconomicIndicator.this,IndustryTargetActivity.class);
				intent.putExtra("XTYPE", xType);
				intent.putExtra("YTYPE", position+1+"");
				startActivity(intent);
			}
		});
	}
	
	private void initView() {
		system_back = (ImageView) findViewById(R.id.system_back);
		btn_top_right = (ImageView) findViewById(R.id.btn_top_right);
		system_back.setOnClickListener(this);
		btn_top_right.setOnClickListener(this);
	}

	private void intData() {
		if(xtype.equals("1")){
			list.add("全省居民消费价格指数CPI");
		    list.add("全省工业品出厂价格指数PPI");
		    list.add("全省制造业采购经理人指数PMI");
		    list.add("全省工业增加值");
		    list.add("全省主营业务收入");
		    list.add("全省利润增速");
		}else if(xtype.equals("2")){
			list.add("全市工业增加值");
		    list.add("全市主营业务收入");
		    list.add("全市利润");
		    list.add("全市利税");
		    list.add("全市工业固定投资");
		    list.add("全市工业税收");
		    list.add("全市工业贷款");
		}else if(xtype.equals("3")){
			list.add("县区居民消费价格指数CPI");
		    list.add("县区工业品出厂价格指数PPI");
		    list.add("县区制造业采购经理人指数PMI");
		    list.add("县区工业增加值");
		    list.add("县区主营业务收入");
		    list.add("县区利润增速");
		}else if (xtype.equals("4")){
			list.add("园区居民消费价格指数CPI");
		    list.add("园区工业品出厂价格指数PPI");
		    list.add("园区制造业采购经理人指数PMI");
		    list.add("园区工业增加值");
		    list.add("园区主营业务收入");
		    list.add("园区利润增速");
		}else if(xtype.equals("5")){
			list.add("主导产业居民消费价格指数CPI");
		    list.add("主导产业工业品出厂价格指数PPI");
		    list.add("主导产业制造业采购经理人指数PMI");
		    list.add("主导产业工业增加值");
		    list.add("主导产业主营业务收入");
		    list.add("主导产业利润增速");
		}else if (xtype.equals("6")){
			list.add("产业");
			list.add("轻重工业");
			list.add("行业");
		}
	}
	
	private  IRequestCallBack callBack = new BaseRequestCallBack(){
		 
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
					if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("data");
						for (ResultItem resultItem : items) {
							TargetInfo tgInfo = new TargetInfo();
							tgInfo.setType(resultItem.getString("TYPE"));
							tgInfo.setNum(resultItem.getString("XH"));
							tgInfo.setYear(resultItem.getString("YEAR"));
							tgInfo.setMonth(resultItem.getString("MONTH"));
							tgInfo.setTarget(resultItem.getString("ZB"));
							System.out.println(tgInfo);
						}
					}
				}
			}
		}
     };
	private String xtype;
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			finish();
			break;
		case R.id.btn_top_right:
			startActivity(new Intent(EconomicIndicator.this,MainActivity.class));
			finish();
			break;
		default:
			break;
		}
	}
	public static void finishMySelf() {
		mContext.finish();
	}
}
