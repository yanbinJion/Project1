package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.CountyEconomyInfo;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter.ViewHolder;

import android.R.integer;
import android.content.Context;
import android.renderscript.Type;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CountyEconomyAdapter extends BaseAdapter {

	private Context mContext;
	private List<CountyEconomyInfo> mData;
	private int type;
	
	public CountyEconomyAdapter(Context mContext,List<CountyEconomyInfo> mData, int type) {
		super();
		this.mContext = mContext;
		this.mData = mData;
		this.type = type;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData.size()==0?null:mData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.county_economy_target_item,null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);
			hodler.tv_table01.setVisibility(View.GONE);
			hodler.tv_table04 = (TextView) convertView.findViewById(R.id.tv_table04);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		
		if (1==type) {
			hodler.tv_table1.setText(mData.get(position).getCompanyName());
			hodler.tv_table01.setText(mData.get(position).getYearTaget());
			hodler.tv_table02.setText(mData.get(position).getMouthComplete());
			hodler.tv_table03.setText(mData.get(position).getAddPercent());
			hodler.tv_table04.setText(mData.get(position).getCompletePlan());
		}else if (2==type) {
			hodler.tv_table1.setText(mData.get(position).getCompanyName());
			hodler.tv_table01.setText(mData.get(position).getgYearTaget());
			hodler.tv_table02.setText(mData.get(position).getgMouthComplete());
			hodler.tv_table03.setText(mData.get(position).getgAddPercent());
			hodler.tv_table04.setText(mData.get(position).getgCompletePlan());
			
		}else if (3==type) {
			hodler.tv_table1.setText(mData.get(position).getCompanyName());
			hodler.tv_table01.setText(mData.get(position).getlYearTaget());
			hodler.tv_table02.setText(mData.get(position).getlMouthComplete());
			hodler.tv_table03.setText(mData.get(position).getlAddPercent());
			hodler.tv_table04.setText(mData.get(position).getlCompletePlan());
		}
		
		return convertView;
	}

	final class ViewHolder {
		TextView tv_table1, tv_table01, tv_table02, tv_table03, tv_table04;
	}
}
