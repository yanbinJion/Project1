package com.gt.ytbf.oa.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import cn.jpush.android.api.JPushInterface;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.api.OnDownLoadListener;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.UpdateInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LogUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.SharePreferenceUtil;

public class LoginActivity extends BaseActivity implements OnClickListener {

	private final String TAG = "LoginActivity";

	private EditText userNameEdt;
	private EditText pwdEdt;
	private Button loginBtn;
	private CheckBox remberPwd;
	private InvokeHelper invoke;
	private SharedPreferences sharedPreferences;
	private UserInfo user;
	
	protected static final int NEED_UPDATE = 0;
	protected static final int MAX = 1;
	protected static final int PROGRESS = 2;
	private UpdateInfo updateInfo;
	private ProgressDialog pb;
	private boolean isForceUpdate;
	
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch (msg.what) {
			case NEED_UPDATE:
				UpdateInfo updateInfo = (UpdateInfo) msg.obj;
				String isforce = updateInfo.getIsforce();
//				isForceUpdate = !"0".equals(isforce);
				if ("0".equals(isforce)) {
					showUpdateDialog(updateInfo);
				} else {
					showForceUpdateDialog(updateInfo);
				}
				
				break;
			case MAX:
				pb.setMax(msg.arg1);
				break;
			case PROGRESS:
				int progress=pb.getProgress()+msg.arg2;
				pb.setProgress(progress);
				
				int precent=progress*100/pb.getMax();
				//tvProgress.setText("已下载:"+precent+"%");
				break;
			default:
				break;
			}
		};
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		UserInfo user = LoginUtils.getInstance().getUserInfo();
		if (null != user && !BeanUtils.isNullOrEmpty(user.getUserId())
				&& !BeanUtils.isNullOrEmpty(user.getPassword())) {
			if ((getIntent().getFlags() & Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) != 0) {
		        finish();  
		        return;  
			} else {
				if (getIntent().getBooleanExtra("passwordError", false)) {
					setContentView(R.layout.activity_login);					
					invoke = new InvokeHelper(this);
					invoke.invoke(OAInterface.getVersion("1"), requestCallBack);
					initView();
				}else {
					Intent intent = new Intent(this, LoginGesturesPasswordActivity.class);
					intent.putExtra("gotoMain", true);
					startActivity(intent);
					finish();
				}
			}
		} else {
			setContentView(R.layout.activity_login);					
			invoke = new InvokeHelper(this);
			invoke.invoke(OAInterface.getVersion("1"), requestCallBack);
			initView();
		}
	}

	private void initView() {
		userNameEdt = (EditText) findViewById(R.id.login_user);
		pwdEdt = (EditText) findViewById(R.id.login_pwd);
		loginBtn = (Button) findViewById(R.id.login_btn);
		remberPwd=(CheckBox) findViewById(R.id.remberPwd);
		
		sharedPreferences = getSharedPreferences("config", MODE_PRIVATE);		
		boolean chooseRember = sharedPreferences.getBoolean("chooseRember", true);
		if (chooseRember) {		
			String userName = sharedPreferences.getString("usetName", "");
			String pwd = sharedPreferences.getString("pwd", "");
			userNameEdt.setText(userName);
			pwdEdt.setText(pwd);
			remberPwd.setChecked(true);
		}
			
		Selection.setSelection(userNameEdt.getText(), userNameEdt.length());
		loginBtn.setOnClickListener(this);
		userNameEdt.addTextChangedListener(new TextWatcher() {

			@Override
			public void afterTextChanged(Editable s) {
				pwdEdt.setText("");
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				
			}
			
		});
	}
	
	/**
	 * 判断用户名和密码是否为空
	 * */
	private boolean invalidate() {
		String userName = userNameEdt.getText().toString().trim();
		String pwd = pwdEdt.getText().toString().trim();
		if (TextUtils.isEmpty(userName)||TextUtils.isEmpty(pwd)) {
			Toast.makeText(this, "用户名和密码不能为空", Toast.LENGTH_SHORT).show();
			return false;
		}
		return true;
	}
		
	private IRequestCallBack callBack = new BaseRequestCallBack() {		

		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (!response.isSuccess()) {
					errorMessage = response.getErrorItem().getErrorMessage();
	                showDialog(DIALOG_ERROR);
	                return;
				}
				if (checkResult(item)) {
					if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
						item = item.getItems("data").get(0);
						user = new UserInfo();
						user.setAuthtoken(item.getString("AUTHTOKEN"));
						user.setOrgCode(item.getString("ORG_CODE"));
						user.setPassword(item.getString("USER_PWD"));
						user.setState(item.getString("STATE"));
						user.setUserLevel(item.getString("USERLEVEL"));
						user.setUserName(item.getString("USER_NAME"));
						user.setUserCode(item.getString("USER_CODE"));
						user.setUserSortNo(item.getString("USER_SORTNO"));
						user.setUserId(item.getString("USER_ID"));
						user.setId(item.getString("ID"));
						user.setDepLevel(item.getString("DEP_LEVEL"));
						user.setInvalid(item.getString("INVALID"));
						user.setName(item.getString("NAME"));
						user.setIsDispatch(item.getString("IS_DISPATCH"));
						user.setDepartMentId(item.getString("DEPARTMENTID"));
						user.setSwitch("1".equals(item.getString("HUNGPOINT")));
						LoginUtils.getInstance().setUserInfo(user);					
						
						gotoMain();
					}
				}
				if (item.getString("code").equals("-3")) {
					Toast.makeText(LoginActivity.this, "用户名不存在或密码错误", 0).show();
				}
									
		}
		
	};	

	@Override
	public void onClick(View v) {
		int viewId = v.getId();
		switch(viewId) {
		case R.id.login_btn:
			String userName = userNameEdt.getText().toString().trim();
			String pwd = pwdEdt.getText().toString().trim();
						
			if (invalidate()) {
				invoke.invokeWidthDialog(OAInterface.logon(userName, pwd), callBack);
			}
			
			Editor editor = sharedPreferences.edit();
			if (remberPwd.isChecked()) {
				editor.putString("usetName", userName);
				editor.putString("pwd", pwd);
				editor.putBoolean("chooseRember", true);
				
				}else {
					editor.putString("usetName", "");
					editor.putString("pwd", "");
					editor.putBoolean("chooseRember", false);
				}		
			editor.commit();
			break;
			default:
				break;
		}
	}

	protected void gotoMain() {
		if (null == spUtils) {
			spUtils = new SharePreferenceUtil(this);
		}
		if (remberPwd.isChecked() && spUtils.getPatternState() && !BeanUtils.isNullOrEmpty(spUtils.getPatternPwd())) {
			Intent intent = new Intent(this, LoginGesturesPasswordActivity.class);
			intent.putExtra("gotoMain", true);
			startActivity(intent);
		} else {
		//进入主界面
			Intent intent = new Intent(LoginActivity.this, MainActivity.class);
			startActivity(intent);
		}
		LoginActivity.this.finish();
	}

	private IRequestCallBack requestCallBack= new BaseRequestCallBack() {				

		@Override
		public void process(com.gt.ytbf.oa.network.http.HttpResponse response,
				int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
				item = item.getItems("data").get(0);
				if (!BeanUtils.isEmpty(item)) {
					updateInfo = new UpdateInfo();
					updateInfo.setApkSize(item.getString("APKSIZE"));
					updateInfo.setContent(item.getString("CONTENT"));
					updateInfo.setDateTime(item.getString("DATATIME"));
					updateInfo.setUrl(item.getString("URL"));
					updateInfo.setVerCode(item.getString("VERCODE"));
					updateInfo.setVerName(item.getString("VERNAME"));
					updateInfo.setIsforce(item.getString("ISFORCE"));
					checkUpdate();
				}
			}			
		}
	};
	
	/**
	 * 检测更新版本
	 */
	private void checkUpdate() {
 
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				if (null == updateInfo || BeanUtils.isEmpty(updateInfo.getVerCode())) {
					return;
				}
				String currentVersionCode = getVersionCode();		
				String updateode = updateInfo.getVerCode();
				LogUtils.d(TAG, "getVersion: " + currentVersionCode + "  " + updateode);
				if (updateode.compareTo(currentVersionCode) > 0) {
					Message message = Message.obtain();
					message.what = NEED_UPDATE;
					message.obj = updateInfo;
					mHandler.sendMessage(message);
				}
			}
		}).start();
				
	}
	
	/**
	 * 強制安裝
	 * 弹出对话框提醒用户更新
	 * @param updateInfo
	 */
	protected void showForceUpdateDialog(final UpdateInfo updateInfo) {
		final AlertDialog.Builder builder=new AlertDialog.Builder(this);
		builder.setCancelable(false);
		builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
		    @Override
		    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
		        if(keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount()==0)
		        {
		        	dialog.dismiss();
		            LoginActivity.this.finish();
		        }
		        return false;
		    }
		});
		builder.setTitle("有新版本可以更新,否则将无法使用");	
		
		builder.setPositiveButton("接受更新", new android.content.DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				File dir = Environment.getExternalStorageDirectory();
				download(updateInfo.getUrl(), dir, new OnDownLoadListener() {
					
					@Override
					public void onSuccess(File file) {
						installApk(file);
						
					}
										
					@Override
					public void onFail() {
					
					//Toast.makeText(LoginActivity.this, "下载失败", Toast.LENGTH_SHORT).show();
					}
				});
				
			}
		}).show();
		
	}
	

	
	/**
	 * 選擇安裝
	 * 弹出对话框提醒用户更新
	 * @param updateInfo
	 */
	protected void showUpdateDialog(final UpdateInfo updateInfo) {
//		isForceUpdate = true;
		final AlertDialog.Builder builder=new AlertDialog.Builder(this);
		builder.setTitle("亲、有新版本可以更新哦");	
//		builder.setCancelable(!isForceUpdate);
		builder.setCancelable(false);
		
		builder.setOnKeyListener(new DialogInterface.OnKeyListener() {
		    @Override
		    public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
		        if(keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount()==0)
		        {
		        	dialog.dismiss();
		            LoginActivity.this.finish();
		        }
		        return false;
		    }
		});
		builder.setPositiveButton("接受更新", new android.content.DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
//				setProgressBarVisibility(true);							
				File dir = Environment.getExternalStorageDirectory();
				//Toast.makeText(LoginActivity.this, updateInfo.getUrl(), Toast.LENGTH_SHORT).show();
				download(updateInfo.getUrl(), dir, new OnDownLoadListener() {
					
					@Override
					public void onSuccess(File file) {
						installApk(file);
					}
										
					@Override
					public void onFail() {
					
					//Toast.makeText(LoginActivity.this, "下载失败", Toast.LENGTH_SHORT).show();
					}
				});
				
			}
		}).show();
		
	}
	/**
	 * 获取版本信息
	 */
	private String getVersionCode() {
		PackageManager packageManager = getPackageManager();
		PackageInfo packageInfo = null;
		try {
			packageInfo=packageManager.getPackageInfo(getPackageName(), PackageManager.GET_UNINSTALLED_PACKAGES);
		} catch (NameNotFoundException e) {	
			e.printStackTrace();
		}
		if (packageInfo!=null) {
			return packageInfo.versionName;
		}
		return "";
		
	}
	
	/**
	 * 安装APK
	 * @param apkFile
	 */
	private void installApk(File apkFile) {
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_VIEW);
		intent.addCategory(Intent.CATEGORY_DEFAULT);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
		intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
		startActivity(intent);
		finish();
	}
	
	/**
	 * 文件下载
	 * @param url
	 * @param dir
	 */
	public void download(final String url,final File dir,final OnDownLoadListener listener ) {

		pb = new ProgressDialog(this);
		pb.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		pb.setMessage("正在下载更新");
		pb.show();
		new Thread(new Runnable() {
			@SuppressWarnings("deprecation")
			public void run() {
				InputStream inputStream=null;
				OutputStream outputStream=null;
				HttpClient httpClient=new DefaultHttpClient();
				HttpGet httpGet=new HttpGet(url);
				HttpParams params = httpClient.getParams();
				params.setParameter(HttpConnectionParams.CONNECTION_TIMEOUT, 3000);
				params.setParameter(HttpConnectionParams.SO_TIMEOUT, 3000);
				
				try {
					org.apache.http.HttpResponse response = httpClient.execute(httpGet);
					if (response.getStatusLine().getStatusCode()==200) {
						HttpEntity entity = response.getEntity();
						inputStream=entity.getContent();
						
						Header[] headers = response.getHeaders("Content-Length");
						String fileLength = headers[0].getValue();
						int fileSize = Integer.parseInt(fileLength);
						Message message = Message.obtain();
						message.what=MAX;
						message.arg1=fileSize;
						mHandler.sendMessage(message);
												
						String fileName =url.substring(url.lastIndexOf("/")+1);
						File localFile =new File(dir,fileName);		
						outputStream=new FileOutputStream(localFile);
						byte[] buffer=new byte[1024];
						int len=-1;
						while ((len=inputStream.read(buffer))!=-1) {
							outputStream.write(buffer,0,len);
							Message message2 = Message.obtain();
							message2.what=PROGRESS;
							message2.arg2=len;
							mHandler.sendMessage(message2);
						}
						outputStream.flush();
						pb.dismiss();
						listener.onSuccess(localFile);
					}else {
						listener.onFail();
					}
										
				} catch (IOException e) {
					// TODO 响应失败
					e.printStackTrace();
					listener.onFail();
				}finally{
					try {
						if (inputStream!=null) {
							inputStream.close();
						}
						if (outputStream!=null) {
							outputStream.close();
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}			
				
			}
		}).start();				
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		JPushInterface.onResume(this);
	}
	@Override
	protected void onPause() {
		super.onPause();
		JPushInterface.onPause(this);
	}
	
}
