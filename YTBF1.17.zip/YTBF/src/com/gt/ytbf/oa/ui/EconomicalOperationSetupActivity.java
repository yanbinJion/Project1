package com.gt.ytbf.oa.ui;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.ui.adapter.EconomicalSetupAdapter;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class EconomicalOperationSetupActivity extends BaseActivity implements OnItemClickListener{
 
	private GridView gw_econ;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_economical_setup);
		initTitleBar(R.string.tab_economical_title,backListener,null);
		gw_econ = (GridView) findViewById(R.id.econ_gv);
		gw_econ.setAdapter(new EconomicalSetupAdapter(EconomicalOperationSetupActivity.this));
	    gw_econ.setOnItemClickListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		   if(position==0){
			   	Intent intent = new Intent(EconomicalOperationSetupActivity.this, IndustryTargetActivity.class);
				startActivity(intent);
		   }else if(position==5){
			   Intent intent = new Intent(EconomicalOperationSetupActivity.this, WholeCityElectricActivity.class);
			   startActivity(intent);
		   }else if(position==3){
			   Intent intent = new Intent(EconomicalOperationSetupActivity.this, CountyIndustryActivity.class);
			   startActivity(intent);
		   }else if(position==4){
			   Intent intent = new Intent(EconomicalOperationSetupActivity.this, MainIndustryActivity.class);
			   startActivity(intent);
		   }else if(position==2){
			   Intent intent = new Intent(EconomicalOperationSetupActivity.this, CountyEconomyActivity.class);
			   startActivity(intent);
		   }else if(position==1){
			   Intent intent = new Intent(EconomicalOperationSetupActivity.this, CityEconomicActivity.class);
			   startActivity(intent);
		   }
		
	 }
	
	private OnClickListener backListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			finish();
		}
		
	};
	
	
//	@Override
//	public void onBackPressed() {
//		MainActivity.getInstance().onBackPressed();
//	}
}
