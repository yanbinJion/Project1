package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.ViewHolderAdapter;
import com.gt.ytbf.oa.bean.OfficeInfo;

public class OfficeAdapter extends
		ViewHolderAdapter<OfficeInfo, OfficeAdapter.ViewHolder> {

	private static final int TYPE=10;
	public OfficeAdapter(Context context, List<OfficeInfo> listData) {
		super(context, listData);
	}

	@Override
	public View buildConvertView(LayoutInflater layoutInflater, OfficeInfo t,
			int position) {
		return inflate(R.layout.viewpager_item);
	}

	@Override
	public ViewHolder buildViewHolder(View convertView, OfficeInfo t,
			int position) {
		ViewHolder holder = new ViewHolder();
		holder.iv_icon=(ImageView) convertView.findViewById(R.id.iv_icon);
		holder.tv_content=(TextView) convertView.findViewById(R.id.tv_content);
		holder.tv_data=(TextView) convertView.findViewById(R.id.tv_data);
		holder.tv_destpye = (TextView)convertView.findViewById(R.id.tv_destpye);
		return holder;
	}

	@Override
	public void bindViewDatas(ViewHolder holder, OfficeInfo t, int position) {
		
		if(String.valueOf(TYPE).equals(t.getType())){
			holder.iv_icon.setImageResource(R.drawable.two_icon_city);
		}else if (String.valueOf(TYPE+1).equals(t.getType())){
			holder.iv_icon.setImageResource(R.drawable.two_icon_amphoe);
		}else if(String.valueOf(TYPE+2).equals(t.getType())){
			holder.iv_icon.setImageResource(R.drawable.two_icon_tambon);
		}
		
		holder.tv_content.setText(t.getContent());
		holder.tv_data.setText(t.getData());
        holder.tv_destpye.setText(t.getDestype());
	}

	class ViewHolder {
		private ImageView iv_icon;
		private TextView tv_content;
		private TextView tv_data;
		private TextView tv_destpye;
	}

}
