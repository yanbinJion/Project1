package com.gt.ytbf.oa.ui.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

/**
 * Created by ch on 2016/5/4.
 */
public class AutoRollViewPager extends ViewPager{
    public AutoRollViewPager(Context context) {
        super(context);
    }

    public AutoRollViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);

    }
}
