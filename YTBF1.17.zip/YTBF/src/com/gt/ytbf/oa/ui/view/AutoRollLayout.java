package com.gt.ytbf.oa.ui.view;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;



import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.RollItem;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.LogUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ch on 2016/5/4.
 */
public class AutoRollLayout extends FrameLayout implements ViewPager.OnPageChangeListener {

    private ViewPager mViewPager;
    private TextView tvTitle;
    private LinearLayout llDots;
    private int dot_size;
    private int mPosition;
    private GestureDetector mGestureDetector;
    private Context mContext;
    private boolean isFirst = true;

    private OnItemClickListener mOnItemClickListener;
    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.mOnItemClickListener=onItemClickListener;
    }
    public interface OnItemClickListener{
        public void onItemClick(RollItem rollItem);
    }

    public static Handler mHandler = new Handler(Looper.getMainLooper());

    public AutoRollLayout(Context context) {
        this(context, null);
    }

    public AutoRollLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AutoRollLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        View.inflate(context, R.layout.roll_layout, this);
        mViewPager = (ViewPager) findViewById(R.id.mvp);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        llDots = (LinearLayout) findViewById(R.id.ll_dots);
        mViewPager.setOnPageChangeListener(this);


        mGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                if (mOnItemClickListener != null) {
                    int currentItem=mViewPager.getCurrentItem();
                    RollItem rollItem = mRollItems.get(currentItem);
                    mOnItemClickListener.onItemClick(rollItem);
                }
                return super.onSingleTapUp(e);
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                return super.onScroll(e1, e2, distanceX, distanceY);
            }
        });

        mViewPager.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mGestureDetector.onTouchEvent(event);
                int action = event.getAction();
                if (action == MotionEvent.ACTION_DOWN) {
                    mTapInTouch = true;
                } else if (action == MotionEvent.ACTION_UP) {
                    mTapInTouch = false;
                } else if (action == MotionEvent.ACTION_CANCEL) {
                    mTapInTouch = false;
                }
                return false;
            }
        });

    }

    private List<RollItem> mRollItems;
    public AutoRollLayout setData(List<RollItem> rollItems){
        if (rollItems==null) {
            return this;
        }
        this.mRollItems=rollItems;
        mCache.clear();
        for (RollItem item : rollItems) {
        	ImageView imageView = new ImageView(mContext);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            mCache.add(imageView);
            if (!BeanUtils.isNullOrEmpty(item.imgPath)) {
            	Picasso.with(mContext).load(item.getImgPath()).into(imageView);
            } else {
	            int image = item.getImage();
	            imageView.setImageResource(image);
            }
        }
        if (isFirst) {
        	mViewPager.setAdapter(mPagerAdapter);
        } else {
        	mPagerAdapter.notifyDataSetChanged();
        }
        addDots();
        mPosition=0;
        onPageSelected(0);
        if (!isFirst) {
        	mHandler.removeCallbacks(mAutoTask);
        }
        mHandler.postDelayed(mAutoTask, 3000);
        isFirst = false;
        return this;
    }

    private void addDots() {
        llDots.removeAllViews();
        for (int i = 0; i <mPagerAdapter.getCount(); i++) {
            View view = new View(getContext());
            view.setBackgroundResource(R.drawable.selecter_dot_bg);
            view.setOnClickListener(mDotOnClickListener);
            dot_size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10, getContext().getResources().getDisplayMetrics());
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(dot_size,dot_size);
            params.rightMargin=dot_size;
            view.setLayoutParams(params);
            llDots.addView(view);

        }
    }

    private OnClickListener mDotOnClickListener=new OnClickListener() {
        @Override
        public void onClick(View v) {
            int index = llDots.indexOfChild(v);
            mViewPager.setCurrentItem(index);
        }
    };

    private boolean mTapInTouch;
    private Runnable mAutoTask=new Runnable() {
        @Override
        public void run() {
            if (!mTapInTouch) {
                antoNext();
            }
            mHandler.postDelayed(this,3000);
        }
    };

    private boolean mAutoRight;
    private ArrayList<ImageView> mCache =new ArrayList<ImageView>();
    
    private void antoNext() {
    	int currentItem = mViewPager.getCurrentItem();
//        if (currentItem >= mPagerAdapter.getCount()-1) {
//            mAutoRight = false;
//        } else if (currentItem == 0){
//            mAutoRight = true;
//        }
//        currentItem=mAutoRight? (currentItem+1) : (currentItem-1);
    	currentItem = (currentItem >= mRollItems.size() - 1) ? 0 : currentItem + 1;
        mViewPager.setCurrentItem(currentItem, true);
    }



    private PagerAdapter mPagerAdapter= new PagerAdapter() {
        
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
        	container.addView(mCache.get(position), 0);
            return mCache.get(position);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public int getCount() {
//            return mRollItems==null?0:mRollItems.size();
            return  3;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view==object;
        }

    };

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
            String title=mRollItems.get(position).title;
            tvTitle.setText(title);

        llDots.getChildAt(mPosition).setEnabled(true);
        llDots.getChildAt(position).setEnabled(false);
        mPosition=position;
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
