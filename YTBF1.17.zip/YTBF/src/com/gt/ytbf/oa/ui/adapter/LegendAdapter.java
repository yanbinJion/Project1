package com.gt.ytbf.oa.ui.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.ui.AppealActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-6-20.
 */
public class LegendAdapter extends BaseAdapter {

    private Context mContext;
    private int[] color;
    private List<String> name;
    public LegendAdapter(Context context, int[] color,List<String> name) {
        mContext = context;
        this.color=color;
        this.name=name;
    }

    @Override
    public int getCount() {
        return name.size();
    }

    @Override
    public Object getItem(int i) {
        return name.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = null;
        if (null == view) {
            view = LayoutInflater.from(mContext).inflate(R.layout.grid_legend_item, null);
            holder = new ViewHolder();
            holder.color =  (ImageView) view.findViewById(R.id.color);
            holder.name = (TextView) view.findViewById(R.id.name);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.color.setBackgroundColor(color[i]);
        holder.name.setText(name.get(i));
        return view;
    }

    class ViewHolder {
        public ImageView color;
        public TextView name;
    }
}
