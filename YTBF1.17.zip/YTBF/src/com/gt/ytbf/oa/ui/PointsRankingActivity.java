package com.gt.ytbf.oa.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;

public class PointsRankingActivity extends BaseActivity {

    public static final String[] POINTS={"500.9","500.9","500.9","466.5","466.5","466.5"};
    private View.OnClickListener backListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_points_ranking);

        initTitleBar(R.string.function_points_ranking, backListener, null);
        initView();
    }


    private void initView() {
        ListView lv_points_ranking = (ListView) findViewById(R.id.lv_points_ranking);
        lv_points_ranking.setAdapter(new RankAdapter());
    }

    class RankAdapter extends BaseAdapter{

        private TextView tv_points;

        @Override
        public int getCount() {
            return POINTS==null?0:POINTS.length;
        }

        @Override
        public Object getItem(int position) {
            return POINTS[position];
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView==null){
                convertView = View.inflate(PointsRankingActivity.this, R.layout.rank_points_item, null);
                tv_points = (TextView) convertView.findViewById(R.id.tv_points);
            }
            if(position<=2){

                tv_points.setText(POINTS[position]);
                tv_points.setTextColor(Color.RED);
            }else {
                tv_points.setText(POINTS[position]);
            }
            return convertView;
        }
    }
}
