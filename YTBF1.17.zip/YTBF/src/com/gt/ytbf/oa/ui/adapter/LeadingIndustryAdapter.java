package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.ViewHolderAdapter;
import com.gt.ytbf.oa.bean.LeadingIndustryInfo;

/**
 * 
 * @author dir_wang
 * 
 */
public class LeadingIndustryAdapter extends ViewHolderAdapter<LeadingIndustryInfo, LeadingIndustryAdapter.ViewHolder> {

	public LeadingIndustryAdapter(Context context, List<LeadingIndustryInfo> listData) {
		super(context, listData);
	}

	@Override
	public View buildConvertView(LayoutInflater layoutInflater, LeadingIndustryInfo t, int position) {
		return inflate(R.layout.leading_industry_item);
	}

	@Override
	public ViewHolder buildViewHolder(View convertView, LeadingIndustryInfo t, int position) {
		ViewHolder holder = new ViewHolder();
		holder.iv_icon= (ImageView) convertView.findViewById(R.id.iv_icon);
        holder.tv_title= (TextView) convertView.findViewById(R.id.tv_title);
        holder.tv_content= (TextView) convertView.findViewById(R.id.tv_content);
		return holder;
	}

	@Override
	public void bindViewDatas(ViewHolder holder, LeadingIndustryInfo info,
			int position) {
		holder.iv_icon.setImageResource(info.getIcon());
        holder.tv_title.setText(info.getTitle());
        holder.tv_content.setText(info.getContent());
		if (position == 0) {
			holder.tv_title.setTextColor(Color.parseColor("#F2E42C"));
		}
		if (position == 1) {
			holder.tv_title.setTextColor(Color.parseColor("#3EABF0"));
		}
		if (position == 2) {
			holder.tv_title.setTextColor(Color.parseColor("#24AF34"));
		}
		if (position == 3) {
			holder.tv_title.setTextColor(Color.parseColor("#CD4F75"));
		}
		if (position == 4) {
			holder.tv_title.setTextColor(Color.parseColor("#3D85AA"));
		}
		if (position == 5) {
			holder.tv_title.setTextColor(Color.parseColor("#D64F8A"));
		}
	}

	public class ViewHolder {
		private ImageView iv_icon;
        private TextView tv_title;
        private TextView tv_content;
	}
}
