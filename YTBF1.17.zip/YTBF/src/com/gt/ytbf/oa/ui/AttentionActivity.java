package com.gt.ytbf.oa.ui;

import android.os.Bundle;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;

/**
 * 关注主界面
 * */
public class AttentionActivity extends BaseActivity {

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_attention);
		initTitleBar("关注", null, null);
	}
}
