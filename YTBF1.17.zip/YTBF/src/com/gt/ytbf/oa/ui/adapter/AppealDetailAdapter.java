package com.gt.ytbf.oa.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.AppealDetailInfo;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.AppealAdapter.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AppealDetailAdapter extends BaseAdapter{
	
	private Context mContext;
    private List<AppealDetailInfo> mData;
    
	public AppealDetailAdapter(Context context, List<AppealDetailInfo> data) {
		mContext = context;
        mData = new ArrayList<AppealDetailInfo>();
        setData(data);
	}

	private void setData(List<AppealDetailInfo> data) {
		if (null != data) {
            mData.clear();
            mData.addAll(data);
        }
        notifyDataSetChanged();
	}

	 @Override
	    public int getCount() {
	        return mData.size();
	    }

	    @Override
	    public Object getItem(int i) {
	        return mData.get(i);
	    }

	    @Override
	    public long getItemId(int i) {
	        return i;
	    }

	    @Override
	    public View getView(int i, View view, ViewGroup viewGroup) {
	        AppealDetailInfo  appealDetailInfo= mData.get(i);
	        ViewHolder holder = null;
	        if (null == view) {
	            view = LayoutInflater.from(mContext).inflate(R.layout.appeal_center_item, null);
	            holder = new ViewHolder();
	            holder.tv_appeal_time = (TextView) view.findViewById(R.id.tv_appeal_time);
	            holder.tv_appeal_content = (TextView) view.findViewById(R.id.tv_appeal_content);
	            holder.tv_appeal_comment = (TextView) view.findViewById(R.id.tv_appeal_comment);
	            holder.tv_appeal_state = (TextView) view.findViewById(R.id.tv_appeal_state);
	            holder.tv_appeal_next = (TextView) view.findViewById(R.id.tv_appeal_next);
	            holder.tv_lead_content = (TextView) view.findViewById(R.id.tv_lead_content);
	            holder.ll_lead_content = (LinearLayout) view.findViewById(R.id.ll_lead_content);
	            view.setTag(holder);
	        } else {
	            holder = (ViewHolder) view.getTag();
	        }
	        holder.tv_appeal_time.setText(appealDetailInfo.getAppealTime());
	        holder.tv_appeal_content.setText(appealDetailInfo.getAppealContent());
	        holder.tv_appeal_next.setText(appealDetailInfo.getAppealNext());
	        holder.tv_appeal_state.setText(appealDetailInfo.getAppealState());
	        holder.tv_appeal_comment.setText(appealDetailInfo.getAdvice());
	        if (!BeanUtils.isEmpty(appealDetailInfo.getLeadContent())) {
				holder.ll_lead_content.setVisibility(View.VISIBLE);
				holder.tv_lead_content.setText(appealDetailInfo.getLeadContent());
			}
	        return view;
	    }

	    class ViewHolder {
	        public TextView tv_appeal_time;
	        public TextView tv_appeal_content;
	        public TextView tv_appeal_comment;
	        public TextView tv_appeal_state;
	        public TextView tv_appeal_next;
	        public TextView tv_lead_content;
	        public LinearLayout ll_lead_content;
	    }
	
}
