package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.TargetInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.ScreenUtils;
import com.gt.ytbf.oa.tools.StringUtils;

public class EconomicalListChartActivity extends BaseActivity implements
		OnClickListener {

	// XY轴坐标数据
	private XYSeries series1;
	// 单个曲线渲染器
	private XYSeriesRenderer renderer1;
	// 图标数据集
	private XYMultipleSeriesDataset mDataset = new XYMultipleSeriesDataset();
	// 曲线图整体渲染器
	private XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer();
	// 绘图视图
	private GraphicalView mChartView;

	private List<TargetInfo> chartDatas;
	
	List<Map<String,String>> moreListYear;
	List<Map<String,String>> moreListMonth;
	private ListView lvPopupList;
	private PopupWindow pwMyPopWindow;
	private RelativeLayout chart;
	private TextView tv_start_year;
	private TextView tv_start_month;
	private TextView tv_end_year;
	private TextView tv_end_month;
	private static final int NUM_OF_VISIBLE_LIST_ROWS = 6;
	private InvokeHelper invoke;
	private String xType;
	private String yType;
	
	private ArrayList<String> timeArrays = new ArrayList<String>();
	
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
		}
	};

	private View.OnClickListener homeListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			startActivity(new Intent(EconomicalListChartActivity.this,
					MainActivity.class));
			EconomicIndicator.finishMySelf();
			finish();
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_economical_list_chart);
//		initTitleBar(R.string.function_economical_operation_list, backListener,
//				homeListener);
//		initView();
//		init_chart();
//		initData();
	}


	private void initView() {
		tv_start_year = (TextView) findViewById(R.id.tv_start_year);
		tv_start_month = (TextView) findViewById(R.id.tv_start_month);
		tv_end_year = (TextView) findViewById(R.id.tv_end_year);
		tv_end_month = (TextView) findViewById(R.id.tv_end_month);
		TextView tv_search = (TextView) findViewById(R.id.tv_search);
		tv_start_year.setOnClickListener(this);
		tv_start_month.setOnClickListener(this);
		tv_end_year.setOnClickListener(this);
		tv_end_month.setOnClickListener(this);
		tv_search.setOnClickListener(this);
	}

	private void initPopupWindow(final List<Map<String,String>> dates,final TextView tv) {
		LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
	    View layout = inflater.inflate(R.layout.task_detail_popupwindow, null);
	    lvPopupList = (ListView) layout.findViewById(R.id.lv_popup_list);
	    pwMyPopWindow = new PopupWindow(layout);
	    pwMyPopWindow.setFocusable(true);
	    lvPopupList.setAdapter(new SimpleAdapter(EconomicalListChartActivity.this, dates, R.layout.list_item_popupwindow, new String[] {"key"}, new int[] {R.id.tv_list_item}));
	    lvPopupList.setOnItemClickListener(new OnItemClickListener() {
  			@Override
  			public void onItemClick(AdapterView<?> parent, View view,
  					int position, long id) {
  				if(dates.get(position).get("key").equals("请选择")){
  					tv.setText("");
  					pwMyPopWindow.dismiss();
  				}else {
  					String str = dates.get(position).get("key");
  					String [] strsplit = str.split(" ");
  					tv.setText(strsplit[0]);
  					pwMyPopWindow.dismiss(); 
  				}
  			}
  		});
	    //控制popupwindow的宽度和高度自适应
	    lvPopupList.measure(View.MeasureSpec.UNSPECIFIED,View.MeasureSpec.UNSPECIFIED);
	    pwMyPopWindow.setWidth(lvPopupList.getMeasuredWidth());
	    pwMyPopWindow.setHeight((lvPopupList.getMeasuredHeight() + 20)*NUM_OF_VISIBLE_LIST_ROWS);
	   //控制popupwindow点击屏幕其他地方消失
	    pwMyPopWindow.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.bg_popupwindow));
	    pwMyPopWindow.setOutsideTouchable(true);
	}
	
	private void setYearAndMonth() {
		String startYear = tv_start_year.getText().toString();
		String startMonth = tv_start_month.getText().toString();
		String endYear = tv_end_year.getText().toString();
		String endMonth = tv_end_month.getText().toString();
		Calendar c = Calendar.getInstance();
		if (StringUtils.isNullOrEmpty(startYear)) {
			startYear = String.valueOf(c.get(Calendar.YEAR) - 1);
		}
		if (StringUtils.isNullOrEmpty(startMonth)) {
			startMonth = String.valueOf("1");
		}
		if (StringUtils.isNullOrEmpty(endYear)) {
			endYear = String.valueOf(c.get(Calendar.YEAR));
		}
		if (StringUtils.isNullOrEmpty(endMonth)) {
			endMonth = String.valueOf(c.get(Calendar.MONTH) + 1);
		}
		int sy = Integer.valueOf(startYear);
		int sm = Integer.valueOf(startMonth);
		int ey = Integer.valueOf(endYear);
		int em = Integer.valueOf(endMonth);
		if (endYear.compareTo(startYear) > 0) {
			getTimeArray(sy,sm,ey,em);
		} else if (endYear.compareTo(startYear) == 0) {
			if (endMonth.compareTo(startMonth) <= 0) {
				//搜索开始时间不能大于结束时间
				Toast.makeText(this, "搜索开始时间不能大于结束时间", 0).show();
			} else {
				getTimeArray(sy,sm,ey,em);
			}
		} else {
			//搜索开始时间不能大于结束时间
			Toast.makeText(this, "搜索开始时间不能大于结束时间", 0).show();
		}
	}
	
	private void getTimeArray(int sy, int sm, int ey, int em) {
		if(ey==sy){
			for (int i = sm; i <= em; i++) {
				timeArrays.add(String.valueOf(sy)+"-"+String.valueOf(i));
			}
		}else {
			int index = 1;
			for (int i = sy; i <= ey; i++) {
				int bm = 1;
				int tem = 12;
				if (i == sy) {
					bm = sm;
					tem = 12;
				} else if (i == ey) {
					bm = 1;
					tem = em;
				}
				for (int j = bm; j <= tem; j++) {
					timeArrays.add(String.valueOf(i)+"-"+String.valueOf(j));
					mRenderer.addXTextLabel(index++, String.valueOf(i)+"-"+String.valueOf(j));
				}
			}
		}
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					List<ResultItem> resultItems = item.getItems("data");
					getChartData(resultItems);
				}
			}
		}
	};

	private void initData() {
			//年份设置
			moreListYear = new ArrayList<Map<String,String>>();
			Map<String,String> mapYear;
			mapYear = new HashMap<String, String>();
			mapYear.put("key", "请选择");
			moreListYear.add(mapYear);
			for (int i = 0; i < 3; i++) {
				mapYear = new HashMap<String , String>();
				mapYear.put("key", String.valueOf(2014+i)+" 年");
				moreListYear.add(mapYear);
			}
			
			//月份设置
			moreListMonth = new ArrayList<Map<String,String>>();
			Map<String, String> mapMonth ;
			mapMonth = new HashMap<String,String>();
			mapMonth.put("key", "请选择");
			moreListMonth.add(mapMonth);
			for (int i = 0; i < 12; i++) {
				mapMonth = new HashMap<String,String>();
				mapMonth.put("key", String.valueOf(1+i)+" 月");
				moreListMonth.add(mapMonth);
			}
		xType = getIntent().getStringExtra("XTYPE");
		yType = getIntent().getStringExtra("YTYPE");
		invoke = new InvokeHelper(this);
		setYearAndMonth();
		invoke.invokeWidthDialog(
				OAInterface.getTarget(xType, yType, "", "", "", ""),
				callBack);
		
	}

	protected void getChartData(List<ResultItem> resultItems) {
		System.out.println("getChartData()");
		if (null == chartDatas) {
			chartDatas = new ArrayList<TargetInfo>();
		} else {
			chartDatas.clear();
		}
		if (!BeanUtils.isEmpty(resultItems)) {
			String tempY = "";
			String tempM = "";
			String type = "";
			String xh = "";
			String year = "";
			String month = "";
			String zb = "";
			for (int i = 0; i < timeArrays.size(); i++) {
				tempY = timeArrays.get(i).split("-")[0];
				tempM = timeArrays.get(i).split("-")[1];
				for (ResultItem item : resultItems) {
					type = item.getString("TYPE");
					year = item.getString("YEAR");
					month = item.getString("MONTH");
					if (tempY.equals(year) && tempM.equals(month)) {
						zb = item.getString("ZB");
						xh = item.getString("XH");
						break;
					}
	//				yDatas.add(zb);
	//				xDatas.add(year + "-" + month);
				}
				chartDatas.add(new TargetInfo(year, month, type, xh, zb));
				System.out.println("fsafjslajf"+chartDatas.get(0).getNum());
			}
		}
//		yDatas = new ArrayList<String>(resultItems.size());
//		xDatas = new ArrayList<String>(resultItems.size());
		System.out.println("asdasd"+chartDatas.get(0).getNum());
		updateLineChart();
	}

	private void init_chart() {
		chart = (RelativeLayout) findViewById(R.id.chart);
		Button bt_bar_chart = (Button) findViewById(R.id.bt_bar_chart);
		Button bt_line_chart = (Button) findViewById(R.id.bt_line_chart);
		bt_bar_chart.setOnClickListener(this);
		bt_line_chart.setOnClickListener(this);
		intitLineChart();
		intitBarChart();
	}
   
	private void intitLineChart() {
//		 ****添加曲线***** 
		// mRenderer.setXTitle("ppi"); // 设置为X轴的标题
		// mRenderer.setYTitle("数值"); // 设置为Y轴的标题
		// mRenderer.setChartTitle("achartengine折线图"); // 设置图表标题
		mRenderer.setMargins(new int[] { 150, 50, 100, 20 }); // 上左下右边距
		mRenderer.setAxisTitleTextSize(50); // 设置轴标题文本大小
		// mRenderer.setLabelsColor(Color.rgb(0xD2, 0x69, 0x1E)); // 坐标名称及标题颜色
		mRenderer.setXLabelsColor(Color.BLACK);// 设置X轴刻度颜色
		mRenderer.setYLabelsColor(0, Color.BLACK);// 设置Y轴刻度颜色
		mRenderer.setChartTitleTextSize(50);// 设置图表标题文字的大小
		mRenderer.setLabelsTextSize(ScreenUtils.px2dp(this, 50));// 设置标签的文字大小
		mRenderer.setYLabels(7);// 设置Y轴刻度个数
		mRenderer.setYLabelsAlign(Paint.Align.RIGHT); // 设置刻度线与Y轴之间的相对位置关系
		mRenderer.setClickEnabled(false);
		mRenderer.setZoomEnabled(true); // 设置是否可以滑动及放大缩小;
		mRenderer.setPanEnabled(true);
		mRenderer.setApplyBackgroundColor(true); // 设置背景颜色可应用
		mRenderer.setBackgroundColor(Color.WHITE); // 内部颜色
		mRenderer.setMarginsColor(Color.WHITE); // 外部颜色
		mRenderer.setShowLegend(true); // 隐藏曲线以外的部分
		mRenderer.setLegendHeight(100);
		mRenderer.setLegendTextSize(ScreenUtils.px2dp(this, 50));
		mRenderer.setSelectableBuffer(10);

		mRenderer.setShowGrid(true);// 显示网格
		mRenderer.setShowGridX(true);
		mRenderer.setGridColor(Color.GRAY);
		mRenderer.setYAxisMax(120.0);
		mRenderer.setYAxisMin(0.0);
		mRenderer.setXAxisMin(0.5); // 设置x轴最小值
		mRenderer.setXAxisMax(4 + 0.5); // 设置x轴最大值
		mRenderer.setAxesColor(Color.parseColor("#4488BB"));// 设置坐标轴的颜色
		mRenderer.setXLabels(0);
		mRenderer.setPanEnabled(true, false);// 设置滑动,这边是横向可以滑动,竖向不可滑动
	}
	
	private void updateLineChart() {
		if(xType.equals("3")){
			if(yType.equals("1")){
				series1 = new XYSeries("工业增值", 0); // XY坐标序列
			}else if(yType.equals("2")){
				series1 = new XYSeries("主营业务", 0); // XY坐标序列
			}else if (yType.equals("3")){
				series1 = new XYSeries("全市利润", 0); // XY坐标序列
			}else if (yType.equals("4")){
				series1 = new XYSeries("全市利税", 0); // XY坐标序列
			}else if (yType.equals("5")){
				series1 = new XYSeries("固定投资", 0); // XY坐标序列
			}else if (yType.equals("6")){
				series1 = new XYSeries("工业税收", 0); // XY坐标序列
			}else if (yType.equals("7")){
				series1 = new XYSeries("工业贷款", 0); // XY坐标序列
			}
		}else{
			if(yType.equals("1")){
				series1 = new XYSeries("cpi", 0); // XY坐标序列
			}else if(yType.equals("2")){
				series1 = new XYSeries("ppi", 0); // XY坐标序列
			}else if (yType.equals("3")){
				series1 = new XYSeries("pmi", 0); // XY坐标序列
			}else if (yType.equals("4")){
				series1 = new XYSeries("工业增值", 0); // XY坐标序列
			}else if (yType.equals("5")){
				series1 = new XYSeries("主营业务", 0); // XY坐标序列
			}else if (yType.equals("6")){
				series1 = new XYSeries("利润增速", 0); // XY坐标序列
			}
		}
		
		
//		 设置坐标点 
		// series1.add(0,101);
		// series1.add(1,102);
		// series1.add(2,403);
		if (!BeanUtils.isEmpty(chartDatas)) {
			String tempY = "";
			String tempM = "";
			String year = "";
			String month = "";
			for (int i = 0; i < timeArrays.size(); i++) {
				tempY = timeArrays.get(i).split("-")[0];
				tempM = timeArrays.get(i).split("-")[1];
				for (TargetInfo charts : chartDatas) {
					year = charts.getYear();
					month = charts.getMonth();
					if (tempY.equals(year) && tempM.equals(month)) {
						series1.add(i + 1, Float.valueOf(chartDatas.get(i).getNum()));
						break;
					}
				}
			}
			mDataset.clear();
			mDataset.addSeries(series1);
		}
//		 曲线1 
		renderer1 = new XYSeriesRenderer();
		renderer1.setPointStyle(PointStyle.CIRCLE); // 坐标点形式
		renderer1.setPointStrokeWidth(10); // 坐标点的大小
		renderer1.setColor(Color.parseColor("#FF7F50")); // 温度线红色 温度
		renderer1.setLineWidth(3); // 线宽3
		renderer1.setDisplayChartValues(true);// 将点的值显示出来
		renderer1.setChartValuesSpacing(30);// 显示的点的值与图的距离
		renderer1.setChartValuesTextAlign(Align.CENTER);
		renderer1.setChartValuesTextSize(30);// 点的值的文字大小
		java.text.DecimalFormat df = new java.text.DecimalFormat("#.0");
		renderer1.setChartValuesFormat(df);// 设置折线点的值的格式,显示小数点后2位
		mRenderer.removeAllRenderers();
		mRenderer.addSeriesRenderer(renderer1);
		mChartView = ChartFactory.getCubeLineChartView(this, mDataset,
				mRenderer, 0.3f);
		chart.removeAllViews();
		chart.addView(mChartView, new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		mChartView.repaint();
	}

	private void intitBarChart() {
//		 ****添加曲线***** 
		// mRenderer.setXTitle("ppi"); // 设置为X轴的标题
		// mRenderer.setYTitle("数值"); // 设置为Y轴的标题
		// mRenderer.setChartTitle("achartengine折线图"); // 设置图表标题
		mRenderer.setMargins(new int[] { 150, 50, 100, 20 }); // 上左下右边距
		mRenderer.setAxisTitleTextSize(50); // 设置轴标题文本大小
		// mRenderer.setLabelsColor(Color.rgb(0xD2, 0x69, 0x1E)); // 坐标名称及标题颜色
		mRenderer.setXLabelsColor(Color.BLACK);// 设置X轴刻度颜色
		mRenderer.setYLabelsColor(0, Color.BLACK);// 设置Y轴刻度颜色
		mRenderer.setChartTitleTextSize(50);// 设置图表标题文字的大小
		mRenderer.setLabelsTextSize(30);// 设置标签的文字大小
		mRenderer.setYLabels(7);// 设置Y轴刻度个数
		mRenderer.setYLabelsAlign(Paint.Align.RIGHT); // 设置刻度线与Y轴之间的相对位置关系
		mRenderer.setClickEnabled(false);
		mRenderer.setZoomEnabled(true); // 设置是否可以滑动及放大缩小;
		mRenderer.setPanEnabled(true);
		mRenderer.setApplyBackgroundColor(true); // 设置背景颜色可应用
		mRenderer.setBackgroundColor(Color.WHITE); // 内部颜色
		mRenderer.setMarginsColor(Color.WHITE); // 外部颜色
		mRenderer.setShowLegend(true); // 隐藏曲线以外的部分
		mRenderer.setLegendHeight(100);
		mRenderer.setLegendTextSize(50);
		mRenderer.setSelectableBuffer(10);

		mRenderer.setShowGrid(true);// 显示网格
		mRenderer.setShowGridX(true);
		mRenderer.setGridColor(Color.GRAY);
		mRenderer.setYAxisMax(120.0);
		mRenderer.setYAxisMin(0.0);
		mRenderer.setXAxisMin(0.5); // 设置x轴最小值
		mRenderer.setXAxisMax(4 + 0.5); // 设置x轴最大值
		mRenderer.setAxesColor(Color.parseColor("#4488BB"));// 设置坐标轴的颜色
		mRenderer.setXLabels(0);
		mRenderer.setPanEnabled(true, false);// 设置滑动,这边是横向可以滑动,竖向不可滑动
		mRenderer.setBarSpacing(0.5f);// 柱形图间隔

	}
	
	private void updateBarChart() {
		if(xType.equals("3")){
			if(yType.equals("1")){
				series1 = new XYSeries("工业增值", 0); // XY坐标序列
			}else if(yType.equals("2")){
				series1 = new XYSeries("主营业务", 0); // XY坐标序列
			}else if (yType.equals("3")){
				series1 = new XYSeries("全市利润", 0); // XY坐标序列
			}else if (yType.equals("4")){
				series1 = new XYSeries("全市利税", 0); // XY坐标序列
			}else if (yType.equals("5")){
				series1 = new XYSeries("固定投资", 0); // XY坐标序列
			}else if (yType.equals("6")){
				series1 = new XYSeries("工业税收", 0); // XY坐标序列
			}else if (yType.equals("7")){
				series1 = new XYSeries("工业贷款", 0); // XY坐标序列
			}
		}else{
			if(yType.equals("1")){
				series1 = new XYSeries("cpi", 0); // XY坐标序列
			}else if(yType.equals("2")){
				series1 = new XYSeries("ppi", 0); // XY坐标序列
			}else if (yType.equals("3")){
				series1 = new XYSeries("pmi", 0); // XY坐标序列
			}else if (yType.equals("4")){
				series1 = new XYSeries("工业增值", 0); // XY坐标序列
			}else if (yType.equals("5")){
				series1 = new XYSeries("主营业务", 0); // XY坐标序列
			}else if (yType.equals("6")){
				series1 = new XYSeries("利润增速", 0); // XY坐标序列
			}
		}
		
		if (!BeanUtils.isEmpty(chartDatas)) {
			String tempY = "";
			String tempM = "";
			String year = "";
			String month = "";
			for (int i = 0; i < timeArrays.size(); i++) {
				tempY = timeArrays.get(i).split("-")[0];
				tempM = timeArrays.get(i).split("-")[1];
				for (TargetInfo charts : chartDatas) {
					year = charts.getYear();
					month = charts.getMonth();
					if (tempY.equals(year) && tempM.equals(month)) {
						series1.add(i + 1, Float.valueOf(chartDatas.get(i).getNum()));
						break;
					}
				}
			}
			mDataset.clear();
			mDataset.addSeries(series1);
		}
//		 曲线1 
		renderer1 = new XYSeriesRenderer();
		renderer1.setPointStyle(PointStyle.CIRCLE); // 坐标点形式
		renderer1.setPointStrokeWidth(30); // 坐标点的大小
		renderer1.setColor(Color.parseColor("#FF7F50")); // 温度线红色 温度
		renderer1.setLineWidth(3); // 线宽3
		renderer1.setDisplayChartValues(true);// 将点的值显示出来
		renderer1.setChartValuesSpacing(30);// 显示的点的值与图的距离
		renderer1.setChartValuesTextAlign(Align.RIGHT);
		renderer1.setChartValuesTextSize(30);// 点的值的文字大小
		java.text.DecimalFormat df = new java.text.DecimalFormat("#.0");
		renderer1.setChartValuesFormat(df);// 设置折线点的值的格式,显示小数点后2位
		mRenderer.removeAllRenderers();
		mRenderer.addSeriesRenderer(renderer1);
		mChartView = ChartFactory.getBarChartView(this, mDataset, mRenderer,
				Type.DEFAULT);
		chart.removeAllViews();
		chart.addView(mChartView, new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		mChartView.repaint();
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.bt_bar_chart:
//			if(BeanUtils.isEmpty(chartDatas)){
//				intitBarChart();
//				return;
//			}else{
				updateBarChart();
//			}
			break;
		case R.id.bt_line_chart:
//			if(BeanUtils.isEmpty(chartDatas)){
//				intitLineChart();
//				return;
//			}else{
				updateLineChart();
//			}
			break;
		case R.id.tv_start_year:
		    initPopupWindow(moreListYear,tv_start_year);
		    int xPosStartYear = (-pwMyPopWindow.getWidth() / 2)-(tv_start_year.getWidth() / 3);
		    pwMyPopWindow.showAsDropDown(tv_start_year, xPosStartYear, 10);
			break;
		case R.id.tv_start_month:
			initPopupWindow(moreListMonth,tv_start_month);
			int xPosStartMonth = (-pwMyPopWindow.getWidth() / 2)-(tv_start_year.getWidth() / 3);
	    	 pwMyPopWindow.showAsDropDown(tv_start_month, xPosStartMonth, 10);
			break;
		case R.id.tv_end_year:
			initPopupWindow(moreListYear,tv_end_year);
			int xPosEndYear = (-pwMyPopWindow.getWidth() / 2)-(tv_start_year.getWidth() / 3);
	    	 pwMyPopWindow.showAsDropDown(tv_end_year, xPosEndYear, 10);
			break;
		case R.id.tv_end_month:
			initPopupWindow(moreListMonth,tv_end_month);
			int xPosEndMonth = (-pwMyPopWindow.getWidth() / 2)-(tv_start_year.getWidth() / 3);
	    	pwMyPopWindow.showAsDropDown(tv_end_month, xPosEndMonth, 10);
			break;
		case R.id.tv_search:
			String startYear = tv_start_year.getText().toString().trim();
			String startMonth = tv_start_month.getText().toString().trim();
			String endYear = tv_end_year.getText().toString().trim();
			String endMonth = tv_end_month.getText().toString().trim();
//			if (BeanUtils.isEmpty(chartDatas)) {
//				timeArrays.clear();
//				setYearAndMonth();
//				invoke.invokeWidthDialog(OAInterface.getTarget(xType,yType, startYear, startMonth, endYear, endMonth),callBack);
//			}else {
				chartDatas.clear();
				timeArrays.clear();
				setYearAndMonth();
				invoke.invokeWidthDialog(OAInterface.getTarget(xType,yType, startYear, startMonth, endYear, endMonth),callBack);
//			}
			
//			intitBarChart();
			
			break;
		default:
			break;
		}
	}
}
