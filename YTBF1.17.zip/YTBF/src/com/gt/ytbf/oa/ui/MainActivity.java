package com.gt.ytbf.oa.ui;
	
import java.util.ArrayList;
import java.util.List;
	
import android.app.Activity;
import android.app.ActivityGroup;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.LocalActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;
import cn.jpush.android.api.JPushInterface;

import com.gt.ytbf.oa.OADroid;
import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.ApiRequest;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseHandler;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.RollItem;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.LogUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.ScreenUtils;
import com.gt.ytbf.oa.ui.view.AutoRollLayout;
import com.gt.ytbf.oa.ui.view.AutoRollLayout.OnItemClickListener;
import com.gt.ytbf.oa.ui.view.FloatManager;
import com.gt.ytbf.oa.ui.view.FloatView;
	
/** 
 *  程序主界面
 * */
public class MainActivity extends ActivityGroup implements OnClickListener {
	
	private static final String TAG = MainActivity.class.getSimpleName();
	
	private static final int FIRST_INDEX = 0;
	private static final int SECOND_INDEX = 1;
	private static final int THIRD_INDEX = 2;
	
	private LinearLayout firstLay;
	private LinearLayout secondLay;
	private LinearLayout thirdLay;
	private LinearLayout forthLay;
	/** 标示当前显示的界面*/
	private LinearLayout currrentLay;
	
	/**
	 * 界面容器
	 * */
	public ViewGroup container;
	private LocalActivityManager localActivityManager;
	
	/**
	 * 点击返回键的时间间隔
	 * */
	private final long timeElapse = 2000;
	/**
	 * 第一次点击返回键的时间
	 * */
	private long firstClickBack;
	
	private RadioButton radioBtn0,radioBtn1,radioBtn2;
	
	private ArrayList<RadioButton> radioGroups = new ArrayList<RadioButton>();
	
	/**
	 * 保存当前界面状态信息
	 * */
	
	private String activityTag;
	private Intent intentState;
	private static MainActivity instance;
	private List<RollItem> rollItemList=new ArrayList<RollItem>();
	private AutoRollLayout rollLayout;
	
	private int[] tabSelectImgs = {R.drawable.blue_icon_news, R.drawable.white_icon_gz_02, 
			R.drawable.blue_icon_jingji};
	private int[] tabUnselectImgs = {R.drawable.gray_icon_news, R.drawable.white_icon_gz, 
			R.drawable.gray_icon_jingji};
	
	private AlertDialog mExitDialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		JPushInterface.init(this);
		initView();
		instance = this;
		setMainActivity();
	}
	
	/**
	 * 初始化界面控件
	 * */
	private void initView() {
		container = (ViewGroup) findViewById(R.id.main_container);
		localActivityManager = getLocalActivityManager();
		/** tabhost 下面的四个按钮*/
		radioBtn0 = ((RadioButton) findViewById(R.id.radio_button0));
		radioBtn1 = ((RadioButton) findViewById(R.id.radio_button1));
		radioBtn2 = ((RadioButton) findViewById(R.id.radio_button2));
		radioGroups.add(radioBtn0);
		radioGroups.add(radioBtn1);
		radioGroups.add(radioBtn2);
		for (RadioButton button : radioGroups) {
			button.setOnClickListener(this);
		}
	}
	
	/**
	 * 加载新闻
	 * */
	private void loadNews() {
		new InvokeHelper(this).invoke(OAInterface.getNewsList("1", "1"), callBack);
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (!BeanUtils.isEmpty(item)) {
				if (Constants.SUCCESS_CODE.equals(item.get("code"))) {
					List<ResultItem> resultItems = item.getItems("data");
					if (BeanUtils.isEmpty(resultItems)) {
						return;
					}
					List<RollItem> items = new ArrayList<RollItem>();
					for (ResultItem resultItem : resultItems) {
						String title=resultItem.getString("TITLE");
						String ctime=resultItem.getString("CTIME");
						String id = resultItem.getString("ID");
						String type = resultItem.getString("DESTYPE");
						String imgUrl = resultItem.getString("IMG");
						Log.i("imgUrl", " imgUrl "+imgUrl);
						if (items.size() >= 3) {
							updateRolls(items);
							break;
						}
						if (!BeanUtils.isNullOrEmpty(imgUrl)) {
							items.add(new RollItem(id, title, imgUrl));
						}
					}
				}
			}
		}
		
	};
		
	/** 
     * 能将Activity容器内的Activity移除，再将指定的某个Activity加入
     * @param activityName 加载的Activity在localActivityManager中的名字
     */	
		
	protected void setContainerView(String activityName, Intent intent){
        if(null == localActivityManager){
            localActivityManager = getLocalActivityManager();
        }
        
        //移除内容部分全部的View
        container.removeAllViews();
        
        Activity contentActivity = localActivityManager.getActivity(activityName);
//        if (null == contentActivity) {
        	intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            localActivityManager.startActivity(activityName, intent);
//        }
        
        //加载Activity
        container.addView(
                localActivityManager.getActivity(activityName)
                        .getWindow().getDecorView(),
                new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,
                        LayoutParams.MATCH_PARENT));
        
        activityTag = activityName;
        intentState = intent;
    }
	
	/**
	 * 界面跳转
	 * */
	public void startActivity(Class cls, int index) {
		LogUtils.d(TAG, "startActivity: " + cls.getName());
		if (null != cls
//				&& !cls.getName().equals(activityTag)
				) {
			LogUtils.d(TAG, "startActivity into if ");
			Intent intent = new Intent(this, cls);
			intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			setContainerView(cls.getName(), intent);
		}
	}
	
	
	
	public static MainActivity getInstance() {
		return instance;
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.radio_button0:
			//新闻
			showCurrentView(FIRST_INDEX, PolicyNewsActivity.class);
			break;
		case R.id.radio_button1:
			//主页
			setMainActivity();
			break;
		case R.id.radio_button2:
			//经济运行
			showEconomicalView();
			break;
			default :
				break;
		}
	}
	
	private void showEconomicalView() {
		String userLevel = LoginUtils.getInstance().getUserInfo().getUserLevel();
		if ("1".equals(userLevel) || "3".equals(userLevel)) {
			showCurrentView(THIRD_INDEX, EconomicalOperationAcitivityQY.class);
		}else {
			showCurrentView(THIRD_INDEX, EconomicalOperationAcitivity.class);
		}
	}

	public void setMainActivity() {
		String userLevel = LoginUtils.getInstance().getUserInfo().getUserLevel();
		if ("1".equals(userLevel)) {
			showCurrentView(SECOND_INDEX, MainEntryActivityQY.class);
		} else if ("2".equals(userLevel)) {
			showCurrentView(SECOND_INDEX, MainEntryActivityPD.class);
		} else if ("3".equals(userLevel)) {
			showCurrentView(SECOND_INDEX, MainEntryActivityZN.class);
		} else if ("4".equals(userLevel)||"5".equals(userLevel)) {
			showCurrentView(SECOND_INDEX, MainEntryActivityGD.class);
		}
	}

	private void showCurrentView(int index, Class cls) {
		Drawable img_on, img_off;
		for (int i = 0; i < radioGroups.size(); i++) {
			RadioButton button = radioGroups.get(i);
            if (index == i) {
                if (i != SECOND_INDEX) {
                    img_on = getResources().getDrawable(tabSelectImgs[i]);
                    //调用setCompoundDrawables时，必须调用Drawable.setBounds()方法,否则图片不显示
                    img_on.setBounds(0, 0, img_on.getMinimumWidth(), img_on.getMinimumHeight());
                    button.setCompoundDrawables(null, img_on, null, null);
                }
                button.setTextColor(getResources().getColor(R.color.green));
                continue;
            }
            if (i != SECOND_INDEX) {
                img_off = getResources().getDrawable(tabUnselectImgs[i]);
                img_off.setBounds(0, 0, img_off.getMinimumWidth(), img_off.getMinimumHeight());
                button.setCompoundDrawables(null, img_off, null, null);
            }
			button.setTextColor(getResources().getColor(R.color.bottom_txt));
		}
		startActivity(cls, index);
	}
	
	@Override
	public void onBackPressed() {
		LogUtils.d(TAG, "onBackPressed()");
//		if (mMenu.isOpen) {
//			mMenu.closeMenu();
//			return;
//		}
		if (System.currentTimeMillis() - firstClickBack <= timeElapse) {
			LoginUtils.getInstance().setIsLoginSuccess(false);
			doLogout();
		} else {
			firstClickBack = System.currentTimeMillis();
			Toast.makeText(this, R.string.toast_double_click_back_logout, Toast.LENGTH_LONG).show();
		}
	}
	
	/**
	 * 退出程序
	 * */
	private void doLogout() {
		LoginUtils.getInstance().logout();
		OADroid.getInstance().onTerminate();
		android.os.Process.killProcess(android.os.Process.myPid());
		System.exit(0);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
//		if ("3".equals(userLevel) || "4".equals(userLevel)) {
//			FloatManager.createSmallWindow(this);
//		}
	}
	
	@Override
	protected void onStop() {
		super.onStop();
//		FloatManager.removeBigWindow(this);
//		FloatManager.removeSmallWindow(this);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (null != mExitDialog) {
		    mExitDialog.dismiss();
		}
	}
	
	/**
	 * 正在推出对话框
	 * 
	 * @return 对话框实体
	 */
	protected Dialog createExitRunning(Context activityContext) {
		mExitDialog = new AlertDialog.Builder(activityContext)
				.setCancelable(false)
				.setView(
						LayoutInflater.from(activityContext).inflate(
								R.layout.exit_dialog, null)).create();
		return mExitDialog;
	}
	
	public void updateRolls(List<RollItem> items) {
		if (items != rollItemList && !BeanUtils.isEmpty(items)) {
			rollItemList.clear();
			if (items.size() > 3) {
				rollItemList.addAll(items.subList(0, 3));
			}
			rollItemList.addAll(items);
		}
		if (null != rollLayout) {
			rollLayout.setData(rollItemList);
			rollLayout.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(RollItem rollItem) {
					if (null == rollItem || BeanUtils.isNullOrEmpty(rollItem.getId())) {
						return;
					}
					Intent intent = new Intent(rollLayout.getContext(), NewsDetailActivity.class);	
					intent.putExtra("id", rollItem.getId());	
					intent.putExtra("title", rollItem.getTitle());
					rollLayout.getContext().startActivity(intent);
				}
				
			});
		}
	}
	
	public List<RollItem> getRollList() {
		if (rollItemList.size() <= 0) {
//	        rollItemList.add(new RollItem("张晓明赴鹰潭开展“降低企业成本、优化发展环境”专项行动政策宣讲和调研",R.drawable.news_01));
//	        rollItemList.add(new RollItem("张晓明赴鹰潭开展“降低企业成本、优化发展环境”专项行动政策宣讲和调研",R.drawable.news_02));
//	        rollItemList.add(new RollItem("洪礼和赴挂点联系园区调研并作政策宣讲动员", R.drawable.news_03));
	        rollItemList.add(new RollItem("",R.drawable.actionsheet_top_normal));
	        rollItemList.add(new RollItem("",R.drawable.actionsheet_top_normal));
	        rollItemList.add(new RollItem("", R.drawable.actionsheet_top_normal));
		}
		return rollItemList;
	}
	
	public void setRollLayout(AutoRollLayout layout) {
		this.rollLayout = layout;
		if (rollItemList.size() <= 0) {
			loadNews();
		} else {
			updateRolls(rollItemList);
		}
//		updateRolls(getRollList());
	}

}
