package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.IndustryTargetInfo;
import com.gt.ytbf.oa.bean.MainIndustryInfo;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MainIndustryDetailAdapter extends BaseAdapter{
	
	private Context mContext;
	private List<MainIndustryInfo> mData;
	private int type;
	public  MainIndustryDetailAdapter(Context context,List<MainIndustryInfo> mData, int pagetypeone) {
		this.mContext = context;
		this.mData = mData;
		this.type = pagetypeone;
	}
	
	
	@Override
	public int getCount() {
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.activity_main_detail_item,
					null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);
			hodler.tv_table03.setVisibility(View.GONE);
			hodler.tv_table04 = (TextView) convertView.findViewById(R.id.tv_table04);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		if(1==type){
	    	 hodler.tv_table1.setText(mData.get(position).getFl());
	    	 hodler.tv_table01.setText(mData.get(position).getQygs());
			 hodler.tv_table02.setText(mData.get(position).getZbylj());
			 hodler.tv_table03.setText(mData.get(position).getZqntq());
			 hodler.tv_table04.setText(mData.get(position).getZtb());
	     }else if(2==type){
	    	 hodler.tv_table1.setText(mData.get(position).getFl());
	    	 hodler.tv_table01.setText(mData.get(position).getQygs());
			 hodler.tv_table02.setText(mData.get(position).getGbylj());
			 hodler.tv_table03.setText(mData.get(position).getGqntq());
			 hodler.tv_table04.setText(mData.get(position).getGtb());
	     }else{
	    	 hodler.tv_table1.setText(mData.get(position).getFl());
	    	 hodler.tv_table01.setText(mData.get(position).getQygs());
			 hodler.tv_table02.setText(mData.get(position).getLbylj());
			 hodler.tv_table03.setText(mData.get(position).getLqntq());
			 hodler.tv_table04.setText(mData.get(position).getLtb());
	     }
		
		return convertView;
	}
	
	final class ViewHolder {
		TextView tv_table1, tv_table01, tv_table02, tv_table03, tv_table04;
	}
}
