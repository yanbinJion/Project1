package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gt.ytbf.oa.OADroid;
import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.LogUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.SharePreferenceUtil;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.view.ContentView;
import com.gt.ytbf.oa.ui.view.GestureDrawl.GestureCallBack;


/**
 * Filename : GesturesPasswordActivity
 * 
 * @Description : 手势密码
 */
public class LoginGesturesPasswordActivity extends BaseActivity implements OnClickListener{

	private FrameLayout gesturespwdLayout;

	private ContentView content;

	private int errorNumber = 5;

	private TextView msgView;

	/**解锁屏幕*/
	private boolean isLock;

	private boolean isGotoMain;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gestures_password);
		initView();
	}
	
	private void initView() {
		isGotoMain = getIntent().getBooleanExtra("gotoMain", false);
		gesturespwdLayout = (FrameLayout) findViewById(R.id.gesturespwd_layout);
		msgView = (TextView) findViewById(R.id.pwdMsgView);
		msgView.setText(R.string.gesturespassword_login_title);
		
		findViewById(R.id.tv_change_user).setVisibility(View.GONE);
		findViewById(R.id.tv_forget_pass).setOnClickListener(this);
		((RelativeLayout) findViewById(R.id.user_name_layout)).setVisibility(View.VISIBLE);
		findViewById(R.id.tv_forget_pass).setVisibility(View.VISIBLE);
//		findViewById(R.id.tv_change_user).setVisibility(View.VISIBLE);
		
		spUtils = new SharePreferenceUtil(this);
		String userName = LoginUtils.getInstance().getUserInfo().getName();//用户名称
		String gesturePwd = spUtils.getPatternPwd();
		isLock = spUtils.getPatternState(); 
		
		// 如果查询为空或者被锁定，则跳转到输入用户名和密码页面
		if(isLock && !BeanUtils.isNullOrEmpty(gesturePwd)){
			((TextView) findViewById(R.id.login_user_name)).setText(userName);
			// 初始化一个显示各个点的viewGroup
			content = new ContentView(Constants.GESTURES_OPTTYPE_LOGIN, this,
					gesturePwd, new GestureCallBack() {
						@Override
						public void checkedSuccess() {
							msgView.setTextColor(Color
									.parseColor(getString(R.color.white)));
							msgView.setText(R.string.gesturespassword_login_success);
							//如果是解锁的，则直接进入页面，关闭当前的activity
//							if(!BeanUtils.isEmpty(isLock) && "true".equals(isLock)){
//								finish();
//							}else{
//							}
							if (isGotoMain) {
								gotoMainActivity();
							}
							finish();
						}

						@Override
						public void checkedFail() {
							msgView.setTextColor(Color
									.parseColor(getString(R.color.red)));
							errorNumber--;
							if (errorNumber == 0) {
								toLogin();
							} else {
								msgView.setText("密码错了，还可以输入" + errorNumber + "次");
							}
						}

						@Override
						public void checkedSuccessBack(String param) {
						}
					});
			// 设置手势解锁显示到哪个布局里面
			content.setParentView(gesturespwdLayout);
		} else {
			toLogin();
			return;
		}
	}


	// 跳转到输入用户名和密码页面
	public void toLogin() {
		OADroid.getInstance().onTerminate();
		SharedPreferences sharedPreferences = getSharedPreferences("config", MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putString("usetName", "");
		editor.putString("pwd", "");
		editor.commit();
		Intent intent = new Intent(LoginGesturesPasswordActivity.this, LoginActivity.class);
		intent.putExtra("passwordError", true);
		startActivity(intent);
		finish();
	}
	
	/**
	 * 跳转到主界面
	 */
	private void gotoMainActivity() {
		Intent intent = new Intent(LoginGesturesPasswordActivity.this, MainActivity.class);
		startActivity(intent);
		overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	}

	@Override
	public void onClick(View v) {
		spUtils.savePatternPwd("");
		toLogin();
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		finish();
	}

	@Override
	public void onBackPressed() {
//		if (isGotoMain) {
//			toLogin();
//		}else {
			Intent intent= new Intent(Intent.ACTION_MAIN); 
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
			intent.addCategory(Intent.CATEGORY_HOME);
			startActivity(intent);
//		}
		super.onBackPressed();
	}
}
