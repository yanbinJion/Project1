package com.gt.ytbf.oa.ui;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;

import android.app.Activity;
import android.content.Intent;
import android.database.CursorJoiner.Result;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ModifyPwdActivity extends BaseActivity implements OnClickListener {

	private EditText etOldPwd;
	private EditText etNewPwd;
	private EditText etNewPwdAgain;
	private InvokeHelper invoke;
	private Button okBtn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_motify_pwd);
		initTitleBar("修改密码", this, null);
		initView();
		invoke = new InvokeHelper(this);
		
		
	}
	
	private IRequestCallBack callBack= new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					Toast.makeText(ModifyPwdActivity.this, "密码修改成功", Toast.LENGTH_SHORT).show();
					ModifyPwdActivity.this.finish();
				} else {
					Toast.makeText(ModifyPwdActivity.this, "密码修改失敗: " + item.getString("message"), Toast.LENGTH_SHORT).show();
				}
			}
		}
	};
	
	private void initView() {
		etOldPwd = (EditText) findViewById(R.id.et_old_pwd);
		etNewPwd = (EditText) findViewById(R.id.et_new_pwd);
		etNewPwdAgain = (EditText) findViewById(R.id.et_new_pwd_again);
		okBtn = (Button) findViewById(R.id.modify_pwd_ok_btn);
		okBtn.setOnClickListener(this);
	}
	
	private void click(){
		String oldPwd = etOldPwd.getText().toString().trim();
		String newPwd = etNewPwd.getText().toString().trim();
		String newPwdAgain = etNewPwdAgain.getText().toString().trim();
		if (TextUtils.isEmpty(oldPwd)||TextUtils.isEmpty(newPwd)||TextUtils.isEmpty(newPwdAgain)) {
			Toast.makeText(this, "密码不能为空", Toast.LENGTH_SHORT).show();
			return;
		}
//		if ("2".equals(oldPwd)) {
//			Toast.makeText(this, "当前密码错误", Toast.LENGTH_SHORT).show();
//		}
		if(!newPwd.equals(newPwdAgain)){
			Toast.makeText(this, "密码不一致!", Toast.LENGTH_SHORT).show();
			return;
		}
		invoke.invoke(OAInterface.modifyPass(oldPwd, newPwd), callBack);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.system_back:
			finish();
			break;
		case R.id.modify_pwd_ok_btn:
			click();
			break;
			default:
				break;
		}
	}
}
