package com.gt.ytbf.oa.ui.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.ui.AppealActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-6-20.
 */
public class AppealAdapter extends BaseAdapter {

    private Context mContext;
    private List<AppealCenterModel> mData;
    private int type;
    private static final String TAG = "AppealAdapter";
    public AppealAdapter(Context context, List<AppealCenterModel> data) {
        mContext = context;
        mData = new ArrayList<AppealCenterModel>();
        setData(data);
    }

    public AppealAdapter(Context context, List<AppealCenterModel> data, int type) {
    	 mContext = context;
    	 this.type = type;
         mData = new ArrayList<AppealCenterModel>();
         setData(data);
	}

	public void setData(List<AppealCenterModel> data) {
    	mData.clear();
        if (null != data) {
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        AppealCenterModel model = mData.get(i);
        ViewHolder holder = null;
        if (null == view) {
            view = LayoutInflater.from(mContext).inflate(R.layout.appeal_list_item, null);
            holder = new ViewHolder();
            holder.tv_appeal_title = (TextView) view.findViewById(R.id.tv_appeal_title);
            holder.tv_appeal_type = (TextView) view.findViewById(R.id.tv_appeal_type);
            holder.tv_appeal_content = (TextView) view.findViewById(R.id.tv_appeal_content);
            holder.tv_appeal_state = (TextView) view.findViewById(R.id.tv_appeal_state);
            holder.tv_area = (TextView) view.findViewById(R.id.tv_area);
            holder.tv_appeal_time = (TextView) view.findViewById(R.id.tv_appeal_time);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        if(2==type){
        	 holder.tv_appeal_title.setText(model.getTitle());
        }else{
        	holder.tv_appeal_title.setText(model.getCompanyName());
        }
        holder.tv_appeal_content.setText(model.getAppealContent());
        holder.tv_appeal_state.setText(model.getStatusType());
        holder.tv_appeal_time.setText(model.getAppealTime());
        holder.tv_area.setText(model.getAppealNo());
        if(2==type){
        	Log.i(TAG, "数据解析"+model.getAppealType());
        	if("1".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("融资难");
        	}else if("2".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("招工难、人才却");
        	}else if("3".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("生产要素成本高");
        	}else if("4".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("市场销售不畅");
        	}else if("5".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("创新发展不足");
        	}else if("6".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("企业税费压力大");
        	}else if("7".equals(model.getAppealType())){
        		holder.tv_appeal_type.setText("小微企业创新创业难");
        	}else{
        		holder.tv_appeal_type.setText("其他");
        	}
        }else{
        	holder.tv_appeal_type.setText(model.getAppealType());
        }
        
        return view;
    }

    class ViewHolder {
        public TextView tv_appeal_title;
        public TextView tv_appeal_type;
        public TextView tv_appeal_content;
        public TextView tv_appeal_state;
        public TextView tv_area;
        public TextView tv_appeal_time;
    }
}
