package com.gt.ytbf.oa.ui.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;

public class EconomicalSetupAdapter extends BaseAdapter {
	private String[] items = { "全省主要指标", "全市主要指标",
			"县区主要指标", "园区主要指标", "主要产业主要指标" ,"工业用电"};
	private int[] img = {
			R.drawable.economy_icon_02, R.drawable.economy_icon_03,
			R.drawable.economy_icon_06, R.drawable.economy_icon_07,
			R.drawable.economy_icon_08,R.drawable.economy_icon_05};
	private Context context;

	public EconomicalSetupAdapter(Context context) {
		this.context = context;
	}

	@Override
	public int getCount() {
		return items.length;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = View.inflate(context,
					R.layout.activity_economical_gv, null);
			holder.econ_setup_img = (ImageView) convertView
					.findViewById(R.id.econ_setup_img);
			holder.econ_setup_tv = (TextView) convertView
					.findViewById(R.id.econ_setup_tv);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.econ_setup_img.setImageResource(img[position]);
		holder.econ_setup_tv.setText(items[position]);
		return convertView;
	}

	class ViewHolder {
		private ImageView econ_setup_img;
		private TextView econ_setup_tv;
	}
}
