package com.gt.ytbf.oa.ui;

import android.os.Bundle;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;

/**
 * 个人中心界面 
 * */
public class PersonalActivity extends BaseActivity {
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_personal);
		initTitleBar("个人", null, null);
	}
}
