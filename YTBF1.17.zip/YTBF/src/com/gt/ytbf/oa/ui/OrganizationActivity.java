package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes.Name;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.R.drawable;
import com.gt.ytbf.oa.R.id;
import com.gt.ytbf.oa.R.layout;
import com.gt.ytbf.oa.R.string;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.base.InvokeThread;
import com.gt.ytbf.oa.bean.OrganizationInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;

import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class OrganizationActivity extends BaseActivity implements OnClickListener {
	
	private List<OrganizationInfo> orList;
	private StringBuilder depts = new StringBuilder();
	private StringBuilder names = new StringBuilder();
	private String appealId;
	private ListView lv_organization;
	private TextView searchTxt;
	private EditText contentEdt;
	private List<OrganizationInfo> searchList;
	private OrganizationAdapter mAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_organization);
		appealId = getIntent().getStringExtra("appealId");
		initView();
		loadData();
	}

	private void loadData() {
		orList = new ArrayList<OrganizationInfo>();
		searchList = new ArrayList<OrganizationInfo>();
		mAdapter = new OrganizationAdapter();
		new InvokeHelper(this).invokeWidthDialog(OAInterface.getDepts(appealId), callback);
	}
	
	private IRequestCallBack callback = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
				List<ResultItem> items = (List<ResultItem>) item.getItems("data");
				if (!BeanUtils.isEmpty(items)) {
					for (ResultItem temp : items) {
						String name = temp.getString("NAME");
						String id = temp.getString("ID");
						orList.add(new OrganizationInfo(name, id));
					}
					lv_organization.setAdapter(mAdapter);
					mAdapter.updateList(orList);
				}
			} else {
				String message = item.getString("message");
				Toast.makeText(OrganizationActivity.this, message, Toast.LENGTH_SHORT).show();
			}
			
		}
		
	};

	private void initView() {
		Button system_back = (Button) findViewById(R.id.system_back);
		TextView tv_confirm = (TextView) findViewById(R.id.tv_confirm);
		lv_organization = (ListView) findViewById(R.id.lv_organization);
		searchTxt = (TextView) findViewById(R.id.search_organize_txt);
		contentEdt = (EditText) findViewById(R.id.common_search_content_edt);
		
		system_back.setOnClickListener(this);
		tv_confirm.setOnClickListener(this);
		searchTxt.setOnClickListener(this);
		contentEdt.addTextChangedListener(new TextWatcher() {

			@Override
			public void afterTextChanged(Editable arg0) {
				if (!BeanUtils.isNullOrEmpty(contentEdt.getText().toString())) {
					searchList.clear();
					filterContent(contentEdt.getText().toString());
					mAdapter.updateList(searchList);
				} else {
					mAdapter.updateList(orList);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				
			}
			
		});
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			finish();
			break;
		case R.id.tv_confirm:
			boolean flag = false;
			for (OrganizationInfo org : orList) {
				if (org.isChecked()) {
					if (flag) {
						depts.append(",");
						names.append(",");
					}
					flag = true;
					depts.append(org.getCode());
					names.append(org.getName());
				}
			}
			if (!flag) {
				Toast.makeText(this, R.string.appeal_choose_dept_at_least, Toast.LENGTH_SHORT).show();
				return;
			}
			Intent intent = new Intent();
			intent.putExtra("names", names.toString());
			intent.putExtra("depts", depts.toString());
			OrganizationActivity.this.setResult(2, intent);
			finish();
			break;
		case R.id.search_organize_txt:
			if (!BeanUtils.isNullOrEmpty(contentEdt.getText().toString())) {
				searchList.clear();
				filterContent(contentEdt.getText().toString());
				mAdapter.updateList(searchList);
			} else {
				mAdapter.updateList(orList);
			}
			break;
		default:
			break;
		}
	}
	
	private void filterContent(String content) {
		if (BeanUtils.isNullOrEmpty(content)) {
			return;
		}
		if (!BeanUtils.isEmpty(orList)) {
			for (OrganizationInfo info : orList) {
				if (info.getName().contains(content)) {
					searchList.add(info);
				}
			}
		}
	}

	class OrganizationAdapter extends BaseAdapter{
		
		private ArrayList<OrganizationInfo> data = new ArrayList<OrganizationInfo>();
		
		public void updateList(List<OrganizationInfo> list) {
			data.clear();
			if (!BeanUtils.isEmpty(list)) {
				data.addAll(list);
			}
			notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			return data==null?0:data.size();
		}

		@Override
		public Object getItem(int position) {
			return data.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder holder = null;
	        if (null == convertView) {
	        	convertView = LayoutInflater.from(OrganizationActivity.this).inflate(R.layout.appeal_organization_item, null);
	            holder = new ViewHolder();
	            holder.tv_organization = (TextView) convertView.findViewById(R.id.tv_organization);
	            holder.iv_icon = (ImageView) convertView.findViewById(R.id.iv_icon);
//	            LinearLayout ll_org = (LinearLayout) convertView.findViewById(R.id.ll_org);
	            convertView.setTag(holder);
	        } else {
	            holder = (ViewHolder) convertView.getTag();
	        }
	        final OrganizationInfo organizationInfo = data.get(position);
	        holder.tv_organization.setText(organizationInfo.getName());
	        holder.iv_icon.setSelected(organizationInfo.isChecked());
	        if (holder.iv_icon.isSelected()) {
	        	holder.iv_icon.setImageResource(R.drawable.appeal_selected);
	        }else {
	        	holder.iv_icon.setImageResource(R.drawable.appeal_unselected);
			}
	        convertView.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					organizationInfo.setChecked(!organizationInfo.isChecked());
					notifyDataSetChanged();
				}
			});
	        
	        return convertView;
	    }

	    class ViewHolder {
	        private TextView tv_organization;
	        private ImageView iv_icon;
	        
	    }
	}
}
