package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;

import java.util.ArrayList;
import java.util.List;

public class EconomicalListActivity extends BaseActivity {

    private View.OnClickListener backListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

    private View.OnClickListener homeListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(EconomicalListActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    };
    private List<String> ecList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_economical_list);
        initTitleBar(R.string.function_economical_operation_list, backListener, homeListener);
        initData();
        initView();
        ListView lv_economical_list = (ListView) findViewById(R.id.lv_economical_list);
        lv_economical_list.setAdapter(new EconomicalListAdapter());
        lv_economical_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                startActivity(new Intent(EconomicalListActivity.this,EconomicalListChartActivity.class));
            }
        });
    }

    private void initView() {
        ListView lv_economical_list = (ListView) findViewById(R.id.lv_economical_list);
        lv_economical_list.setAdapter(new EconomicalListAdapter());
    }

    private void initData() {
        ecList = new ArrayList();
        ecList.add("月度PPI增加值图表");
        ecList.add("月度增加值图表");
        ecList.add("月度增加值图表");
    }

    class EconomicalListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return ecList == null ? 0 : ecList.size();
        }

        @Override
        public Object getItem(int position) {
            return ecList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = View.inflate(EconomicalListActivity.this, R.layout.economical_list_item, null);
                holder = new ViewHolder();
                holder.tv_chartName = (TextView) convertView.findViewById(R.id.tv_chartName);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }
            holder.tv_chartName.setText(ecList.get(position));
            return convertView;
        }
    }

    class ViewHolder {

        private TextView tv_chartName;
    }

}
