package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.CompanyInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.RecentAppealAdapter;
import com.gt.ytbf.oa.ui.view.NoScrollListView;

public class CompanyInfoDetailActivity extends BaseActivity {


    public static final String[] ITTILES = new String[]{"企业详情", "企业诉求", "科技创新", "发展规划"};
    
    private static CompanyInfoDetailActivity mContext;
	private LayoutInflater layoutInflater;
	private LinearLayout layout;
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	private CommenViewPagerHelper helper;
	private View companyDetail;
	private View fzgh;
	private View kjcx;
	private Button bt_edit;
	private TextView tv_company_name;
	private EditText tv_register_time;
	private EditText tv_register_money;
	private EditText tv_all_money;
	private EditText tv_owenership_type;
	private EditText tv_org_code;
	private EditText tv_bank_credit_Grating;
	private EditText tv_employees_num;
	private EditText tv_company_addr;
	private EditText tv_contact;
	private EditText tv_manager;
	private EditText tv_company_profile;
	private InvokeHelper invoke;
	private TextView tv_plan;
	private TextView tv_create;
	private View appealView;
	private WebView wb_company_appeal;
	private NoScrollListView lv_appeal_recent;
	private String orgCode;
	private List<AppealCenterModel> recentDatas;

	 private View.OnClickListener backListener = new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	            finish();
	        }
	    };

	    private View.OnClickListener homeListener = new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	        	Intent intent= new Intent(CompanyInfoDetailActivity.this, MainActivity.class);  
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
				startActivity(intent);
	        }
	    };
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpager_company_detail);
        initTitleBar(R.string.function_info, backListener, homeListener);
        loadView();
        initData();
//        initView();
//        initViewPagers(savedInstanceState);
        mContext = this;
    }

    private IRequestCallBack companyInfocallBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					ResultItem basicCompanyItem=item.getItems("basicCompanyInfo").get(0);
					loadCompanyInfo(basicCompanyItem);
					
//					ResultItem jqsqItem= item.getItems("jqsqInfo").get(0);
//					List<ResultItem> jqsqItems=jqsqItem.getItems("jqsq");
//					showRecentList(jqsqItems);
//					
//					ResultItem fzghItem= item.getItems("fzghInfo").get(0);
//					ResultItem kjcxItem= item.getItems("kjcxInfo").get(0);
//					String kjcx=kjcxItem.getString("CXNR");
//					String fzgh=fzghItem.getString("FZGH");
//					tv_create.setText(kjcx);
//					tv_plan.setText(fzgh);
				}	
		}
		
	};
    private void initData() {
		orgCode = getIntent().getStringExtra("OrgCode");
		 invoke = new InvokeHelper(this);
		 invoke.invokeWidthDialog(OAInterface.getCompanyInfo(orgCode), companyInfocallBack);
	}

	protected void showRecentList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			return;
		}
		recentDatas = new ArrayList<AppealCenterModel>(2);
		 for (ResultItem item : resultItems) {
			String title = item.getString("TITLE");
			String content = item.getString("CONTENT");
			String time = item.getString("CTIME");
			String lx = item.getString("LX");
			String state = item.getString("STATUS");
			String bizId=item.getString("BIZID");
			if (recentDatas.size()>1) {
				break;
			}
			recentDatas.add(new AppealCenterModel(bizId,title,lx, content,state, time));
		}
		 loadRecentView();
//		 Toast.makeText(CompanyInfoDetailActivity.this, recentDatas.toString(), Toast.LENGTH_SHORT).show();
	}

	private void loadRecentView() {
		lv_appeal_recent.setAdapter(new RecentAppealAdapter(this, recentDatas));
	}

	protected void loadCompanyInfo(ResultItem item) {
		if (BeanUtils.isEmpty(item)) {
			return;
		}
			String name = item.getString("COMPANY_NAME");
			String registerTime = item.getString("REGISTER_DATE");
			String registerMoney = item.getString("REGISTER_MONEY");
			String allMoney = item.getString("ALL_MONEY");
			String owenershipType = item.getString("OWENERSHIP_TYPE");
			String orgCode = item.getString("ORG_CODE");
			String bankCreditGrating = item.getString("BANK_CREDIT_RATING");
			String employeesNum = item.getString("EMPLOYEES_NUM");
			String address = item.getString("COMPANY_ADDR");
			String contact = item.getString("CONTACT_PHONE");
			String manager = item.getString("MANAGER_PHONE");
			String company_profile = item.getString("COMPANY_PROFILE");
				CompanyInfo companyInfo = new CompanyInfo(name, registerTime, registerMoney,
						allMoney, owenershipType, orgCode,
						bankCreditGrating, employeesNum, contact,
						manager, address,company_profile);
				loadUI(companyInfo);
				return;
		
	}
	@SuppressLint("SetJavaScriptEnabled")
	private void loadUI(CompanyInfo companyInfo) {
        tv_company_name.setText(companyInfo.getName());
        tv_register_time.setText(companyInfo.getRegisterTime());
        tv_register_money.setText(companyInfo.getRegisterMoney());
        tv_all_money.setText(companyInfo.getAllMoney());
        tv_owenership_type.setText(companyInfo.getOwenershipType());
        tv_org_code.setText(companyInfo.getOrgCode());
        tv_bank_credit_Grating.setText(companyInfo.getBankCreditGrating());
        tv_employees_num.setText(companyInfo.getEmployeesNum());
        tv_company_addr.setText(companyInfo.getAddress());
        tv_contact.setText(companyInfo.getContact());
        tv_manager.setText(companyInfo.getManager());
        tv_company_profile.setText(companyInfo.getCompany_profile());
        
//        WebSettings wbSettings = wb_company_appeal.getSettings();
//        //设置WebView属性，能够执行Javascript脚本    
//        wbSettings.setJavaScriptEnabled(true);    
//        //设置可以访问文件  
//        wbSettings.setAllowFileAccess(true);  
//         //设置支持缩放  
//        wbSettings.setBuiltInZoomControls(true);  
//        //加载需要显示的网页    
//        String str="http://218.17.204.4:8889/platform/enterprise/app_comp.jsp?org_no="+orgCode;
//        Log.i("test", str);
//        wb_company_appeal.loadUrl(str);
//        wb_company_appeal.setWebViewClient(new webViewClient());
        
        
	}

	 //Web视图    
    private class webViewClient extends WebViewClient {    
        public boolean shouldOverrideUrlLoading(WebView view, String url) {    
            view.loadUrl(url);    
            return true;    
        }    
    }  
	private void initView() {
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.viewpage);
		
		
    }

    private void initViewPagers(Bundle savedInstanceState) {
    	helper = new CommenViewPagerHelper(CompanyInfoDetailActivity.this, layout);
        helper.onCreate(savedInstanceState);
        List<View> views = new ArrayList<View>();
        companyDetail = layoutInflater.inflate(R.layout.viewpager_company_detail, null);
        views.add(companyDetail);
        appealView = layoutInflater.inflate(R.layout.viewpager_company_appeal, null);
        views.add(appealView);
        fzgh = layoutInflater.inflate(R.layout.viewpager_company_plan_create, null);
        views.add(fzgh);
        kjcx = layoutInflater.inflate(R.layout.viewpager_company_plan_create, null);
        views.add(kjcx);
        for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));
		}
        helper.showViews(mListDatas);
        loadView();
    }

	private void loadView() {
		//企业详情
		tv_company_name = (TextView) findViewById(R.id.tv_company_name);
		tv_register_time = (EditText) findViewById(R.id.et_register_time);
		tv_register_money = (EditText) findViewById(R.id.et_register_money);
		tv_all_money = (EditText) findViewById(R.id.et_all_money);
		tv_owenership_type = (EditText) findViewById(R.id.et_owenership_type);
		tv_org_code = (EditText) findViewById(R.id.et_org_code);
		tv_bank_credit_Grating = (EditText) findViewById(R.id.et_bank_credit_Grating);
		tv_employees_num = (EditText) findViewById(R.id.et_employees_num);
		tv_company_addr = (EditText) findViewById(R.id.et_company_addr);
		tv_contact = (EditText) findViewById(R.id.et_contact);
		tv_manager = (EditText) findViewById(R.id.et_manager);
		tv_company_profile = (EditText) findViewById(R.id.et_company_profile);
		bt_edit = (Button) findViewById(R.id.bt_edit);
//		//企业诉求
//		ScrollView scrollview = (ScrollView) appealView.findViewById(R.id.scrollview);
//		scrollview.scrollTo(0, 20);
//		wb_company_appeal = (WebView) appealView.findViewById(R.id.wb_company_appeal);
//		lv_appeal_recent = (NoScrollListView) appealView.findViewById(R.id.lv_appeal_recent);
//		lv_appeal_recent.setFocusable(false);
//		lv_appeal_recent.setOnItemClickListener(new OnItemClickListener() {
//
//			@Override
//			public void onItemClick(AdapterView<?> parent, View view,
//					int position, long id) {
//				if (recentDatas.size() <= position) {
//					return;
//				}
//				Intent intent = new Intent(new Intent(CompanyInfoDetailActivity.this,AppealCenterActivity.class));
//				Bundle bundle = new Bundle();
//				bundle.putSerializable("appealInfo",recentDatas.get(position));
//				intent.putExtras(bundle);
//				startActivity(intent);
//			}
//		});
//		LinearLayout ll_load_more = (LinearLayout) appealView.findViewById(R.id.ll_load_more);
//		ll_load_more.setOnClickListener(this);
//		//科技创新和发展规划
//		tv_plan = (TextView) fzgh.findViewById(R.id.tv_plan_create);
//		tv_create = (TextView) kjcx.findViewById(R.id.tv_plan_create);
		//企业信息修改
		bt_edit.setVisibility(View.GONE);
		if ("1".equals(LoginUtils.getInstance().getUserInfo().getUserLevel())) {
			bt_edit.setVisibility(View.VISIBLE);
		bt_edit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Button edit=(Button) v;
				if (edit.isSelected()) {
					tv_company_name.setVisibility(View.VISIBLE);
					tv_register_time.setEnabled(false);
					tv_register_money.setEnabled(false);
					tv_all_money.setEnabled(false);
					tv_owenership_type.setEnabled(false);
					tv_org_code.setEnabled(false);
					tv_bank_credit_Grating.setEnabled(false);
					tv_employees_num.setEnabled(false);
					tv_company_addr.setEnabled(false);
					tv_contact.setEnabled(false);
					tv_manager.setEnabled(false);
					tv_company_profile.setEnabled(false);
					edit.setSelected(false);
					String registerTime = tv_register_time.getText().toString().trim();
					String registerMoney = tv_register_money.getText().toString().trim();
					String allMoney = tv_all_money.getText().toString().trim();
					String owenershipType = tv_owenership_type.getText().toString().trim();
					String orgCode = tv_org_code.getText().toString().trim();
					String bankCreditGrating = tv_bank_credit_Grating.getText().toString().trim();
					String employeesNum = tv_employees_num.getText().toString().trim();
					String companyAddr = tv_company_addr.getText().toString().trim();
					String contact = tv_contact.getText().toString().trim();
					String manager = tv_manager.getText().toString().trim();
					String companyProfile = tv_company_profile.getText().toString().trim();
					invoke.invokeWidthDialog(OAInterface.updateCompanyInfo(orgCode,registerTime,registerMoney,
							allMoney,bankCreditGrating,employeesNum,companyAddr,contact,manager,companyProfile,owenershipType), callBack);
				}else {
					tv_company_name.setVisibility(View.GONE);
					tv_register_time.setEnabled(true);
					tv_register_money.setEnabled(true);
					tv_all_money.setEnabled(true);
					tv_owenership_type.setEnabled(true);
					tv_org_code.setEnabled(true);
					tv_bank_credit_Grating.setEnabled(true);
					tv_employees_num.setEnabled(true);
					tv_company_addr.setEnabled(true);
					tv_contact.setEnabled(true);
					tv_manager.setEnabled(true);
					tv_company_profile.setEnabled(true);
					edit.setSelected(true);
				}
			}
		});
		}
		
	}
	
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					CompanyInfoDetailActivity.this.finish();
				}
			}			

		}
			
	};
//	@Override    
//    public boolean dispatchTouchEvent(MotionEvent ev) {   
//        wb_company_appeal.requestDisallowInterceptTouchEvent(true);  
//        return super.dispatchTouchEvent(ev);    
//    } 

	
//	@Override
//	public boolean onTouchEvent(MotionEvent event) {
//		 switch (event.getAction()) {
//		    case MotionEvent.ACTION_MOVE:
//		    	wb_company_appeal.getParent().requestDisallowInterceptTouchEvent(true);
//		    	return true;
//		    case MotionEvent.ACTION_DOWN:
//		    	wb_company_appeal.getParent().requestDisallowInterceptTouchEvent(true);
//		    	return true;
//		    case MotionEvent.ACTION_UP:
//		    	wb_company_appeal.getParent().requestDisallowInterceptTouchEvent(true);
//		    	return true;
//		    }
//		return false;
//	};

//	@Override
//	public void onClick(View v) {
//		Intent intent = new Intent(CompanyInfoDetailActivity.this,RecentAppealActivity.class);
//		intent.putExtra("OrgCode", orgCode);
//		startActivity(intent);
//	}
	
	public static void finishMySelf() {
		mContext.finish();
	}
}
