package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.SharePreferenceUtil;


/**
 * 个人设置界面
 **/
public class SettingsActivity extends BaseActivity implements OnClickListener {

	private final String TAG = "SettingsActivity";
	
	private RelativeLayout gestureLay;
	private TextView pwdTxt;
	private ToggleButton toggleBtn;
	private RelativeLayout switchLay;
	private TextView currentTxt;
	private TextView switchTxt;
	private TextView tvModifyPwd;
	private SharePreferenceUtil spUtils;
	
	 private View.OnClickListener backListener=new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	            finish();
	        }
	    };
	    
//	 private View.OnClickListener homoListener = new View.OnClickListener() {
//		
//		@Override
//		public void onClick(View v) {
//			Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
//            startActivity(intent);
//			finish();
//		}
//	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
		initTitleBar(R.string.set, backListener, null);
		initView();
	}
	
	private void initView() {
		gestureLay = (RelativeLayout) findViewById(R.id.settings_pwd_lay);
		pwdTxt = (TextView) findViewById(R.id.settings_gesture_txt);
		toggleBtn = (ToggleButton) findViewById(R.id.settings_pwd_switch);
		switchLay = (RelativeLayout) findViewById(R.id.settings_user_lay);
		currentTxt = (TextView) findViewById(R.id.settings_current_txt);
		switchTxt = (TextView) findViewById(R.id.settings_switch_txt);
		
		tvModifyPwd = (TextView) findViewById(R.id.tv_modify_pwd);
		tvModifyPwd.setOnClickListener(this);
		gestureLay.setOnClickListener(this);
		((RelativeLayout) findViewById(R.id.settings_modify_lay)).setOnClickListener(this);
		toggleBtn.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				spUtils.savePatternState(isChecked);
			}
			
		});
		
		setUserInfo(false);
		spUtils = new SharePreferenceUtil(this);
		switchLay.setOnClickListener(this);
		toggleBtn.setChecked(spUtils.getPatternState());
	}

	private void setUserInfo(boolean switchLevel) {
		UserInfo user = LoginUtils.getInstance().getUserInfo();
		if (null != user) {
			if (switchLevel) {
				user.setUserLevel("3".equals(user.getUserLevel()) ? "4" : "3");
				MainActivity.getInstance().setMainActivity();
				Toast.makeText(this, R.string.switch_user_success, Toast.LENGTH_SHORT).show();
			}
			if (user.isSwitch() && ("3".equals(user.getUserLevel()) || "4".equals(user.getUserLevel()))) {
				switchLay.setVisibility(View.VISIBLE);
				currentTxt.setText("3".equals(user.getUserLevel()) ? R.string.user_level_3 : R.string.user_level_4);
				switchTxt.setText("3".equals(user.getUserLevel()) ? R.string.user_level_to_4 : R.string.user_level_to_3);
			}
		}
	}

	@Override
	public void onClick(View v) {
		int viewId = v.getId();
		switch (viewId) {
		case R.id.settings_pwd_lay:
			startActivity(new Intent(this, SetGesturesPasswordActivity.class));
			break;
		case R.id.settings_user_lay:
			setUserInfo(true);
			break;
		case R.id.settings_modify_lay:
			startActivity(new Intent(this,ModifyPwdActivity.class));
			break;
		}
	}

}
