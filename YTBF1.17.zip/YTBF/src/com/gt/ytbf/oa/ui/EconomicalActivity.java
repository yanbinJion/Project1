package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;

public class EconomicalActivity extends BaseActivity implements View.OnClickListener {


    private View.OnClickListener backListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_economical);
        initTitleBar(R.string.function_economical_operation,backListener,null);
        LinearLayout economical1 = (LinearLayout) findViewById(R.id.economical1);
        LinearLayout economical2 = (LinearLayout) findViewById(R.id.economical2);
        LinearLayout economical3 = (LinearLayout) findViewById(R.id.economical3);
        LinearLayout economical4 = (LinearLayout) findViewById(R.id.economical4);
        LinearLayout economical5 = (LinearLayout) findViewById(R.id.economical5);
        LinearLayout economical6 = (LinearLayout) findViewById(R.id.economical6);
        LinearLayout economical7 = (LinearLayout) findViewById(R.id.economical7);
        LinearLayout economical8 = (LinearLayout) findViewById(R.id.economical8);
        economical1.setOnClickListener(this);
        economical2.setOnClickListener(this);
        economical3.setOnClickListener(this);
        economical4.setOnClickListener(this);
        economical5.setOnClickListener(this);
        economical6.setOnClickListener(this);
        economical7.setOnClickListener(this);
        economical8.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
    	Intent intent = new Intent(EconomicalActivity.this, EconomicalListActivity.class);
    	startActivityForResult(intent, 1);
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	super.onActivityResult(requestCode, resultCode, data);
    	if(resultCode == RESULT_OK) {
    		setResult(RESULT_OK);
    		finish();
    	}
    }
}
