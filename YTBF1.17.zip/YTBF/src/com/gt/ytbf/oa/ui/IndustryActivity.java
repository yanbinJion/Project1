package com.gt.ytbf.oa.ui;
	
import java.util.ArrayList;
import java.util.List;
	
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
	
import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.OfficeInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.OfficeAdapter;
import com.gt.ytbf.oa.ui.adapter.WarningAdapter;
public class IndustryActivity extends BaseActivity {
		
	private List<OfficeInfo> mOfficeCategories = new ArrayList<OfficeInfo>();
	private static final String TAG = "IndustryActivity";
	private ListView lv_industry;
	private InvokeHelper invoke;
    private OfficeAdapter mAdapter;
    private static IndustryActivity mContext;
    	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_industry);
        mContext =this;
        invoke = new InvokeHelper(this);
        invoke.invoke(OAInterface.getNewsList("3", "1"), callBack);
        lv_industry = (ListView) findViewById(R.id.lv_industry);
        
        lv_industry.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
			    Intent intent = new Intent(IndustryActivity.this,IndustryDetails.class);
			    intent.putExtra("mOfficeCategories",mOfficeCategories.get(position).getId());
			    intent.putExtra("title", mOfficeCategories.get(position).getContent());
			    System.out.println(mOfficeCategories.get(position).getId());
			    startActivity(intent);
			}
		});
    }	
    	
    private  IRequestCallBack callBack = new BaseRequestCallBack(){
    	
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
				if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("data");
							for (ResultItem resultItem : items) {
								OfficeInfo offInfo = new OfficeInfo();
								//offInfo.setIcon(R.drawable.industry_icon_amphoe);
								offInfo.setContent(resultItem.getString("TITLE"));
								offInfo.setData(resultItem.getString("CTIME"));
								offInfo.setId(resultItem.getString("ID"));
								offInfo.setDestype(resultItem.getString("DESTYPE"));
								offInfo.setType(resultItem.getString("TYPE"));
								System.out.println("类型"+resultItem.getString("TYPE"));
								mOfficeCategories.add(offInfo);
								if (null == mAdapter) {
									mAdapter = new OfficeAdapter(
											IndustryActivity.this,
											mOfficeCategories);
									lv_industry.setAdapter(mAdapter);
								} else {
									mAdapter.notifyDataSetChanged();
								}
						}
					}
				}
			}
		}
     };
     
     public static void finishMySelf() {
 		
		mContext.finish();
 	}
     
     @Override
 	public void onBackPressed() {
 		MainActivity.getInstance().onBackPressed();
 	}
}
