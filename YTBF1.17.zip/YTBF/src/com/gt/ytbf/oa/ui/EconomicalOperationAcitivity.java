package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.ui.view.ImageViewPagerHelper;

import android.os.Bundle;
import android.widget.LinearLayout;

public class EconomicalOperationAcitivity extends BaseActivity {
    
	private LinearLayout mLayout;
	private ImageViewPagerHelper viewHelper;
	private static final int TYPE = 4;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_economical_operation);
		initTitleBar(R.string.tab_economical_title, null, null);
	    mLayout = (LinearLayout) findViewById(R.id.ll_econ_oper);
		viewHelper = new ImageViewPagerHelper(this, mLayout);
		viewHelper.onCreate(savedInstanceState);
		setMainNavigator();
	    initView();
	}
    
	private void initView() {
        String[] strings = {"工业概况","主导产业","经济运行","企业信息"};
        int[] res = {R.drawable.gygk_selector,R.drawable.zdcy_selector,R.drawable.jjyx_selector,
        		R.drawable.qyxx_selector2};
        ArrayList<Class> clss = new ArrayList<Class>();
        clss.add(IndustryActivity.class);
        clss.add(LeadingIndustryActivity.class);
        //clss.add(EmptyActivity.class);
        clss.add(EmptyActivity.class);
        clss.add(EmptyActivity.class);
        List<ImageViewPagerHelper.PagerModel> pages = new ArrayList<ImageViewPagerHelper.PagerModel>();
        for (int i = 0; i < strings.length; i++) {
            pages.add(viewHelper.new PagerModel(strings[i], res[i], null, clss.get(i)));
        }
        viewHelper.showViews(pages,TYPE);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		viewHelper.updateUI();
	}
	
	@Override
	public void onBackPressed() {
		MainActivity.getInstance().onBackPressed();
	}
	
}
