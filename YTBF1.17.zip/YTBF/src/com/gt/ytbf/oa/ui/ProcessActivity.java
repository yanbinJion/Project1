package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.DateUtils;
import com.gt.ytbf.oa.tools.LogUtils;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.ScreenUtils;
import com.gt.ytbf.oa.tools.StringUtils;

/**
 * 处理状态
 * 1.提交,2.下发,3.上报,4.终止,5.评价,6.指派,7.受理,8.回退,9.记录受理过程,10.修改受理过程,11.办结
 * 
 * 企业账号：我的诉求进入，只有提交操作，如果是待评价列表进入，就是评价操作，如果是办理列表进入
 * 县派单员：待派发进入，只有上报和指派操作
 * 市派单员：在待派发进入，有下发，终止，指派三个操作
 * 职能部门：待受理进入，只有受理和回退操作
 * 挂点部门和领导：职能查看，不能处理，只有批示
 * 
 * */
public class ProcessActivity extends BaseActivity implements OnClickListener{
		
	public static final String TAG = "ProcessActivity";
	/** 当前诉求的状态 
	 * 状态，10保存，0市级待派发，1县级待派发，2市级已派发，3县级已派发，4待评价，5已办结，11处理中，12终止，13上报
	 * */
	private String appealState;
	private String appealId;
	private String timeLimit;
	/** 这个是职能部门处理状态。 0待受理1已退回2受理中3已受理4已办结*/
	private String tzt;
	/** 指派时选中的部门id，逗号分隔*/
	private String deptIds;
	private String pjjb = "";
	private Button bt_designate;
	private Button bt_terminate;
	private Button bt_issued;
	/** 处理意见*/
	private EditText contentEdt;
	private InvokeHelper helper;
	private Button selectedBtn;
	/** 指派时选中部门*/
	private LinearLayout deptLay;
	private EditText deptTxt;
	private LinearLayout timeLay;
	private EditText timeTxt;
	/** 评价*/
	private LinearLayout ratingLay;
	private RatingBar ratingBar;
	
	private String processId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_process);
		initTitleBar(R.string.appeal_process, this, this);
		appealState = getIntent().getStringExtra("status");
		appealId = getIntent().getStringExtra("appealId");
		timeLimit = getIntent().getStringExtra("timeLimit");
		tzt = getIntent().getStringExtra("tzt");
		processId = getIntent().getStringExtra("processId");
		LogUtils.d(TAG, "onCreate: " + appealId + "  state: " + appealState + "  time " + timeLimit);
		helper = new InvokeHelper(this);
		initView();
	}
	
	private void initView() {
		contentEdt = (EditText) findViewById(R.id.et_comment);
		Button bt_confirm = (Button) findViewById(R.id.bt_confirm);
		Button bt_cancel = (Button) findViewById(R.id.bt_cancel);
		bt_designate = (Button) findViewById(R.id.bt_designate);
		bt_terminate = (Button) findViewById(R.id.bt_terminate);
		bt_issued = (Button) findViewById(R.id.bt_issued);
		
		deptLay = (LinearLayout) findViewById(R.id.process_dept_names_lay);
		deptTxt = (EditText) findViewById(R.id.appeal_process_dept_names_txt);
		timeLay = (LinearLayout) findViewById(R.id.process_time_lay);
		timeTxt = (EditText) findViewById(R.id.appeal_process_time_txt);
		timeTxt.setText(DateUtils.getDateStr(""));
		
		ratingLay = (LinearLayout) findViewById(R.id.appeal_rating_lay);
		ratingBar = (RatingBar) findViewById(R.id.rating);
		
		bt_cancel.setOnClickListener(this);
		bt_confirm.setOnClickListener(this);
		bt_designate.setOnClickListener(this);
		bt_terminate.setOnClickListener(this);
		bt_issued.setOnClickListener(this);
		bt_terminate.setSelected(false);
		bt_issued.setSelected(false);
		selectedBtn = bt_designate;
		bt_issued.setBackgroundResource(R.drawable.blue_border_white_bg);
		bt_issued.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
		bt_terminate.setBackgroundResource(R.drawable.blue_border_white_bg);
		bt_terminate.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
		selectedBtn.setBackgroundResource(R.drawable.blue_corners_icon);
		selectedBtn.setTextColor(getResources().getColor(R.color.white));
		
		setHandleType();
	}
	
	/**
	 * 设置办理的类型
	 * */
	private void setHandleType() {
		String userLevel = LoginUtils.getInstance().getUserInfo().getUserLevel();
		if ("1".equals(userLevel)) {
			if ("10".equals(appealState)) {
				//只有提交操作
				bt_designate.setText(R.string.appeal_commit);
				bt_designate.setTag("1");
			} else if ("4".equals(appealState)) {
				//只有评价操作
				ratingLay.setVisibility(View.VISIBLE);
				bt_designate.setText(R.string.appeal_assess);
				bt_designate.setTag("5");
			}
			bt_designate.setVisibility(View.VISIBLE);
		} else if ("2".equals(userLevel)) {
			//县派单员
			timeTxt.setOnClickListener(this);
			deptTxt.setOnClickListener(this);
			if ("1".equals(appealState)) {
				bt_designate.setText(R.string.appeal_send);
				bt_designate.setTag("3");
				bt_designate.setVisibility(View.VISIBLE);
				bt_issued.setText(R.string.appeal_dispatcher);
				bt_issued.setTag("6");
				bt_issued.setVisibility(View.VISIBLE);
			} else {
				bt_designate.setText(R.string.appeal_down_send);
				bt_designate.setTag("2");
				bt_terminate.setText(R.string.appeal_complete);
				bt_terminate.setTag("4");
				bt_issued.setText(R.string.appeal_dispatcher);
				bt_issued.setTag("6");
				bt_designate.setVisibility(View.VISIBLE);
				bt_terminate.setVisibility(View.VISIBLE);
				bt_issued.setVisibility(View.VISIBLE);
			}
		} else if ("3".equals(userLevel)) {
			//职能部门
			if ("0".equals(tzt)) {
				bt_designate.setText(R.string.appeal_process_handle);
				bt_designate.setTag("7");
				bt_issued.setText(R.string.appeal_back);
				bt_issued.setTag("8");
//				contentEdt.setVisibility(View.INVISIBLE);
				contentEdt.setEnabled(false);
				contentEdt.setHint("请处理...");
				bt_designate.setVisibility(View.VISIBLE);
				bt_issued.setVisibility(View.VISIBLE);
			} else if ("2".equals(tzt)) {
				bt_designate.setText(R.string.appeal_process_procedure);
				bt_designate.setTag("9");
				bt_designate.setVisibility(View.VISIBLE);
			} else if ("3".equals(tzt)) {
				bt_designate.setText(R.string.appeal_modify_procedure);
				bt_designate.setTag("10");
				bt_issued.setText(R.string.appeal_done);
				bt_issued.setTag("11");
				bt_issued.setVisibility(View.VISIBLE);
				bt_designate.setVisibility(View.VISIBLE);
			}
		} else if ("5".equals(userLevel)) {
			//挂点部门和挂点领导
			bt_designate.setText(R.string.appeal_lead_note);
			bt_designate.setVisibility(View.VISIBLE);
		}
	}
	
	private IRequestCallBack callback = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				Intent intent = new Intent();
				intent.putExtra("isProcess", true);
				ProcessActivity.this.setResult(RESULT_OK, intent);
				ProcessActivity.this.finish();
			}
			
		}
		
	};
	
	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		case R.id.system_back:
			finish();
			break;
		case R.id.btn_top_right:
			AppealCenterActivity.finishMySelf();
            finish();
			break;
		case R.id.bt_confirm:
			if ("5".equals(LoginUtils.getInstance().getUserInfo().getUserLevel())) {
				String content = contentEdt.getText().toString();
				if (StringUtils.isNullOrEmpty(content)) {
					Toast.makeText(this, R.string.appeal_handle_content_tip, Toast.LENGTH_SHORT).show();
					return;
				}
				helper.invokeWidthDialog(OAInterface.insertOrUpdateLeaderNotes(processId, content), callback);
				return;
			}
			String deptNames = "";
			String ids = "";
			String timeLimit = "";
			String pjjb = "";
			//如果是指派,需要设置值
			if ("6".equals(selectedBtn.getTag())) {
				deptNames = deptTxt.getText().toString();
				ids = deptIds;
				if (StringUtils.isNullOrEmpty(deptNames)) {
					Toast.makeText(this, R.string.appeal_dept_can_not_null, Toast.LENGTH_SHORT).show();
					return;
				}
				timeLimit = timeTxt.getText().toString();
			} else if ("5".equals(selectedBtn.getTag())) {
				pjjb = String.valueOf((int) ratingBar.getRating());
			}
			helper.invokeWidthDialog(OAInterface.handleAppeal((String) selectedBtn.getTag(), appealId, contentEdt.getText().toString(), 
					pjjb, ids, deptNames, timeLimit), callback);
			break;
		case R.id.bt_cancel:
			finish();
			break;
		case R.id.bt_designate:
			deptLay.setVisibility(View.GONE);
			timeLay.setVisibility(View.GONE);
			setButtomBg(bt_designate);
			break;
		case R.id.bt_terminate:
			deptLay.setVisibility(View.GONE);
			timeLay.setVisibility(View.GONE);
			setButtomBg(bt_terminate);
			break;
		case R.id.bt_issued:
			if ("6".equals(bt_issued.getTag())) {
				deptLay.setVisibility(View.VISIBLE);
				timeLay.setVisibility(View.VISIBLE);
			}
			setButtomBg(bt_issued);
			break;
		case R.id.appeal_process_time_txt:
			ScreenUtils.showTimeSelect(this, timeTxt, DateUtils.DATE_TIME_FORMAT);
			break;
		case R.id.appeal_process_dept_names_txt:
			Intent intent = new Intent(ProcessActivity.this,OrganizationActivity.class);
			intent.putExtra("appealId", appealId);
			startActivityForResult(intent, 2);
			break;
		default:
			break;
		}
	}
	
	/**
	 * 设置当前选中的按钮背景
	 * */
	private void setButtomBg(Button btn) {
		selectedBtn.setBackgroundResource(R.drawable.blue_border_white_bg);
		selectedBtn.setTextColor(getResources().getColor(R.color.common_top_titlebar_bgcolor));
		btn.setBackgroundResource(R.drawable.blue_corners_icon);
		btn.setTextColor(getResources().getColor(R.color.white));
		selectedBtn = btn;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (data!=null) {
			String depts = data.getStringExtra("depts");
			String names = data.getStringExtra("names");
			if (!StringUtils.isNullOrEmpty(depts)) {
				deptIds = depts;
				deptTxt.setText(names);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
}
