package com.gt.ytbf.oa.ui;

import com.gt.ytbf.oa.R;

import android.app.Activity;
import android.os.Bundle;

public class EmptyActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_empty);
	}
}
