package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

import com.gt.ytbf.oa.model.AdInfo;

public class ViewPagerAdapter extends PagerAdapter{

	private Context context;
	private List<AdInfo> list;
	
	public ViewPagerAdapter(List<AdInfo> list, Context context){
		this.context = context;
		this.list = list;
	}
	/**
	 */
	@Override
	public int getCount() {
		return list.size();
	}

	@Override
	public boolean isViewFromObject(View view, Object obj) {
		return view == obj;
	}
	/**
	 */
	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		ImageView imageView = new ImageView(context);
		imageView.setScaleType(ScaleType.FIT_XY);
		AdInfo ad = list.get(position % list.size());
		imageView.setImageResource(ad.getIconResId());
		
		container.addView(imageView);
		
		return imageView;
	}
	/**
	 */
	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
//		super.destroyItem(container, position, object);
		container.removeView((View)object);
	}
	
}
















