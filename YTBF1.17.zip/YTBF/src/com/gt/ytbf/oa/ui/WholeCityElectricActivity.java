package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.WholeElectricInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.WholeElectricAdapter;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
		
public class WholeCityElectricActivity extends BaseActivity{
		
	private InvokeHelper invoke;
	private List<WholeElectricInfo> mList = new ArrayList<WholeElectricInfo>();
	private WholeElectricAdapter mAdapter;
	private ListView elec_list;
	private static final String TAG = "WholeCityElectricActivity";
	private TextView time1;
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);

		}
	};
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_whole_electric);
		initTitleBar(R.string.whole_electric_title, backListener, null);
		invoke = new InvokeHelper(this);
		invoke.invoke(OAInterface.getQueryStatistics("1", "", ""), callBack);
		initView();
	}
		
	private void initView() {
		elec_list = (ListView) findViewById(R.id.lv_whole_elec);
		time1 = (TextView) findViewById(R.id.time);
	}
	
	private  IRequestCallBack callBack = new BaseRequestCallBack(){
		 
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
					if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("DATA");
						for (ResultItem resultItem : items) {
							WholeElectricInfo infos = new WholeElectricInfo();
							infos.setMonthTotal(resultItem.getString("BYLJ"));
							infos.setAddTotal(resultItem.getString("LJZL"));
							infos.setCommonRise(resultItem.getString("TBZZ"));
							infos.setName(resultItem.getString("ZBMC"));
							String time = resultItem.getString("YF");
							char[] array = time.toCharArray();
							if(array[0]=='0'){
								time1.setText("区间:1-"+array[1]+"月");
							}else{
								time1.setText("区间:1-"+time+"月");
							}
							mList.add(infos);
							
							if(mAdapter==null){
								mAdapter = new WholeElectricAdapter(WholeCityElectricActivity.this,mList);
								elec_list.setAdapter(mAdapter);
							}else{
								mAdapter.notifyDataSetChanged();
							}
						}
					}
				}
			}
		}
     };

}
