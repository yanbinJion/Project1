package com.gt.ytbf.oa.ui.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.gt.ytbf.oa.bean.Point;
import com.gt.ytbf.oa.common.Constants;


/**
 * Filename : GestureDrawl
 * 
 * @Description : 手势密码
 * @Author : 高明峰
 * @Version : 1.0
 * @Date :2015-04-23 17:50:00
 */
public class GestureDrawl extends View {
	private int mov_x;// 声明起点坐标
	private int mov_y;
	private Paint paint;// 声明画笔
	private Canvas canvas;// 画布
	private Bitmap bitmap;// 位图

	private List<Point> list;// 装有各个view坐标的集合
	private List<Pair<Point, Point>> lineList;// 记录画过的线

	private List<Point> selectPointList;// 装有各个view坐标的集合

	/**
	 * 手指当前在哪个Point内
	 */
	private Point currentPoint;
	/**
	 * 用户绘图的回调
	 */
	private GestureCallBack callBack;

	/**
	 * 用户当前绘制的图形密码
	 */
	private StringBuilder passWordSb;

	/**
	 * 用户传入的passWord
	 */
	private String passWord;

	/**
	 * 操作类型
	 */
	private int optType;

	/**
	 * 操作次数
	 */
	private int number = 1;
	
	private final static int WHAT_DELET = 1234;
	
	private TimerTask mTimerTask;
	
	private Timer mTimer;
	
	private boolean isMTimer = true;
	
	public GestureDrawl(int optType, List<Point> list, Context context,
			String passWord, GestureCallBack callBack) {
		super(context);
		paint = new Paint(Paint.DITHER_FLAG);// 创建一个画笔
		WindowManager wm = (WindowManager) context
				.getSystemService(Context.WINDOW_SERVICE);

		int width = wm.getDefaultDisplay().getWidth();
		int height = wm.getDefaultDisplay().getHeight();
		bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); // 设置位图的宽高
		canvas = new Canvas();
		canvas.setBitmap(bitmap);

		paint.setStyle(Style.STROKE);// 设置非填充
		DisplayMetrics dm = new DisplayMetrics();
    	((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(dm);
		paint.setStrokeWidth(35/dm.density);// 笔宽35像素  根据密度进行去除
		paint.setColor(Color.rgb(55, 145, 198));// 设置颜色
		paint.setAntiAlias(true);// 显示锯齿
		this.list = list;
		this.lineList = new ArrayList<Pair<Point, Point>>();
		this.callBack = callBack;

		// 初始化密码缓存
		this.passWordSb = new StringBuilder();

		this.optType = optType;

		this.passWord = passWord;

		this.selectPointList = new ArrayList<Point>();
	}
	
	public void setOptType(int type) {
		this.optType = type;
	}

	// 画位图
	@Override
	protected void onDraw(Canvas canvas) {
		// super.onDraw(canvas);
		canvas.drawBitmap(bitmap, 0, 0, null);
	}

	// 触摸事件
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			stopTimer();
			clearAll();
			mov_x = (int) event.getX();
			mov_y = (int) event.getY();

			// 判断当前点击的位置是处于哪个点之内
			currentPoint = getPointAt(mov_x, mov_y);
			if (currentPoint != null) {
				currentPoint.setHighLighted(true);
				passWordSb.append(currentPoint.getNum());
				selectPointList.add(currentPoint);
			}
			// canvas.drawPoint(mov_x, mov_y, paint);// 画点
			invalidate();
			break;
		case MotionEvent.ACTION_MOVE:
			clearScreenAndDrawList();
			// 得到当前移动位置是处于哪个点内
			Point pointAt = getPointAt((int) event.getX(), (int) event.getY());
			// 代表当前用户手指处于点与点之前
			if (currentPoint == null && pointAt == null) {
				return true;
			} else {// 代表用户的手指移动到了点上
				if (currentPoint == null) {// 先判断当前的point是不是为null
					// 如果为空，那么把手指移动到的点赋值给currentPoint
					currentPoint = pointAt;
					// 把currentPoint这个点设置选中为true;
					currentPoint.setHighLighted(true);
					passWordSb.append(currentPoint.getNum());
				}
			}

			if (pointAt == null || currentPoint.equals(pointAt)
					|| pointAt.isHighLighted()) {
				// 点击移动区域不在圆的区域 或者
				// 如果当前点击的点与当前移动到的点的位置相同
				// 那么以当前的点中心为起点，以手指移动位置为终点画线
				canvas.drawLine(currentPoint.getCenterX(),
						currentPoint.getCenterY(), event.getX(), event.getY(),
						paint);// 画线

			} else {
				// 如果当前点击的点与当前移动到的点的位置不同
				// 那么以前前点的中心为起点，以手移动到的点的位置画线
				canvas.drawLine(currentPoint.getCenterX(),
						currentPoint.getCenterY(), pointAt.getCenterX(),
						pointAt.getCenterY(), paint);// 画线

				pointAt.setHighLighted(true);
				selectPointList.add(pointAt);

				Pair<Point, Point> pair = new Pair<Point, Point>(currentPoint,
						pointAt);
				lineList.add(pair);

				// 赋值当前的point;
				currentPoint = pointAt;
				passWordSb.append(currentPoint.getNum());
			}

			invalidate();
			break;
		case MotionEvent.ACTION_UP:// 当手指抬起的时候
			// 重新绘制界面
			clearScreenAndDrawList();
			// 登录手势登录
			if (optType == Constants.GESTURES_OPTTYPE_LOGIN) {
				// 清掉屏幕上所有的线，只画上集合里面保存的线
				if (passWordSb.toString().equals(passWord)) {
					// 代表用户绘制的密码手势与传入的密码相同
					callBack.checkedSuccess();
				} else {
					// 设置红色错误
					for (Point p : selectPointList) {
						p.setWrongLighted();
					}
					setWrongPaint();
					// 用户绘制的密码与传入的密码不同。
					callBack.checkedFail();
					//两秒之后清空错误画线
					startTimer();
				    
				}
			} else if (optType == Constants.GESTURES_OPTTYPE_SETPWD
					|| optType == Constants.GESTURES_OPTTYPE_MODPWD) {
				// 设置手势密码
				if (number == 1) {
					if (passWordSb.toString().length() < 4) {
						// 设置红色错误
						for (Point p : selectPointList) {
							p.setWrongLighted();
						}
						setWrongPaint();
						callBack.checkedFail();
						//两秒之后清空错误画线
						startTimer();
					} else {
						callBack.checkedSuccess();
						passWord = passWordSb.toString();
						number++;
					}
				} else if (number == 2) {
					if (passWordSb.toString().equals(passWord)) {
						// 代表用户绘制的密码手势与传入的密码相同
						callBack.checkedSuccessBack(passWord);
					} else {
						// 设置红色错误
						for (Point p : selectPointList) {
							p.setWrongLighted();
						}
						setWrongPaint();
						// 用户绘制的密码与传入的密码不同。
						callBack.checkedFail();
						//两秒之后清空错误画线
						startTimer();
					}
					number = 1;
				}
			}
			// 重置passWordSb
			passWordSb = new StringBuilder();

			invalidate();
			break;
		default:
			break;
		}
		return true;
	}

	/**
	 * 通过点的位置去集合里面查找这个点是包含在哪个Point里面的
	 * 
	 * @param x
	 * @param y
	 * @return 如果没有找到，则返回null，代表用户当前移动的地方属于点与点之间
	 */
	private Point getPointAt(int x, int y) {

		for (Point point : list) {
			// 先判断x
			int leftX = point.getLeftX();
			int rightX = point.getRightX();
			if (!(x >= leftX && x < rightX)) {
				// 如果为假，则跳到下一个对比
				continue;
			}

			int topY = point.getTopY();
			int bottomY = point.getBottomY();
			if (!(y >= topY && y < bottomY)) {
				// 如果为假，则跳到下一个对比
				continue;
			}

			// 如果执行到这，那么说明当前点击的点的位置在遍历到点的位置这个地方
			return point;
		}

		return null;
	}

	/**
	 * 清掉屏幕上所有的线，然后画出集合里面的线
	 */
	private void clearScreenAndDrawList() {
		canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
		paint.setColor(Color.rgb(55, 145, 198));// 设置颜色
		for (Pair<Point, Point> pair : lineList) {
			canvas.drawLine(pair.first.getCenterX(), pair.first.getCenterY(),
					pair.second.getCenterX(), pair.second.getCenterY(), paint);// 画线
		}
	}

	private void setWrongPaint() {
		canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.SRC);
		paint.setColor(Color.rgb(157, 124, 131));
		for (Pair<Point, Point> pair : lineList) {
			canvas.drawLine(pair.first.getCenterX(), pair.first.getCenterY(),
					pair.second.getCenterX(), pair.second.getCenterY(), paint);// 画线
		}
	}

	/**
	 * 清除页面所有的画线
	 */
	public void clearAll() {
		// 清空保存点的集合
		lineList.clear();
		//
		this.selectPointList.clear();

		canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
		// 设置为不选中
		for (Point p : list) {
			p.setHighLighted(false);
		}
	}

	public interface GestureCallBack {

		/**
		 * 操作成功返回
		 */
		public abstract void checkedSuccess();

		/**
		 * 操作成功返回带参数
		 */
		public abstract void checkedSuccessBack(String param);

		/**
		 * 代表用户绘制的密码与传入的密码不相同
		 */
		public abstract void checkedFail();
	}
	
	
	
	private void startTimer(){  
        if (mTimer == null) {  
            mTimer = new Timer();  
        }  
  
        if (mTimerTask == null) {  
            mTimerTask = new TimerTask() {  
            	@Override  
                public void run() {  
                    // 需要做的事:发送消息  
                    Message message = new Message();  
                    message.what = WHAT_DELET;  
                    mHandler.sendMessage(message);  
                }  
            };  
        }  
  
        if(mTimer != null && mTimerTask != null ){
        	if(isMTimer){
        		mTimer.schedule(mTimerTask, 1000);  
        		isMTimer = false;
        	}
        }
    }  
  
    private void stopTimer(){  
        if (mTimer != null) {  
            mTimer.cancel();  
            mTimer = null;  
        }  
        if (mTimerTask != null) {  
            mTimerTask.cancel();  
            mTimerTask = null;  
        } 
        isMTimer = true;
    }  
    
    private  Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			 if (msg.what == WHAT_DELET) { 
				 clearAll();
	         }
			 stopTimer();
		}
	};

}
