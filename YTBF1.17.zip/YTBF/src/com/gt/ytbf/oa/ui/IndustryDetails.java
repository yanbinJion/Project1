package com.gt.ytbf.oa.ui;

import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;

public class IndustryDetails extends BaseActivity implements OnClickListener {
	
	private WebView wb_id_list;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		System.out.println("工业概况 onCreate()");
		setContentView(R.layout.activity_industry_detail);
		String industryTitle = getIntent().getStringExtra("title");
		initTitleBar(industryTitle, this, this);
		initView();
		String id = getIntent().getStringExtra("mOfficeCategories");
		InvokeHelper invoke = new InvokeHelper(this);
		invoke.invoke(OAInterface.getNewDetails(id), callBack);
	}
	
	private void initView() {
		wb_id_list = (WebView) findViewById(R.id.wb_id_list);
		wb_id_list.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		wb_id_list.getSettings().setSupportZoom(true);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if(checkResult(item)){
			if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
				List<ResultItem> items = item.getItems("data");
				if (!BeanUtils.isEmpty(items)) {
					String content = items.get(0).getString("CONTENT");
						wb_id_list
								.loadDataWithBaseURL(null, getWebData(content), "text/html", "utf-8", null);
				}
			}
		  }
		}
	};
	
	private String getWebData(String bodyHTML) {
	    String head = "<head><style>img {max-width:100%; width:auto; height: auto;}</style></head>";
	    return "<html>" + head + "<body>" + bodyHTML + "</body></html>";
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.system_back:
			finish();
			break;
		case R.id.btn_top_right:
			IndustryActivity.finishMySelf();
			startActivity(new Intent(IndustryDetails.this,MainActivity.class));
			finish();
			break;
		default:
			break;
		}
	}
}
