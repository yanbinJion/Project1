package com.gt.ytbf.oa.ui;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart.Type;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.ApiRequest;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.AppealChartInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.LoadDataListener;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.DisplayUtil;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.adapter.AppealAdapter;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.LegendAdapter;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class AppealActivity extends BaseActivity implements LoadDataListener{


    public static final String[] ITTILES = new String[]{"全部诉求","诉求总览", "诉求分类", "诉求预警"};
    
    private static AppealActivity mContext;
	private LayoutInflater layoutInflater;
	private LinearLayout layout;
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	private CommenViewPagerHelper helper;
	private View appealNum;
	private View appealWarning;
	private View appealCategory;
	private View appealAll;
	private InvokeHelper invoke;
	private TextView tv_no_data;
	private PullToRefreshListView pullAppealAll;
	private ListView lvAppealAll;
	protected static final int GET_HOME_LIST = 0;
	private List<AppealCenterModel> appeals = new ArrayList<AppealCenterModel>();
	private AppealAdapter myAppealAdapter;
	private int pageIndex = 1;
	private boolean hasListData = false;
	private boolean hasChartData = false;
	private static final int TYPE = 2;
	 private View.OnClickListener backListener = new View.OnClickListener() {
	        @Override
	        public void onClick(View v) {
	            finish();
	            overridePendingTransition(R.anim.in_from_left,
						R.anim.out_to_right);

	        }
	    };

	private RelativeLayout numChart;

	private RelativeLayout categoryChart;

	private RelativeLayout warningChart;
	
	private int[] COLORS = new int[] {Color.parseColor("#95a6cf"), Color.parseColor("#4d7099"),  
		Color.parseColor("#b82622"), Color.parseColor("#89a44a"), Color.parseColor("#036eb7"), Color.parseColor("#D15FEE"),
		Color.parseColor("#4199ad"),Color.parseColor("#8064a1"),Color.parseColor("#a47e7d"),Color.parseColor("#778899") };
	// XY轴坐标数据
	private XYSeries series1;
	// 单个曲线渲染器
	private XYSeriesRenderer renderer1;
	// 图标数据集
	private XYMultipleSeriesDataset mDataset = new XYMultipleSeriesDataset();
	// 曲线图整体渲染器
	private XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer();

	private String[] datas;
    private static final String TAG = "AppealActivity";
    
    private List<AppealChartInfo> statusList = new ArrayList<AppealChartInfo>();
    private List<AppealChartInfo> warnList = new ArrayList<AppealChartInfo>();
    
    public  int num1,num2,num3,num4,num5,num6,num7;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_tabpageindicator);
        initTitleBar(R.string.function_appeal_center, backListener, null);
        invoke = new InvokeHelper(this);
        invoke.invoke(OAInterface.getAppealStatistics(),callBack2);
        initView();
        initViewPagers(savedInstanceState);
        mContext = this;
    }

    private void initData() {
    	Log.i(TAG, "initData() ");
    	pullAppealAll.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
    		// 下拉刷新
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
						if (checkNetworkState()) {

							if (!BeanUtils.isEmpty(appeals)) {
								appeals.clear();
							}
							pageIndex = 1;
							loadData(GET_HOME_LIST, pageIndex, false);
						} else {
							pullAppealAll.onPullDownRefreshComplete();
						}
			}
			// 上拉加载
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
						if (checkNetworkState()) {
							pageIndex = pageIndex + 1;
							loadData(GET_HOME_LIST, pageIndex, false);
						}else {
							pullAppealAll.onPullUpRefreshComplete();
						}
			}
		});
    	loadData(GET_HOME_LIST, pageIndex, true);
    	
    	lvAppealAll.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (appeals.size() <= position) {
					return;
				}
				Intent intent = new Intent(new Intent(AppealActivity.this,AppealCenterActivity.class));
				Bundle bundle = new Bundle();
				bundle.putSerializable("appealInfo", appeals.get(position));
				bundle.putInt("type", TYPE);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});

	}
    private IRequestCallBack callBack2 = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItems = response.getResultItem(ResultItem.class);
			if (checkResult(resultItems)) {
				if (!BeanUtils.isEmpty(response)) {
					if (Constants.SUCCESS_CODE.equals(resultItems.get("code"))) {
						hasChartData = true;
						List<ResultItem> statusResult = resultItems.getItems("AppealsStatusData");
						showStatusChartList(statusResult);
						List<ResultItem> typeResult = resultItems.getItems("AppealsTypeData");
						showTypeChartList(typeResult);
						List<ResultItem> warnResult = resultItems.getItems("AppealsWarnData");
						showWarnChartList(warnResult);
					}
				}
			}
		}
	 };
	
	private void showStatusChartList(List<ResultItem> result) {
		Log.i(TAG, " showStatusChartList ");
		if (result == null) {
			return;
		}
		
		for (ResultItem item : result) {
			AppealChartInfo appealInfo = new AppealChartInfo();
			String count = item.getString("COUNT");
			String status = item.getString("STATUS");
			appealInfo.setCount(count);
			appealInfo.setStatus(status);
			statusList.add(appealInfo);
			Log.i(TAG, " showStatusChartList 2  "+statusList.size());
		}
		updateBarChart();
	}
	 
	protected void showTypeChartList(List<ResultItem> items) {
		Log.i(TAG, " showTypeChartList ");
		if (items == null) {
			return;
		}
		
		names = new ArrayList<String>();
		for (ResultItem item : items) {
			AppealChartInfo appealInfo = new AppealChartInfo();
			String count = item.getString("COUNT");
			String typeName = item.getString("TYPENAME");
			appealInfo.setCount(count);
			appealInfo.setTypeName(typeName);;
			warnList.add(appealInfo);
			names.add(typeName);
		}
		updateCategoryPieChart();
	}
	
	protected void showWarnChartList(List<ResultItem> warnResult) {
	    	if (!BeanUtils.isEmpty(warnResult)) {
				String warnCount = warnResult.get(0).getString("COUNT");
				if(!BeanUtils.isEmpty(warnCount)){
					datas = warnCount.split("-");
				}
			}
	    	
	    	updateWarnPieChart();
	}
	 
	private IRequestCallBack callBack = new BaseRequestCallBack() {
    	
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem resultItems = response.getResultItem(ResultItem.class);
			if (checkResult(resultItems)) {
				if (!BeanUtils.isEmpty(response)) {
					ResultItem result = (ResultItem) resultItems.get("AllAppealsData");
					if (Constants.SUCCESS_CODE.equals(resultItems.get("code"))) {
						hasListData = true;
						if (what == GET_HOME_LIST) {
							showAppealList(result);
						}
					}
				}
			}
		}
	};

	private GridView gv_legend,gv_legend2;
	private TextView tv_pmd,tv_pmd2;

	private List<String> names;
	
	private void showAppealList(ResultItem result) {
		List<ResultItem> list = result.getItems("DATA");
		if (list == null) {
			pullAppealAll.onPullDownRefreshComplete();
			pullAppealAll.onPullUpRefreshComplete();
			pullAppealAll.setHasMoreData(false);
			if(BeanUtils.isEmpty(appeals)){
				tv_no_data.setVisibility(View.VISIBLE);
			}
			myAppealAdapter.setData(appeals);
			return;
		}
		
		for (ResultItem item : list) {
			String id = item.getString("ID");
			String companyName = item.getString("COMPANY_NAME");
			String content = item.getString("CONTENT");
			String appealType = item.getString("APPEAL_TYPE");
			String status = item.getString("STATUS");
			String area_name = item.getString("AREA_NAME");
			String create_time = item.getString("CREATE_TIME");
			String title = item.getString("TITLE");
			String bizId = item.getString("BIZID");
			String tzt=item.getString("TZT");
			appeals.add(new AppealCenterModel(id, title, companyName,
					area_name, appealType, content, status, create_time, bizId,tzt));
		}
			if (myAppealAdapter == null) {
				myAppealAdapter = new AppealAdapter(this, appeals,TYPE);
				lvAppealAll.setAdapter(myAppealAdapter);
			} else {
				myAppealAdapter.setData(appeals);
			}
			
			if (BeanUtils.isEmpty(list) || list.size() < Constants.COMMON_PAGE_SIZE) {
				// 已经全部加载完成，关闭UI组件的下拉加载更多功能
				pullAppealAll.onPullDownRefreshComplete();
				pullAppealAll.onPullUpRefreshComplete();
				pullAppealAll.setHasMoreData(false);
			} else {
				// 还有更多数据，继续打开“下拉加载更多”功能
				pullAppealAll.onPullDownRefreshComplete();
				pullAppealAll.onPullUpRefreshComplete();
				pullAppealAll.setHasMoreData(true);
			}
	}

	private void initView() {
		Log.i(TAG, " initView() ");
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.viewpage);
    }
	
    private void initViewPagers(Bundle savedInstanceState) {
    	Log.i(TAG, " initViewPagers ");
    	helper = new CommenViewPagerHelper(AppealActivity.this, layout);
        helper.onCreate(savedInstanceState);
        List<View> views = new ArrayList<View>();
        appealAll = layoutInflater.inflate(R.layout.appeal_all, null);
        views.add(appealAll);
        appealNum = layoutInflater.inflate(R.layout.appeal_chart, null);
        views.add(appealNum);
        appealCategory = layoutInflater.inflate(R.layout.appeal_chart_pie, null);
        views.add(appealCategory);
        appealWarning = layoutInflater.inflate(R.layout.appeal_chart_pie, null);
        views.add(appealWarning);
        for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));
		}
        helper.showViews(mListDatas);
        loadView();
    }

	private void loadView() {
		tv_no_data = (TextView) findViewById(R.id.tv_no_data);
		pullAppealAll = (PullToRefreshListView) appealAll.findViewById(R.id.lv_appeal_all);
		pullAppealAll.setPullRefreshEnabled(true);
		pullAppealAll.setPullLoadEnabled(false);
		pullAppealAll.setScrollLoadEnabled(true);
		lvAppealAll = pullAppealAll.getRefreshableView();
		setListViewAttribute(this, lvAppealAll);
		numChart = (RelativeLayout) appealNum.findViewById(R.id.appeal_chart);
		categoryChart = (RelativeLayout) appealCategory.findViewById(R.id.appeal_chart);
		warningChart = (RelativeLayout) appealWarning.findViewById(R.id.appeal_chart);
		gv_legend = (GridView) appealCategory.findViewById(R.id.gv_legend);
		tv_pmd = (TextView) appealCategory.findViewById(R.id.tv_pmd);
		gv_legend2 = (GridView) appealWarning.findViewById(R.id.gv_legend);
		tv_pmd2 = (TextView) appealWarning.findViewById(R.id.tv_pmd);
		initData();
		initBarChart();
	}

	private DefaultRenderer initPieChart() {
		DefaultRenderer pRenderer = new DefaultRenderer();
//		pRenderer.setMargins(new int[] { DisplayUtil.dip2px(this, 150), DisplayUtil.dip2px(this, 20), DisplayUtil.dip2px(this, 20), DisplayUtil.dip2px(this, 20) }); // 上左下右边距
		pRenderer.setZoomButtonsVisible(false);// 显示放大缩小功能按钮
		pRenderer.setStartAngle(180);// 设置为水平开始
		pRenderer.setDisplayValues(false);// 显示数据
		pRenderer.setFitLegend(true);// 设置是否显示图例
		pRenderer.setShowLegend(false);
		pRenderer.setLegendTextSize(DisplayUtil.sp2px(this, 12));// 设置图例字体大小
		pRenderer.setLegendHeight(DisplayUtil.dip2px(this, 20));// 设置图例高度
		pRenderer.setChartTitleTextSize(DisplayUtil.sp2px(this, 12));// 设置饼图标题大小
		pRenderer.setLabelsColor(Color.BLACK);//饼图上标记文字的颜色
		pRenderer.setLabelsTextSize(DisplayUtil.sp2px(this, 12));
		pRenderer.setZoomEnabled(false);
		pRenderer.setPanEnabled(false);
		return pRenderer;
	}
	 private int getRandomColor() {// 分别产生RBG数值  
	        Random random = new Random();  
	        int R = random.nextInt(255);  
	        int G = random.nextInt(255);  
	        int B = random.nextInt(255);  
	        return Color.rgb(R, G, B);
	    } 
	 
	private void updateCategoryPieChart() {
		gv_legend.setVisibility(View.VISIBLE);
		DefaultRenderer cRenderer = initPieChart();
		CategorySeries mSeries = new CategorySeries("");// PieChart的DataSet 
		int VALUE=0;
		//显示跑马灯数据
		boolean flag=true;
		String pmdString="截至目前：";
		for (int i = 0; i < warnList.size(); i++) {
			VALUE +=Integer.valueOf(warnList.get(i).getCount());
			if (flag) {
				pmdString=pmdString+warnList.get(i).getTypeName()+":"+warnList.get(i).getCount()+"条";
				flag=false;
			}else {
				pmdString=pmdString+","+warnList.get(i).getTypeName()+":"+warnList.get(i).getCount()+"条";
			}
		}
		//可变文本类参考SpannableStringBuilder
        SpannableString ss = new SpannableString(pmdString); 
        int startLength=5;
        for (int i = 0; i < warnList.size(); i++) {
				int nameLength=warnList.get(i).getTypeName().length()+1;
				int numLength=warnList.get(i).getCount().length();
			//用颜色标记文本
			ss.setSpan(new ForegroundColorSpan(Color.RED), startLength+nameLength, startLength+nameLength+numLength,  
					//setSpan时需要指定的 flag,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE(前后都不包括).
					Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			startLength=startLength+nameLength+numLength+2;
		}
		tv_pmd.setText(ss);
		NumberFormat nt = NumberFormat.getPercentInstance();
		nt.setMinimumFractionDigits(1);
		for (int i = 0; i < warnList.size(); i++) {
			warnList.get(i);
//			mSeries.add(warnList.get(i).getTypeName(), (float)((Float.valueOf(warnList.get(i).getCount())/VALUE)));// 设置种类名称和对应的数值，前面是（key,value）键值对
            mSeries.add(nt.format((float)((Float.valueOf(warnList.get(i).getCount())/VALUE))), (float)((Float.valueOf(warnList.get(i).getCount())/VALUE)));// 设置种类名称和对应的数值，前面是（key,value）键值对
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            if (i < COLORS.length) {
                     renderer.setColor(COLORS[i]);// 设置描绘器的颜色
            } else {
                     renderer.setColor(getRandomColor());// 设置描绘器的颜色
            }
            //设置百分数精确度2即保留两位小数
            renderer.setChartValuesFormat(nt);// 设置百分比
            cRenderer.setChartTitleTextSize(DisplayUtil.sp2px(this, 12));// 设置饼图标题大小
            cRenderer.addSeriesRenderer(renderer);// 将最新的描绘器添加到DefaultRenderer中
		}
		GraphicalView cChartView = ChartFactory.getPieChartView(getApplicationContext(),
   						mSeries, cRenderer);// 构建mChartView
		categoryChart.addView(cChartView, new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		
		cChartView.repaint();
		if (!BeanUtils.isEmpty(names)) {
			gv_legend.setAdapter(new LegendAdapter(this, COLORS, names));
		}
	}
	
    private void updateWarnPieChart() {
    	String[] str = {"超过3天","超过30天","超过90天"};
		DefaultRenderer wRenderer = initPieChart();// PieChart的DataSet 
		CategorySeries mSeries2 = new CategorySeries("");
		int VALUE=0;
		//显示跑马灯数据
		String pmdString="截至目前：";
		boolean flag=true;
		for (int i = 0; i < datas.length; i++) {
			VALUE +=Integer.valueOf(datas[i]);
			if (flag) {
				pmdString=pmdString+str[i]+"未处理有"+datas[i]+"条";
				flag=false;
			}else {
				pmdString=pmdString+","+str[i]+"未处理有"+datas[i]+"条";
			}
		}
		//可变文本类参考SpannableStringBuilder
        SpannableString ss = new SpannableString(pmdString); 
        int startLength=5;
        for (int i = 0; i < datas.length; i++) {
				int nameLength=str[i].length()+4;
				int numLength=datas[i].length();
			//用颜色标记文本
			ss.setSpan(new ForegroundColorSpan(Color.RED), startLength+nameLength, startLength+nameLength+numLength,  
					//setSpan时需要指定的 flag,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE(前后都不包括).
					Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			startLength=startLength+nameLength+numLength+2;
		}
		tv_pmd2.setText(ss);
		NumberFormat nt = NumberFormat.getPercentInstance();
		nt.setMinimumFractionDigits(1);
		for (int i = 0; i < datas.length; i++) {
			if ("0".equals(datas[i])) {
				continue;
			}
            mSeries2.add(nt.format((float)((Float.valueOf(datas[i])/VALUE))), (float)((Float.valueOf(datas[i])/VALUE)));// 设置种类名称和对应的数值，前面是（key,value）键值对
            SimpleSeriesRenderer renderer = new SimpleSeriesRenderer();
            if (i < COLORS.length) {
                     renderer.setColor(COLORS[i]);// 设置描绘器的颜色
            } else {
                     renderer.setColor(getRandomColor());// 设置描绘器的颜色
            }
            wRenderer.setChartTitleTextSize(DisplayUtil.sp2px(this, 12));// 设置饼图标题大小
            wRenderer.addSeriesRenderer(renderer);// 将最新的描绘器添加到DefaultRenderer中
		}
		GraphicalView wChartView = ChartFactory.getPieChartView(getApplicationContext(),
				mSeries2, wRenderer);// 构建mChartView
		warningChart.addView(wChartView, new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
		wChartView.repaint();
		gv_legend2.setAdapter(new LegendAdapter(this, COLORS, Arrays.asList(str)));
	}
	private void initBarChart() {
		/* ****添加曲线***** */
		// mRenderer.setXTitle("ppi"); // 设置为X轴的标题
		// mRenderer.setYTitle("数值"); // 设置为Y轴的标题
		// mRenderer.setChartTitle("achartengine折线图"); // 设置图表标题
		mRenderer.setMargins(new int[] { DisplayUtil.dip2px(this, 30), DisplayUtil.dip2px(this, 20), DisplayUtil.dip2px(this, 40), DisplayUtil.dip2px(this, 10) }); // 上左下右边距
		mRenderer.setAxisTitleTextSize(DisplayUtil.sp2px(this, 12)); // 设置轴标题文本大小
		// mRenderer.setLabelsColor(Color.rgb(0xD2, 0x69, 0x1E)); // 坐标名称及标题颜色
		mRenderer.setXLabelsColor(Color.BLACK);// 设置X轴刻度颜色
		mRenderer.setYLabelsColor(0, Color.BLACK);// 设置Y轴刻度颜色
		mRenderer.setChartTitleTextSize(DisplayUtil.sp2px(this, 12));// 设置图表标题文字的大小
		mRenderer.setLabelsTextSize(DisplayUtil.sp2px(this, 12));// 设置标签的文字大小
		mRenderer.setYLabels(7);// 设置Y轴刻度个数
		mRenderer.setYLabelsAlign(Paint.Align.RIGHT); // 设置刻度线与Y轴之间的相对位置关系
		mRenderer.setClickEnabled(false);
//		mRenderer.setZoomEnabled(false); // 设置是否可以滑动及放大缩小;
		mRenderer.setPanEnabled(false);
		mRenderer.setApplyBackgroundColor(true); // 设置背景颜色可应用
		mRenderer.setBackgroundColor(Color.WHITE); // 内部颜色
		mRenderer.setMarginsColor(Color.WHITE); // 外部颜色
		mRenderer.setShowLegend(true); // 隐藏曲线以外的部分
		mRenderer.setLegendHeight(DisplayUtil.dip2px(this, 20));
		mRenderer.setLegendTextSize(DisplayUtil.sp2px(this, 12));
		mRenderer.setSelectableBuffer(10);

		mRenderer.setShowGrid(true);// 显示网格
		mRenderer.setShowGridX(true);
		mRenderer.setGridColor(Color.GRAY);
		mRenderer.setYAxisMax(300.0f);
		mRenderer.setYAxisMin(0.0f);
		mRenderer.setXAxisMin(0.5f); // 设置x轴最小值
		mRenderer.setXAxisMax(7 + 0.5); // 设置x轴最大值
		mRenderer.setAxesColor(Color.parseColor("#4488BB"));// 设置坐标轴的颜色
		mRenderer.setXLabels(0);
		mRenderer.setPanEnabled(false, false);// 设置滑动,这边是横向可以滑动,竖向不可滑动
		mRenderer.setZoomEnabled(false, false);
		mRenderer.setBarSpacing(0.5f);// 柱形图间隔
		mRenderer.setFitLegend(true);// 调整合适的位置
	}
	int tmp1,tmp2,tmp3,tmp4;

	private void updateBarChart() {
		if(!BeanUtils.isEmpty(statusList)){
			for (int i = 0; i < statusList.size(); i++) {
				Log.i(TAG, " statusList "+statusList.size());
				if("0".equals(statusList.get(i).getStatus())){
					tmp1=Integer.valueOf(statusList.get(i).getCount());//市待派发
				}else if("1".equals(statusList.get(i).getStatus())){
					tmp2 = Integer.valueOf(statusList.get(i).getCount());//县已派发
				}else if("2".equals(statusList.get(i).getStatus())){
					tmp3 = Integer.valueOf(statusList.get(i).getCount());//市已派发
				}else if("3".equals(statusList.get(i).getStatus())){
					tmp4 = Integer.valueOf(statusList.get(i).getCount());//县已派发
				}else if("4".equals(statusList.get(i).getStatus())){
					num3 = Integer.valueOf(statusList.get(i).getCount());//待评价
				}else if("5".equals(statusList.get(i).getStatus())){
					num4 = Integer.valueOf(statusList.get(i).getCount());//已办结
				}else if("10".equals(statusList.get(i).getStatus())){
					num5 = Integer.valueOf(statusList.get(i).getCount());//保存
				}else if("11".equals(statusList.get(i).getStatus())){
					num6 = Integer.valueOf(statusList.get(i).getCount());//处理中
				}else if("12".equals(statusList.get(i).getStatus())){
					num7 = Integer.valueOf(statusList.get(i).getCount());//已终止
				}
			}
			num1= tmp1+tmp2;
			num2 = tmp3+tmp4;
		}
		series1 = new XYSeries("工单数量", 0); // XY坐标序列
		series1.add(1, num5);
		series1.add(2, num1);
		series1.add(3, num2);
		series1.add(4, num3);
		series1.add(5, num4);
		series1.add(6, num6);
		series1.add(6, num7);
		mDataset.addSeries(series1);
		String[] str={"保存","待派发","已派发","待评价","已办结","处理中","终止"};
		for (int i = 0; i < str.length; i++) {
			mRenderer.addXTextLabel(i+1, str[i]);
		}
		/* 曲线1 */
		renderer1 = new XYSeriesRenderer();
		renderer1.setPointStyle(PointStyle.CIRCLE); // 坐标点形式
		renderer1.setPointStrokeWidth(DisplayUtil.dip2px(this, 15)); // 坐标点的大小
		renderer1.setColor(Color.parseColor("#FF7F50")); // 温度线红色 温度
		renderer1.setLineWidth(3); // 线宽3
		renderer1.setDisplayChartValues(true);// 将点的值显示出来
		renderer1.setChartValuesSpacing(DisplayUtil.dip2px(this, 5));// 显示的点的值与图的距离
		renderer1.setChartValuesTextAlign(Align.RIGHT);
		renderer1.setChartValuesTextSize(DisplayUtil.sp2px(this, 12));// 点的值的文字大小
		mRenderer.addSeriesRenderer(renderer1);
		GraphicalView mChartView = ChartFactory.getBarChartView(this, mDataset, mRenderer,
				Type.DEFAULT);
		numChart.addView(mChartView, new LayoutParams(LayoutParams.MATCH_PARENT,
				LayoutParams.MATCH_PARENT));
		mChartView.repaint();
	}
	
	public static void finishMySelf() {
		mContext.finish();
	}
	
	public static void setListViewAttribute(Context context, ListView listView) {
		listView.setDivider(context.getResources().getDrawable(R.color.gray_system_bg));
		listView.setDividerHeight(1);
		listView.setFooterDividersEnabled(false);
		listView.setCacheColorHint(Color.TRANSPARENT);
		listView.setFadingEdgeLength(0);
		listView.setSelector(R.color.transparent);
	}
	
	private void loadData(int what, int index, boolean isDialog) {
		ApiRequest request = OAInterface.getAllAppeals("0", index);
		if (request != null) {
			if (isDialog) {
				invoke.invokeWidthDialog(request, callBack, what);// 第一页，显示进度对话框
			} else {
				invoke.invoke(request, callBack, what);// 从第2页起，采用下拉加载方式，不需要显示进度对话框
			}
		}
	}
	@Override
	public void loadData(int position) {
		if (!hasListData) {
			loadData(GET_HOME_LIST, pageIndex, false);
		}
		
		if (!hasChartData) {
			invoke.invoke(OAInterface.getAppealStatistics(),callBack2);
		}
	}
}
