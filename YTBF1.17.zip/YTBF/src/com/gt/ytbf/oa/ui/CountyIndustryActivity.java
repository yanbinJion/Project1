package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.CountyIndustryInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.CountyAdatper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class CountyIndustryActivity extends BaseActivity {
	
	public static final String[] ITTILES = new String[] { "主营业务", "工业增加值", "利税总额" };
	private InvokeHelper invoke;
	private LayoutInflater layoutInflater;
	private LinearLayout layout;
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	private CommenViewPagerHelper helper;
	private View mainBusView, addIndustryView, profitView;
	private ListView lv_target1,lv_target2,lv_target3;
	private CountyAdatper mAdapterOne,mAdapterTwo,mAdapterThree;
	List<CountyIndustryInfo> mList = new ArrayList<CountyIndustryInfo>();
	public static final int PAGETYPEONE = 1;
	public static final int PAGETYPETWO = 2;
	public static final int PAGETYPETHREE = 3;
	private TextView time1,time2,time3;
	private String time;
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);

		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_common_tabpageindicator);
		initTitleBar(R.string.county_industry_title, backListener, null);
		invoke = new InvokeHelper(this);
		loadData();
		initView();
		initViewPagers(savedInstanceState);
	}

	private void initView() {
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.viewpage);
	}

	private void initViewPagers(Bundle savedInstanceState) {
		helper = new CommenViewPagerHelper(CountyIndustryActivity.this, layout);
		helper.onCreate(savedInstanceState);
		List<View> views = new ArrayList<View>();
		mainBusView = layoutInflater.inflate(R.layout.activity_county_industry, null);
		views.add(mainBusView);
		addIndustryView = layoutInflater.inflate(R.layout.activity_county_industry, null);
		views.add(addIndustryView);
		profitView = layoutInflater.inflate(R.layout.activity_county_industry, null);
		views.add(profitView);
		
		for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));
		}
        helper.showViews(mListDatas);
        loadView();
	}
	
	private void loadView() {
		lv_target1 = (ListView)mainBusView.findViewById(R.id.lv_target);
		time1 = (TextView) mainBusView.findViewById(R.id.time);
		lv_target2 = (ListView)addIndustryView.findViewById(R.id.lv_target);
		time2 = (TextView) addIndustryView.findViewById(R.id.time);
		lv_target3 = (ListView)profitView.findViewById(R.id.lv_target);
		time3 = (TextView) profitView.findViewById(R.id.time);
	}

	private void loadData() {
		invoke.invoke(OAInterface.getQueryStatistics("5", "", ""), callBack);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			if (!BeanUtils.isEmpty(response)) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					if (Constants.SUCCESS_CODE.equals(item.get("code"))) {
						List<ResultItem> items = item.getItems("DATA");
						for (ResultItem resultItem : items) {
							CountyIndustryInfo info = new CountyIndustryInfo();
							time = resultItem.getString("YF");
							//名称
							info.setZbmc(resultItem.getString("ZBMC"));
							//主营业务
//							info.setZndmb(resultItem.getString("ZYYW_NDMB"));
							info.setZtbzz(resultItem.getString("ZYYW_TBZZ"));
							info.setZwc(resultItem.getString("ZYYW_WC"));
//							info.setZwcmbjd(resultItem.getString("ZYYW_WCMBJD"));
//							info.setZzflqspm(resultItem.getString("ZYYW_ZFLQSPM"));
//							info.setZzllqspm(resultItem.getString("ZYYW_ZLLQSPM"));
							//工业增加值
//							info.setGndmb(resultItem.getString("GYZJZ_NDMB"));
							info.setGtbzz(resultItem.getString("GYZJZ_TBZZ"));
							info.setGwc(resultItem.getString("GYZJZ_WC"));
//							info.setGwcmbjd(resultItem.getString("QYZJZ_WCMBJD"));
//							info.setGzflqspm(resultItem.getString("QYZJZ_ZFLQSPM"));
//							info.setGzllqspm(resultItem.getString("GYZJZ_ZLLQSPM"));
							//利税总额
//							info.setLndmb(resultItem.getString("LSZE_NDMB"));
							info.setLtbzz(resultItem.getString("LSZE_TBZZ"));
							info.setLwc(resultItem.getString("LSZE_WC"));
//							info.setLwcmbjd(resultItem.getString("LSZE_WCMBJD"));
//							info.setLzflqspm(resultItem.getString("LSZE_ZFLQSPM"));
//							info.setLzllqspm(resultItem.getString("LSZE_ZLLQSPM"));
							mList.add(info);
							char[] array = time.toCharArray();
							if(array[0]=='0'){
								time1.setText("区间:1-"+array[1]+"月");
								time2.setText("区间:1-"+array[1]+"月");
								time3.setText("区间:1-"+array[1]+"月");
							}else{
								time1.setText("区间:1-"+time+"月");
								time2.setText("区间:1-"+time+"月");
								time3.setText("区间:1-"+time+"月");
							}
							if(mAdapterOne ==null){
								mAdapterOne = new CountyAdatper(CountyIndustryActivity.this,mList,PAGETYPEONE);
								lv_target1.setAdapter(mAdapterOne);
							}else{
								mAdapterOne.notifyDataSetChanged();
							}
							
							if(mAdapterTwo ==null){
							mAdapterTwo = new CountyAdatper(CountyIndustryActivity.this,mList,PAGETYPETWO);
								lv_target2.setAdapter(mAdapterTwo);
							}else{
								mAdapterTwo.notifyDataSetChanged();
							}
							
							if(mAdapterThree ==null){
								mAdapterThree = new CountyAdatper(CountyIndustryActivity.this,mList,PAGETYPETHREE);
								lv_target3.setAdapter(mAdapterThree);
							}else{
								mAdapterThree.notifyDataSetChanged();
							}
							
						}
					}
				}
			}
		}
	};
}
