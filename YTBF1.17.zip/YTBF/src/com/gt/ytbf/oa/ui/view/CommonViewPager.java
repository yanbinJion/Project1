package com.gt.ytbf.oa.ui.view;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.OfficeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ch on 2016/5/6.
 */
public class CommonViewPager {

    private int type;
    private String companyName;
    private String companyAddress;
    protected Context context;
    private View mRootView;
    private ListView listView;
    private List<OfficeInfo> mOfficeCategories;


    public CommonViewPager(Context context,String companyName,String companyAddress, int type) {
        this.context = context;
        this.companyName=companyName;
        this.companyAddress=companyAddress;
        this.type=type;

        loadData();

    }

    private void loadData() {
        OfficeInfo officeCategory1 = new OfficeInfo(R.drawable.ic_launcher, "区域经济的迅速发展历程", "2016-04-20");
        OfficeInfo officeCategory2 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory3 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory4 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory5 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory6 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory7 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory8 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory9 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory10 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory11 = new OfficeInfo(R.drawable.ic_launcher, "用新发展理念指导转型升级", "2016-04-20");
        mOfficeCategories = new ArrayList<OfficeInfo>();
        mOfficeCategories.add(officeCategory1);
        mOfficeCategories.add(officeCategory2);
        mOfficeCategories.add(officeCategory3);
        mOfficeCategories.add(officeCategory4);
        mOfficeCategories.add(officeCategory5);
        mOfficeCategories.add(officeCategory6);
        mOfficeCategories.add(officeCategory7);
        mOfficeCategories.add(officeCategory8);
        mOfficeCategories.add(officeCategory9);
        mOfficeCategories.add(officeCategory10);
        mOfficeCategories.add(officeCategory11);

        initView();
    }

    private void initView(){
        /*if (type==0) {
//            mRootView = View.inflate(context, R.layout.view_pager_layout, null);
//            listView = (ListView) mRootView.findViewById(R.id.vp_lv);
//            listView.setAdapter(new PagerListAdapter());
//            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                    Toast.makeText(context, mOfficeCategories.get(position).getContent(), Toast.LENGTH_SHORT).show();
//                }
//            });
        }if (type==1){
            mRootView = View.inflate(context, R.layout.viewpager_company_detail, null);
            TextView tv_company_name = (TextView) mRootView.findViewById(R.id.tv_company_name);
            tv_company_name.setText(companyName);
            TextView tv_company_address = (TextView) mRootView.findViewById(R.id.tv_company_address);
            tv_company_address.setText(companyAddress);
        }if (type==2){
            mRootView = View.inflate(context, R.layout.viewpager_company_appeal, null);
        }if (type==3){

            mRootView = View.inflate(context, R.layout.viewpager_company_plan_create, null);
            TextView tv_plan_create = (TextView) mRootView.findViewById(R.id.tv_plan_create);
            tv_plan_create.setText(companyName);
        }*/
    }

    public View getView(){
        return mRootView;
    }
    private class PagerListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return mOfficeCategories==null?0:mOfficeCategories.size();
        }

        @Override
        public Object getItem(int position) {
            return mOfficeCategories.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView==null){
                convertView=View.inflate(context,R.layout.viewpager_item,null);
                holder = new ViewHolder();
                holder.iv_icon = (ImageView) convertView.findViewById(R.id.iv_icon);
                holder.tv_content = (TextView) convertView.findViewById(R.id.tv_content);
                holder.tv_data = (TextView) convertView.findViewById(R.id.tv_data);
                convertView.setTag(holder);
            }else {
                holder= (ViewHolder) convertView.getTag();
            }
            OfficeInfo officeCategory = mOfficeCategories.get(position);
            holder.iv_icon.setImageResource(officeCategory.getIcon());
            holder.tv_content.setText(officeCategory.getContent());
            holder.tv_data.setText(officeCategory.getData());
            return convertView;
        }
    }

    class ViewHolder{
        private ImageView iv_icon;
        private TextView tv_content;
        private TextView tv_data;
    }

}
