package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.R.id;
import com.gt.ytbf.oa.R.layout;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.NewsDetailInfo;
import com.gt.ytbf.oa.bean.NewsInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebSettings.LayoutAlgorithm;

public class NewsDetailActivity extends BaseActivity {

	private WebView wbPolicyNews;
	
	private View.OnClickListener backListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

    private View.OnClickListener homeListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(NewsDetailActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    };
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_news_detail);
			
		wbPolicyNews = (WebView) findViewById(R.id.wb_policy_news);
		wbPolicyNews.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		wbPolicyNews.getSettings().setSupportZoom(true);
		wbPolicyNews.setHorizontalScrollBarEnabled(false);
		wbPolicyNews.getSettings().setLoadWithOverviewMode(true);
		//wbPolicyNews.getSettings().setBlockNetworkImage(true);
		String id = getIntent().getStringExtra("id");
		String title = getIntent().getStringExtra("title");
		initTitleBar(title, backListener, homeListener);
		InvokeHelper invoke = new InvokeHelper(this);
		invoke.invoke(OAInterface.getNewDetails(id), callBack);
		
		
	}
	
	 private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					List<ResultItem> resultItems = item.getItems("data");
					if (!BeanUtils.isEmpty(resultItems)) {
						String content = resultItems.get(0).getString("CONTENT");
//						resultItems.get(0).getString("TITLE");
						wbPolicyNews.loadDataWithBaseURL(null, getWebData(content), "text/html", "utf-8", null);
					}
					
				}
			}			

		}
			
	};
	
	private String getWebData(String bodyHTML) {
	    String head = "<head><style>img {max-width:100%; width:auto; height: auto;}</style></head>";
	    return "<html>" + head + "<body>" + bodyHTML + "</body></html>";
	}

}
