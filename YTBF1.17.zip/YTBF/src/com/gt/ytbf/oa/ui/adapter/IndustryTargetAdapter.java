package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.IndustryTargetInfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class IndustryTargetAdapter extends BaseAdapter{

	private Context mContext;
	private List<IndustryTargetInfo> mData;
	private int type;
	public  IndustryTargetAdapter(Context context,List<IndustryTargetInfo> mData, int pagetypeone) {
		this.mContext = context;
		this.mData = mData;
		this.type = pagetypeone;
	}
	
	@Override
	public int getCount() {
		return mData.size()==0?null:mData.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.industrytargetitem,
					null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);
			hodler.tv_table04 = (TextView) convertView.findViewById(R.id.tv_table04);
			hodler.tv_table05 = (TextView) convertView.findViewById(R.id.tv_table05);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
	     
	     if(1==type){
	    	 hodler.tv_table1.setText(mData.get(position).getCompany());
	    	 hodler.tv_table01.setText(mData.get(position).getMonthData());
			 hodler.tv_table02.setText(mData.get(position).getSortOne());
			 hodler.tv_table03.setText(mData.get(position).getAddPercent());
			 hodler.tv_table04.setText(mData.get(position).getSortTwo());
			 hodler.tv_table05.setText(mData.get(position).getCompletePlan());
	     }else if(2==type){
	    	 hodler.tv_table1.setText(mData.get(position).getCompany());
	    	 hodler.tv_table01.setText(mData.get(position).getgMonthData());
			 hodler.tv_table02.setText(mData.get(position).getgSortOne());
			 hodler.tv_table03.setText(mData.get(position).getgAddPercent());
			 hodler.tv_table04.setText(mData.get(position).getgSortTwo());
			 hodler.tv_table05.setText(mData.get(position).getgCompletePlan());
	     }else{
	    	 hodler.tv_table1.setText(mData.get(position).getCompany());
	    	 hodler.tv_table01.setText(mData.get(position).getlMonthData());
			 hodler.tv_table02.setText(mData.get(position).getlSortOne());
			 hodler.tv_table03.setText(mData.get(position).getlAddPercent());
			 hodler.tv_table04.setText(mData.get(position).getlSortTwo());
			 hodler.tv_table05.setText(mData.get(position).getlCompletePlan());
	     }
		
		return convertView;
	}
	
	final class ViewHolder {
		TextView tv_table1, tv_table01, tv_table02, tv_table03, tv_table04, tv_table05;
	}
	
	
}
