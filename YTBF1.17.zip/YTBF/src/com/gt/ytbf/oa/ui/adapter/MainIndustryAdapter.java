package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.MainIndustryInfo;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MainIndustryAdapter extends BaseAdapter{

	int[] args ={R.drawable.lending_product01,R.drawable.lending_product02,R.drawable.lending_product03,
			R.drawable.lending_product04,R.drawable.lending_product05,R.drawable.lending_product06};
	private Context context;
	private List<String> mData;
	public MainIndustryAdapter(Context context, List<String> mList) {
		this.context = context;
		this.mData = mList;
	}

	@Override
	public int getCount() {
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.activity_indicator_list,
					null);
			hodler = new ViewHolder();
			hodler.econ_indicator_img = (ImageView) convertView.findViewById(R.id.econ_indicator_img);
			hodler.econ_indicator_tv = (TextView) convertView.findViewById(R.id.econ_indicator_tv);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		hodler.econ_indicator_img.setImageResource(args[position]);
		hodler.econ_indicator_tv.setText(mData.get(position));
		return convertView;
	}
	
	final class ViewHolder {
		TextView econ_indicator_tv;
		ImageView econ_indicator_img;
	}
}
