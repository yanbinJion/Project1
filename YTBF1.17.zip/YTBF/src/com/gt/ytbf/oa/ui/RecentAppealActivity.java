package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.R.id;
import com.gt.ytbf.oa.R.layout;
import com.gt.ytbf.oa.R.string;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.RecentAppealAdapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class RecentAppealActivity extends BaseActivity {

	private ListView lv_recent_appeal;
	

	
	private View.OnClickListener backListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

    private View.OnClickListener homeListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//            Intent intent = new Intent(RecentAppealActivity.this, MainActivity.class);
//            startActivity(intent);
        	CompanyInfoDetailActivity.finishMySelf();
        	CompanyInfoActivity.finishMySelf();
            finish();
        }
    };
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_recent_appeal);
		initTitleBar(R.string.appeal_list, backListener, homeListener);
		initView();
		initData();
	}

	private void initData() {
		String orgCode = getIntent().getStringExtra("OrgCode");
		InvokeHelper invoke = new InvokeHelper(this);
		invoke.invokeWidthDialog(OAInterface.getCompanyInfo(orgCode), callBack);
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					ResultItem jqsqItem= item.getItems("jqsqInfo").get(0);
					List<ResultItem> jqsqItems=jqsqItem.getItems("jqsq");
					showRecentList(jqsqItems);
				}	
		}
		
	};
	private List<AppealCenterModel> recentDatas;
	private void initView() {
		lv_recent_appeal = (ListView) findViewById(R.id.lv_recent_appeal);
	}

	protected void showRecentList(List<ResultItem> resultItems) {
			if (BeanUtils.isEmpty(resultItems)) {
				return;
			}
			recentDatas = new ArrayList<AppealCenterModel>(2);
			 for (ResultItem item : resultItems) {
				String title = item.getString("TITLE");
				String content = item.getString("CONTENT");
				String time = item.getString("CTIME");
				String lx = item.getString("LX");
				String state = item.getString("STATUS");
				String bizId=item.getString("BIZID");
				recentDatas.add(new AppealCenterModel(bizId,title,lx, content,state, time));
			}
			 loadRecentView();
	}

	private void loadRecentView() {
		lv_recent_appeal.setAdapter(new RecentAppealAdapter(this, recentDatas));
		lv_recent_appeal.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if (recentDatas.size() <= position) {
					return;
				}
				Intent intent = new Intent(new Intent(RecentAppealActivity.this,AppealCenterActivity.class));
				Bundle bundle = new Bundle();
				bundle.putSerializable("appealInfo",recentDatas.get(position));
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});
	}
	
}
