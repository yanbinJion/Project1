package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.common.LoadDataListener;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AdInfo;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.AppealListUtil;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.adapter.AppealAdapter;
import com.gt.ytbf.oa.ui.view.AutoRollLayout;
import com.gt.ytbf.oa.ui.view.ImageViewPagerHelper;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;

/**
 * 首页
 * */
public class MainEntryActivityQY extends BaseActivity implements LoadDataListener{

	private final String FIRST = "1";
	private final String SECOND = "2";
	private final String THIRD = "3";
	private static final int TYPE = 1;
	private static final int FIRST_PAGE = 1;
	private static final int GET_APPEAL=0;
	private static final int GET_WAITEVALUATE=1;
	private static final int GET_PROCESSOVER=2;
	private int firstIndex = 1;
	private int secondIndex = 1;
	private int thirdIndex = 1;
	/**
	 * 功能列表适配器
	 * */
	private LinearLayout mTabLayout;
	private ImageViewPagerHelper viewHelper;
	/**
	 * 图片轮播资源
	 * */
	private List<AdInfo> list = new ArrayList<AdInfo>();

	/**
	 * 定时循环显示图片
	 * */

	private String[] strings;
	private int[] res;
	private List<View> views;
	private PullToRefreshListView myAppealView;
	private PullToRefreshListView waitEvaluateView;
	private PullToRefreshListView processOverView;
	private AppealAdapter myAppealAdapter;
	private AppealAdapter waitEvaluateAdapter;
	private AppealAdapter processOverAdapter;

	private AutoRollLayout mAutoRollLayout;
	private int mTabLayoutTop;
	private LinearLayout linearlayout;
	private LinearLayout linearlayout_gone;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_entry);
		initTitleBar(R.string.tab_home_title, null, null);
		mTabLayout = (LinearLayout) findViewById(R.id.main_tab_layout);
		viewHelper = new ImageViewPagerHelper(this, mTabLayout);
		viewHelper.onCreate(savedInstanceState);
		setMainNavigator();
		initView();
	}

	private void initView() {
		mAutoRollLayout = (AutoRollLayout) findViewById(R.id.autorolllayout);
		MainActivity.getInstance().setRollLayout(mAutoRollLayout);
		linearlayout = (LinearLayout) findViewById(R.id.linearlayout);
		linearlayout_gone = (LinearLayout) findViewById(R.id.linearlayout_gone);
		
		View view0 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view1 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view2 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view4 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view5 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);

		strings = new String[] { "我的诉求", "待评价", "已办结", "我要诉求", "诉求中心" };
		res = new int[] { R.drawable.wdsq_selector, R.drawable.dpj_selector,
				R.drawable.ybj_selector, R.drawable.wysq_selector, R.drawable.qyxx_selector };
		views = new ArrayList<View>();
		views.add(view0);
		views.add(view1);
		views.add(view2);
		views.add(view5);
		views.add(view4);

		myAppealView = (PullToRefreshListView) view0.findViewById(R.id.common_pullToRefresh_list);
		myAppealList = AppealListUtil.setProperty(myAppealView);
		myAppealView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
			// 下拉刷新数据
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					firstIndex = 1;
					appeals.clear();
					getDatas(FIRST, firstIndex, callBack,GET_APPEAL);
				}else {
					myAppealView.onPullDownRefreshComplete();
				}
			}

			// 上拉加载下一页的数据
			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					firstIndex += 1;
					getDatas(FIRST, firstIndex, callBack,GET_APPEAL);
				}else {
					myAppealView.onPullUpRefreshComplete();
				}
			}
		});
		
		waitEvaluateView = (PullToRefreshListView) view1.findViewById(R.id.common_pullToRefresh_list);
		waitEvaluateList = AppealListUtil.setProperty(waitEvaluateView);
		waitEvaluateView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
			// 下拉刷新数据
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					secondIndex = 1;
					waitEvaluates.clear();
					getDatas(SECOND,secondIndex,callBack,GET_WAITEVALUATE);
				}else {
					waitEvaluateView.onPullDownRefreshComplete();
				}
			}
			// 上拉加载下一页的数据
			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					secondIndex += 1;
					getDatas(SECOND,secondIndex,callBack,GET_WAITEVALUATE);
				}else {
					waitEvaluateView.onPullUpRefreshComplete();
				}
			}
		});
		
		processOverView = (PullToRefreshListView) view2.findViewById(R.id.common_pullToRefresh_list);
		processOverList = AppealListUtil.setProperty(processOverView);
		processOverView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
			// 下拉刷新数据
			@Override
			public void onPullDownToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					thirdIndex = 1;
					processOvers.clear();
					getDatas(THIRD, thirdIndex, callBack,GET_PROCESSOVER);
				}else {
					processOverView.onPullUpRefreshComplete();
				}
			}
			// 上拉加载下一页的数据
			@Override
			public void onPullUpToRefresh(
					PullToRefreshBase<ListView> refreshView) {
				if (checkNetworkState()) {
					thirdIndex += 1;
					getDatas(THIRD, thirdIndex, callBack,GET_PROCESSOVER);
				}else {
					processOverView.onPullUpRefreshComplete();
				}
			}
		});
		updateUI();
	}

	protected void getDatas(String index, int pageIndex,
			IRequestCallBack callBack,int what) {
		invoke.invokeWidthDialog(OAInterface.getAppeals(index, pageIndex),callBack,what);
	}

	private void updateUI() {
		List<ImageViewPagerHelper.PagerModel> pages = new ArrayList<ImageViewPagerHelper.PagerModel>();
		for (int i = 0; i < strings.length; i++) {
			pages.add(viewHelper.new PagerModel(strings[i], res[i], views
					.get(i), null));

		}

		viewHelper.showViews(pages, TYPE);

	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					ResultItem countItem = (ResultItem) item.get("lstCount");
					parserUnread(countItem);
					List<ResultItem> resultItems = item.getItems("data");
					if (what==GET_APPEAL) {
						showAppealList(resultItems);
					}else if (what==GET_WAITEVALUATE) {
						showWaitEvaluateList(resultItems);
					}else if (what==GET_PROCESSOVER) {
						showProcessOverList(resultItems);
					}
				}
			}
		}
	};
	
	private void parserUnread(ResultItem item) {
		if (null != item) {
			String appeal = item.getString("qysqlb");
			String wait = item.getString("qydpj");
			String over = item.getString("qyybj");
			int[] count = {
					StringUtils.isNullOrEmpty(appeal) ? 0 : Integer.valueOf(appeal),
					StringUtils.isNullOrEmpty(wait) ? 0 : Integer.valueOf(wait),
					StringUtils.isNullOrEmpty(over) ? 0 : Integer.valueOf(over) };
			viewHelper.updateText(count);
		}
	}
	private List<AppealCenterModel> appeals = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> waitEvaluates = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> processOvers = new ArrayList<AppealCenterModel>();
	private ListView myAppealList;
	private ListView waitEvaluateList;
	private ListView processOverList;
	private InvokeHelper invoke;
	//列表个数，默认为0
	private String thirdSize="0";
	private String secondSize="0";
	private String firstSize="0";

	private void loadDatas(int position) {
		invoke = new InvokeHelper(this);
		 if (0 == position) {
			 firstIndex=1;
			 if (!BeanUtils.isEmpty(appeals)) {
				 appeals.clear();
			 }
			 invoke.invoke(OAInterface.getAppeals(FIRST, FIRST_PAGE),callBack,GET_APPEAL);
		 } else if (1 == position) {
			 secondIndex=1;
			 if (!BeanUtils.isEmpty(waitEvaluates)) {
				 waitEvaluates.clear();
			 }
			 invoke.invoke(OAInterface.getAppeals(SECOND, FIRST_PAGE),callBack,GET_WAITEVALUATE);
		 } else if (2 == position){
			 thirdIndex=1;
			 if (!BeanUtils.isEmpty(processOvers)) {
				 processOvers.clear();
			 }
			 invoke.invoke(OAInterface.getAppeals(THIRD, FIRST_PAGE),callBack,GET_PROCESSOVER);
		 } 
		 
	 }
	protected void showProcessOverList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,processOverView,thirdIndex,thirdSize);
			processOverAdapter.setData(processOvers);
			return;
		}
		processOvers.addAll(AppealListUtil.getAppeal(resultItems));
		thirdSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == processOverAdapter) {
			processOverAdapter = new AppealAdapter(this, processOvers);
			processOverList.setAdapter(processOverAdapter);
			processOverList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					if (processOvers.size() <= position) {
						return;
					}
					Intent intent = new Intent(new Intent(
							MainEntryActivityQY.this,
							AppealCenterActivity.class));
					Bundle bundle = new Bundle();
					bundle.putSerializable("appealInfo",
							processOvers.get(position));
					intent.putExtras(bundle);
					startActivity(intent);
				}
			});
		} else {
			processOverAdapter.setData(processOvers);
		}
		AppealListUtil.checkDatas(resultItems,processOverView,thirdIndex,thirdSize);
	}

	protected void showWaitEvaluateList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,waitEvaluateView,secondIndex,secondSize);
			waitEvaluateAdapter.setData(waitEvaluates);
			return;
		}
		waitEvaluates.addAll(AppealListUtil.getAppeal(resultItems));
		secondSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == waitEvaluateAdapter) {
			waitEvaluateAdapter = new AppealAdapter(this, waitEvaluates);
			waitEvaluateList.setAdapter(waitEvaluateAdapter);
			waitEvaluateList.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					if (waitEvaluates.size() <= position) {
						return;
					}
					Intent intent = new Intent(new Intent(MainEntryActivityQY.this,AppealCenterActivity.class));
					Bundle bundle = new Bundle();
					bundle.putSerializable("appealInfo",waitEvaluates.get(position));
					bundle.putBoolean("isHandler", true);
					intent.putExtras(bundle);
					startActivity(intent);
				}
			});
		} else {
			waitEvaluateAdapter.setData(waitEvaluates);
		}
		AppealListUtil.checkDatas(resultItems,waitEvaluateView,secondIndex,secondSize);
	}

	protected void showAppealList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,myAppealView,firstIndex,firstSize);
			myAppealAdapter.setData(appeals);
			return;
		}
		appeals.addAll(AppealListUtil.getAppeal(resultItems));
		firstSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == myAppealAdapter) {
			myAppealAdapter = new AppealAdapter(this, appeals);
			myAppealList.setAdapter(myAppealAdapter);
			myAppealList.setOnItemClickListener(new OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					if (appeals.size() <= position) {
						return;
					}
					Intent intent = new Intent(new Intent(MainEntryActivityQY.this,AppealCenterActivity.class));
					Bundle bundle = new Bundle();
					bundle.putSerializable("appealInfo", appeals.get(position));
					bundle.putBoolean("isHandler", "10".equals(appeals.get(position).getAppealState()));
					intent.putExtras(bundle);
					startActivity(intent);
				}
			});
		} else {
			myAppealAdapter.setData(appeals);
		}
		AppealListUtil.checkDatas(resultItems,myAppealView,firstIndex,firstSize);
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		viewHelper.updateUI();
		loadDatas(viewHelper.getCurrentIndex());
	}

	@Override
	public void onBackPressed() {
		MainActivity.getInstance().onBackPressed();
	}

	@Override
	public void loadData(int position) {
		loadDatas(position);
	}

}
