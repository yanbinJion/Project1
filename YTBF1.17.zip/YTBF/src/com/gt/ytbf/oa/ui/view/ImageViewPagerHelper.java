package com.gt.ytbf.oa.ui.view;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.common.LoadDataListener;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.AppealActivity;
import com.gt.ytbf.oa.ui.CompanyInfoActivity;
import com.gt.ytbf.oa.ui.EconomicalOperationSetupActivity;
import com.gt.ytbf.oa.ui.EnterpriseWarningActivity;
import com.gt.ytbf.oa.ui.MyAppealActivity;

import android.app.Activity;
import android.app.LocalActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by root on 16-6-29.
 */
public class ImageViewPagerHelper {

    /**
     * 需要使用的上下文
     * */
    private Context mContext;
    /**
     * 显示的界面列表
     * */
    private List<PagerModel> mData = new ArrayList<PagerModel>();
    private ViewPager mPager;
    private LocalActivityManager activityManager;
    private CommenPagerAdapter mAdapter;
    private LayoutInflater mInflater;
    private ViewGroup mGroup;
    private int curIndex = 0;
    private LinearLayout mTabLayout;
    private ArrayList<TextView> unReadTxts;
	private List<ImageView> im;
	private int type;

    public ImageViewPagerHelper(Context context, ViewGroup v){
        this.mContext = context;
        mGroup = v;
        mInflater = LayoutInflater.from(mContext);
        initViews();
    }

    //设置数据源，显示界面
    //type值由企业精准帮扶使用，不使用可用0代替
    public void showViews(List<PagerModel> data,int type) {
    	this.type=type;
        if (!BeanUtils.isEmpty(data)) {
            for (int i = 0; i < data.size(); i++) {
                if (null == data.get(i).getCls()) {
                    break;
                }
                if (null != activityManager) {
                    data.get(i).setView(activityManager.startActivity(("view" + i), new Intent(mContext, data.get(i).getCls())).getDecorView());
                }
            }
            mData.clear();
            mData.addAll(data);
            unReadTxts = new ArrayList<TextView>(mData.size());
            im = new ArrayList<ImageView>(mData.size());
            mAdapter.notifyDataSetChanged();
            mPager.setCurrentItem(curIndex);
            updateUI();
        }
    }

	//设置数据源，显示界面
    public void showViews(List<PagerModel> data) {
        if (!BeanUtils.isEmpty(data)) {
            for (int i = 0; i < data.size(); i++) {
                if (null == data.get(i).getCls()) {
                    break;
                }
                if (null != activityManager) {
                    data.get(i).setView(activityManager.startActivity(("view" + i), new Intent(mContext, data.get(i).getCls())).getDecorView());
                }
            }
            mData.clear();
            mData.addAll(data);
            unReadTxts = new ArrayList<TextView>(mData.size());
            im = new ArrayList<ImageView>(mData.size());
//            updateUI();
        }
    }

    private void initTabView() {
        if (mTabLayout.getChildCount() > 0) {
            mTabLayout.removeAllViews();
        }
        LinearLayout childView = null;
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.weight = 1;
        for (int i = 0; i < mData.size(); i++) {
            childView = (LinearLayout) mInflater.inflate(R.layout.tab_layout_item, null);
            FrameLayout frame = (FrameLayout) childView.getChildAt(0);
            ((ImageView) frame.getChildAt(0)).setImageResource(mData.get(i).getTabImg());
            im.add((ImageView) frame.getChildAt(0));
            unReadTxts.add((TextView) childView.findViewById(R.id.tv_pop));
            ((TextView) childView.getChildAt(1)).setText(mData.get(i).getTabString());
            childView.setLayoutParams(params);
            childView.setOnClickListener(new MyOnClickListener(i));
            mTabLayout.addView(childView);
        }
    }

    //刷新界面
    public void updateUI() {
    	if (!BeanUtils.isEmpty(unReadTxts)) {
			unReadTxts.clear();
		}
        initTabView();
        mAdapter.notifyDataSetChanged();
        mPager.setCurrentItem(curIndex);
        setSelectImage(curIndex);
        setSelectText(curIndex);
    }
    
    //刷新条数
    public void updateText(int index, int size) {
//    	Log.i("test", unReadTxts.size()+"+"+index+"+"+size);
    	if (unReadTxts.size() > index) {
    		if (size < 1) {
    			unReadTxts.get(index).setVisibility(View.GONE);
    		} else {
    			unReadTxts.get(index).setVisibility(View.VISIBLE);
    			if (size > 99) {
    				unReadTxts.get(index).setText("99+");
    			} else {
    				unReadTxts.get(index).setText(size+"");
    			}
    		}
    	}
    }
    
    public void updateText(int[] size) {
    	if (null != size && size.length > 0) {
    		for (int i = 0; i < size.length; i++) {
    			updateText(i, size[i]);
    		}
    	}
    }

    //获取当前显示的页面下标
    public int getCurrentIndex() {
        return curIndex;
    }

    public void onCreate(Bundle savedInstanceState) {
        if (null == activityManager && mContext instanceof Activity) {
            activityManager = new LocalActivityManager((Activity) mContext, true);
        }
        activityManager.dispatchCreate(savedInstanceState);
    }

    public void onResume() {
        if (null != activityManager) {
            activityManager.dispatchResume();
        }
    }

    private void initViews() {
        View rootView = mInflater.inflate(R.layout.common_image_view_pager, mGroup);
        mTabLayout = (LinearLayout) rootView.findViewById(R.id.common_tab);
        mPager = (ViewPager) rootView.findViewById(R.id.common_pager);
        mAdapter = new CommenPagerAdapter();
        mPager.setAdapter(mAdapter);
        mPager.setOnPageChangeListener(mOnPageChangeListener);
    }

    private void setSelectText(int position) {
        for (int i = 0; i < mData.size(); i++) {
            TextView text = (TextView) ((LinearLayout) mTabLayout.getChildAt(i)).getChildAt(1);
            if (i == position) {
                text.setTextColor(mContext.getResources().getColor(R.color.black));
            } else {
                text.setTextColor(mContext.getResources().getColor(R.color.gray));
            }
        }
    }
    private void setSelectImage(int position) {
    	for (int i = 0; i < mData.size(); i++) {
    		FrameLayout frame = (FrameLayout) ((LinearLayout) mTabLayout.getChildAt(i)).getChildAt(0);
    		ImageView image = (ImageView) frame.getChildAt(0);
    		if (i == position) {
    			image.setSelected(true);
    		} else {
    			image.setSelected(false);
    		}
    	}
    }

    private class MyOnClickListener implements View.OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        public void onClick(View v) {
            mPager.setCurrentItem(index);
        }
    }

    private ViewPager.OnPageChangeListener mOnPageChangeListener= new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
        	curIndex = position;
        	setSelectImage(position);
        	setSelectText(position);
        	Activity temp = activityManager.getActivity("view" + position);
        	if (null != mContext && mContext instanceof LoadDataListener) {
        		((LoadDataListener) mContext).loadData(position);
        	}
        	if (type==1) {
        		if (position==mData.size()-2) {
    				mContext.startActivity(new Intent(mContext,MyAppealActivity.class));
				}if(position==mData.size()-1){
					mContext.startActivity(new Intent(mContext,AppealActivity.class));
				}
			}
        	if (type==2||type==3) {
        		if (position==mData.size()-1) {
        			mContext.startActivity(new Intent(mContext,AppealActivity.class));
				}
			}
        	if(type == 4){
        		if (position==mData.size()-3) {
    				//mContext.startActivity(new Intent(mConte xt,EnterpriseWarningActivity.class));
				}if(position==mData.size()-2){
					mContext.startActivity(new Intent(mContext,EconomicalOperationSetupActivity.class));
				}
				if(position==mData.size()-1){
					mContext.startActivity(new Intent(mContext,CompanyInfoActivity.class));
				}
        	}
        	
        	if(type == 11){
        		if (position==mData.size()-1) {
    				mContext.startActivity(new Intent(mContext,CompanyInfoActivity.class));
				}
        	}
        	curIndex = 0;
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    class CommenPagerAdapter extends PagerAdapter {

        /**
         */
        @Override
        public int getCount() {
            return mData.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }
        /**
         */
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            container.addView(mData.get(position).getView());
            return mData.get(position).getView();
        }
        /**
         */
        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View)object);
        }
    }

    public class PagerModel {
        private String tabString;
        private int tabImg;
        private View view;
        private Class cls;

        public PagerModel(String tabTitle, int img, View v, Class c) {
            tabString = tabTitle;
            tabImg = img;
            view = v;
            cls = c;
        }

		public String getTabString() {
            return tabString;
        }

        public void setTabString(String tabString) {
            this.tabString = tabString;
        }

        public View getView() {
            return view;
        }

        public void setView(View view) {
            this.view = view;
        }

        public Class getCls() {
            return cls;
        }

        public void setIntent(Class c) {
            this.cls = c;
        }

        public int getTabImg() {
            return tabImg;
        }

        public void setTabImg(int tabImg) {
            this.tabImg = tabImg;
        }
    }

}
