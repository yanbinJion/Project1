package com.gt.ytbf.oa.ui;
import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.CountyEconomyInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.CountyEconomyAdapter;
import com.nostra13.universalimageloader.core.assist.ViewScaleType;

public class CountyEconomyActivity extends BaseActivity {

	public static final String[] ITTILES = new String[] { "主营业务收入", "工业增加值", "利润总额" };
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	ArrayList<CountyEconomyInfo> mList = new ArrayList<CountyEconomyInfo>();
	private ListView lv_target1,lv_target2,lv_target3;
	private InvokeHelper invoke;
	private LinearLayout layout;
	private LayoutInflater layoutInflater;
	private CommenViewPagerHelper helper;
	
	private CountyEconomyAdapter mAdapterOne;
	private CountyEconomyAdapter mAdapterTwo;
	private CountyEconomyAdapter mAdapterThree;
	
	public static final int PAGETYPEONE = 1;
	public static final int PAGETYPETWO = 2;
	public static final int PAGETYPETHREE = 3;
	
	private View mainBusView;
	private View addIndustryView;
	private View profitView;
	private CountyEconomyInfo cInfo;
	private TextView tvSpace1;
	private TextView tvSpace2;
	private TextView tvSpace3;
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);

		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_county_economy);		
		initTitleBar(R.string.county_economy_title, backListener, null);
		invoke = new InvokeHelper(this);
		loadData();
		initView();		
		initViewPagers(savedInstanceState);
	}
		

	private void initView() {
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.ll_county_viewpage);		
		
	}

	private void initViewPagers(Bundle savedInstanceState) {

		helper = new CommenViewPagerHelper(CountyEconomyActivity.this, layout);
		helper.onCreate(savedInstanceState);
		List<View> views = new ArrayList<View>();
		mainBusView = layoutInflater.inflate(R.layout.activity_county_economy_target, null);
		views.add(mainBusView);
		addIndustryView = layoutInflater.inflate(R.layout.activity_county_economy_target, null);
		views.add(addIndustryView);
		profitView = layoutInflater.inflate(R.layout.activity_county_economy_target, null);
		views.add(profitView);
		
		for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));			
		}
		 helper.showViews(mListDatas);
	     loadView();
	}
	
	private void loadView() {
		lv_target1 = (ListView)mainBusView.findViewById(R.id.lv_county_target);
		lv_target2 = (ListView)addIndustryView.findViewById(R.id.lv_county_target);
		lv_target3 = (ListView)profitView.findViewById(R.id.lv_county_target);
		
		tvSpace1 = (TextView)mainBusView.findViewById(R.id.tv_space);
		tvSpace2 = (TextView)addIndustryView.findViewById(R.id.tv_space);
		tvSpace3 = (TextView)profitView.findViewById(R.id.tv_space);
		
		
	}
	
	/**
	 * 加载数据
	 */
	private void loadData() {
		invoke.invoke(OAInterface.getQueryStatistics("4", "", ""), new BaseRequestCallBack() {						

			@Override
			public void process(HttpResponse response, int what) {
				if(!BeanUtils.isEmpty(response)){
					ResultItem item = response.getResultItem(ResultItem.class);
					if(checkResult(item)){
						if(Constants.SUCCESS_CODE.equals(item.get("code"))){
							List<ResultItem> items = item.getItems("DATA");
							for (ResultItem resultItem : items) {
								cInfo = new CountyEconomyInfo();
								cInfo.setCompanyName(resultItem.getString("ZBMC"));
								cInfo.setYf(resultItem.getString("YF"));
								//主营业务收入
								cInfo.setYearTaget(resultItem.getString("ZYYWSR_NDMB"));
								cInfo.setMouthComplete(resultItem.getString("ZYYWSR_YZBYWC"));
								cInfo.setAddPercent(resultItem.getString("ZYYWSR_TBZZ"));
								cInfo.setCompletePlan(resultItem.getString("ZYYWSR_WCMBJD"));
								//工业增加值
								cInfo.setgYearTaget(resultItem.getString("GYZJZ_NDMB"));
								cInfo.setgMouthComplete(resultItem.getString("GYZJZ_YZBYWC"));
								cInfo.setgAddPercent(resultItem.getString("GYZJZ_TBZZ"));
								cInfo.setgCompletePlan(resultItem.getString("GYZJZ_WCMBJD"));
								//利税
								cInfo.setlYearTaget(resultItem.getString("LS_NDMB"));
								cInfo.setlMouthComplete(resultItem.getString("LS_YZBYWC"));
								cInfo.setlAddPercent(resultItem.getString("LS_TBZZ"));
								cInfo.setlCompletePlan(resultItem.getString("LS_ECMBJD"));
								mList.add(cInfo);
								
								if (mAdapterOne==null) {
									mAdapterOne = new CountyEconomyAdapter(CountyEconomyActivity.this, mList, PAGETYPEONE);
									lv_target1.setAdapter(mAdapterOne);
								} else {
									mAdapterOne.notifyDataSetChanged();
								}
								if (mAdapterTwo==null) {
									mAdapterTwo = new CountyEconomyAdapter(CountyEconomyActivity.this, mList, PAGETYPETWO);
									lv_target2.setAdapter(mAdapterTwo);
								} else {
									mAdapterTwo.notifyDataSetChanged();
								}
								if (mAdapterThree==null) {
									mAdapterThree = new CountyEconomyAdapter(CountyEconomyActivity.this, mList, PAGETYPETHREE);
									lv_target3.setAdapter(mAdapterThree);
								} else {
									mAdapterThree.notifyDataSetChanged();
								}
							
								
								char[] yTime = cInfo.getYf().toCharArray();
								
								if (yTime[0]=='0') {
									tvSpace1.setText("区间:1-"+yTime[1]+"月");
									tvSpace2.setText("区间:1-"+yTime[1]+"月");
									tvSpace3.setText("区间:1-"+yTime[1]+"月");
								}else {
									tvSpace1.setText("区间:1-"+cInfo.getYf()+"月");
									tvSpace2.setText("区间:1-"+cInfo.getYf()+"月");
									tvSpace3.setText("区间:1-"+cInfo.getYf()+"月");
								}
								
							}
														
						}
					}
				}
			}
		});
	}
	
	
}
