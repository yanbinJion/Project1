package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.WarningInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.WarningAdapter;

public class EnterpriseWarningActivity extends BaseActivity implements OnClickListener {

	private List<WarningInfo> warningInfos = new ArrayList<WarningInfo>();
	private static final String TAG = "EnterpriseWarningActivity";
	private InvokeHelper invoke;
	private ListView lv_warning;
	private WarningAdapter mAdapter = null;
	private EditText date_tv,time_tv,qy_tv;
	private String date,time,compname;
	private TextView search_tv;
	private ImageView warn_date_img;
	private ImageView warn_time_img;
	private PopupWindow pwMyPopWindow;
	private ListView lvPopupList;
	private  static final int NUM_OF_VISIBLE_LIST_ROWS = 4 ;
	private static final int NUM_OF_VISIBLE_LIST_ROWS_MONTH = 6;
	List<Map<String,String>> moreListYear;
	List<Map<String,String>> moreListMonth;
	private PopupWindow pwMyPopWindowMonth;
	private ListView lvPopupListMonth;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_enterprise_warning);
		initTitleBar(R.string.function_enterprise_warning, this, null);
		initData();
		initYearPopupWindow();
		initMonthPopupWindow();
		initView();
		invoke = new InvokeHelper(this);
		lv_warning = (ListView) findViewById(R.id.lv_warning);
		invoke.invoke(OAInterface.getWaringInfo("", "", "", "1"),
				callBack);
	}

	private void initMonthPopupWindow() {
		LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
	    View layout = inflater.inflate(R.layout.task_detail_popupwindow, null);
	    lvPopupListMonth = (ListView) layout.findViewById(R.id.lv_popup_list);
	    pwMyPopWindowMonth = new PopupWindow(layout);
	    pwMyPopWindowMonth.setFocusable(true);
	    lvPopupListMonth.setAdapter(new SimpleAdapter(EnterpriseWarningActivity.this, moreListMonth, R.layout.list_item_popupwindow, new String[] {"month_key"}, new int[] {R.id.tv_list_item}));
	    lvPopupListMonth.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(moreListMonth.get(position).get("month_key").equals("请选择月份")){
					time_tv.setText("");
					pwMyPopWindowMonth.dismiss();
				}else {
					String strMonth = moreListMonth.get(position).get("month_key");
					String [] strMonthSplit = strMonth.split(" ");
					time_tv.setText(strMonthSplit[0]);
					pwMyPopWindowMonth.dismiss();
				}
				
			}
		});
	    //控制popupwindow的宽度和高度自适应
	    lvPopupListMonth.measure(View.MeasureSpec.UNSPECIFIED,View.MeasureSpec.UNSPECIFIED);
	    pwMyPopWindowMonth.setWidth(lvPopupList.getMeasuredWidth());
	    pwMyPopWindowMonth.setHeight((lvPopupList.getMeasuredHeight() + 20)*NUM_OF_VISIBLE_LIST_ROWS_MONTH);
	   //控制popupwindow点击屏幕其他地方消失
	    pwMyPopWindowMonth.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.bg_popupwindow));
	    pwMyPopWindowMonth.setOutsideTouchable(true);
	}

	private void initYearPopupWindow() {
		LayoutInflater inflater = (LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE);
	    View layout = inflater.inflate(R.layout.task_detail_popupwindow, null);
	    lvPopupList = (ListView) layout.findViewById(R.id.lv_popup_list);
	    pwMyPopWindow = new PopupWindow(layout);
	    pwMyPopWindow.setFocusable(true);
	    lvPopupList.setAdapter(new SimpleAdapter(EnterpriseWarningActivity.this, moreListYear, R.layout.list_item_popupwindow, new String[] {"year_key"}, new int[] {R.id.tv_list_item}));
	    lvPopupList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				if(moreListYear.get(position).get("year_key").equals("请选择年份")){
					date_tv.setText("");
					pwMyPopWindow.dismiss();
				}else {
					String str = moreListYear.get(position).get("year_key");
					String [] strsplit = str.split(" ");
					date_tv.setText(strsplit[0]);
					pwMyPopWindow.dismiss(); 
				}
			}
		});
	    //控制popupwindow的宽度和高度自适应
	    lvPopupList.measure(View.MeasureSpec.UNSPECIFIED,View.MeasureSpec.UNSPECIFIED);
	    pwMyPopWindow.setWidth(lvPopupList.getMeasuredWidth());
	    pwMyPopWindow.setHeight((lvPopupList.getMeasuredHeight() + 20)*NUM_OF_VISIBLE_LIST_ROWS);
	   //控制popupwindow点击屏幕其他地方消失
	    pwMyPopWindow.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.bg_popupwindow));
	    pwMyPopWindow.setOutsideTouchable(true);
	}

	private void initData() {
		//年份设置
		moreListYear = new ArrayList<Map<String,String>>();
		Map<String,String> mapYear;
		mapYear = new HashMap<String, String>();
		mapYear.put("year_key", "请选择年份");
		moreListYear.add(mapYear);
		for (int i = 0; i < 3; i++) {
			mapYear = new HashMap<String , String>();
			mapYear.put("year_key", String.valueOf(2014+i)+" 年");
			moreListYear.add(mapYear);
		}
		
		//月份设置
		moreListMonth = new ArrayList<Map<String,String>>();
		Map<String, String> mapMonth ;
		mapMonth = new HashMap<String,String>();
		mapMonth.put("month_key", "请选择月份");
		moreListMonth.add(mapMonth);
		for (int i = 0; i < 12; i++) {
			mapMonth = new HashMap<String,String>();
			mapMonth.put("month_key", String.valueOf(1+i)+" 月");
			moreListMonth.add(mapMonth);
		}
	}

	private void initView() {
		date_tv = (EditText) findViewById(R.id.warn_date_tv);
        time_tv = (EditText) findViewById(R.id.warn_time_tv);
        qy_tv = (EditText) findViewById(R.id.warn_qy_tv);
        search_tv = (TextView) findViewById(R.id.warn_search_tv);
        warn_date_img = (ImageView) findViewById(R.id.warn_date_img);
        warn_time_img = (ImageView) findViewById(R.id.warn_time_img);
        warn_date_img.setOnClickListener(this);
        warn_time_img.setOnClickListener(this);
		search_tv.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				    date = date_tv.getText().toString().trim();
					time = time_tv.getText().toString().trim();
					compname = qy_tv.getText().toString().trim();
				if(!BeanUtils.isEmpty(date)||!BeanUtils.isEmpty(time)||!BeanUtils.isEmpty(compname)){
					System.out.println(" 年份 "+date+" 月份 "+time+" 公司 "+compname);
					if(null !=mAdapter){
						warningInfos.clear();
						loadData();
						mAdapter.notifyDataSetChanged();
					}
				}else {
					warningInfos.clear();
					invoke.invoke(OAInterface.getWaringInfo("", "", "", "1"),
							callBack);
					mAdapter.notifyDataSetChanged();
				}
			}
		});
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			if (!BeanUtils.isEmpty(response)) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
				if (Constants.SUCCESS_CODE.equals(item.get("code"))) {
					List<ResultItem> items = item.getItems("data");
					for (ResultItem resultItem : items) {
						WarningInfo warInfo = new WarningInfo();
						warInfo.setCompanyName(resultItem
								.getString("COMPANY_NAME"));
						warInfo.setIndNow(resultItem.getString("GYCZ_P"));

						warInfo.setBusNow(resultItem.getString("ZYYWSR_P"));
						warInfo.setTax(resultItem.getString("LSZE_P"));
						warInfo.setProfit(resultItem.getString("LR_P"));
						warInfo.setYear(resultItem.getString("YEARS"));
						warInfo.setMonth(resultItem.getString("MONTHS_"));
						System.out.println("年"+resultItem.getString("YEARS")+"月"+resultItem.getString("MONTHS_"));
						warningInfos.add(warInfo);
						if (null == mAdapter) {
							mAdapter = new WarningAdapter(
									EnterpriseWarningActivity.this,
									 warningInfos);
							lv_warning.setAdapter(mAdapter);
						} else {
							mAdapter.notifyDataSetChanged();
						}
					}
				  }
				}
			}
		}
	};
	
	public void loadData() {
		if(BeanUtils.isEmpty(compname)&&BeanUtils.isEmpty(date)&&BeanUtils.isEmpty(time)){
			invoke.invoke(OAInterface.getWaringInfo("", "", "", "1"),
					callBack);
		}else if(!BeanUtils.isEmpty(date)&&!BeanUtils.isEmpty(time)&&BeanUtils.isEmpty(compname)){
			invoke.invoke(OAInterface.getWaringInfo("", date, time, "1"),
					callBack);
		}else if(!BeanUtils.isEmpty(date)&&BeanUtils.isEmpty(compname)){
			invoke.invoke(OAInterface.getWaringInfo("", date, "", "1"),
					callBack);
		}else if(!BeanUtils.isEmpty(time)&&BeanUtils.isEmpty(date)&&BeanUtils.isEmpty(compname)){
			invoke.invoke(OAInterface.getWaringInfo("", "", time, "1"),
					callBack);
		}else if(!BeanUtils.isEmpty(compname)){
			invoke.invoke(OAInterface.getWaringInfo(compname, "", "", "1"),
					callBack);
		}
	}

	@Override
	public void onClick(View v) {
		int id = v.getId();
		switch (id) {
		
		case R.id.warn_date_img:
			      if (pwMyPopWindow.isShowing()) {
			    	  pwMyPopWindow.dismiss();
			      } else {
			    	  int xPos = (-pwMyPopWindow.getWidth() / 2)-(date_tv.getWidth() / 3);
			    	  pwMyPopWindow.showAsDropDown(warn_date_img, xPos, 10);
			      }
			break;

		case R.id.warn_time_img:
			
		      if (pwMyPopWindowMonth.isShowing()) {
		    	  pwMyPopWindowMonth.dismiss();
		      } else {
		          int xPosMonth = (-pwMyPopWindowMonth.getWidth() / 2 )-(time_tv.getWidth() / 3);  
		    	  pwMyPopWindowMonth.showAsDropDown(warn_time_img,xPosMonth,10);
		      }
		      break;
		      
		case R.id.system_back:
			finish();
			break;
		default:
			break;
		}
	}
}
