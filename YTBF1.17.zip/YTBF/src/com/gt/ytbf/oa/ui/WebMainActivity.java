package com.gt.ytbf.oa.ui;

import cn.jpush.android.api.InstrumentedActivity;
import cn.jpush.android.api.JPushInterface;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.R.id;
import com.gt.ytbf.oa.R.layout;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebSettings.TextSize;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class WebMainActivity extends InstrumentedActivity {

	
	
	private WebView mWebView;
	
	static final String isFirstLoad = "IS_FIRST_LOAD";
	private AlertDialog mDialog;
	static final String LOGIN_URL = "http://218.17.204.4:8889/platform/enterprise/login.jsp";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.web_activity_main);
		mWebView = (WebView) findViewById(R.id.webView);
		JPushInterface.init(this);
		if (isNetworkConnected(this)
				|| !getPreferences(MODE_PRIVATE).getBoolean(isFirstLoad, true)) {
			load();
		} else {
			showDialog();
		}
	}

	private void showDialog() {
		AlertDialog.Builder builder = new Builder(this);
		builder.setMessage("当前网络不可用，请检查网络");
		builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mDialog.dismiss();
				boolean firstLoad = getPreferences(MODE_PRIVATE).getBoolean(isFirstLoad, true);
				if (firstLoad) {
					finish();
					return;
				}
//				if (mWebView.canGoBack()) {
//					mWebView.goBack();
//				}
			}
		});
		mDialog = builder.create();
		mDialog.show();
	}
	private void load() {
		// 设置WebViewClient
		WebSettings webSetting = mWebView.getSettings(); 
		webSetting.setAppCacheMaxSize(1024*1024*32);//设置缓冲大小，我设的是8M 
		String appCacheDir = this.getApplicationContext().getDir("cache", Context.MODE_PRIVATE).getPath(); 
		webSetting.setAppCachePath(appCacheDir); 
//		webSetting.setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webSetting.setAllowFileAccess(true); 
		webSetting.setAppCacheEnabled(true); 
		webSetting.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); 
		webSetting.setJavaScriptEnabled(true);
		webSetting.setDomStorageEnabled(true);
//		webSetting.setDefaultFontSize(16);
		
		mWebView.setWebViewClient(new WebViewClient() {
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				if (!isNetworkConnected(WebMainActivity.this)) {
//					showDialog();
					return false;
				}
				view.loadUrl(url);
				if (LOGIN_URL.equals(url)) {
					getPreferences(MODE_PRIVATE).edit().putBoolean(isFirstLoad, false).commit();
				}
				return true;
			}

			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
			}

//			public void onPageStarted(WebView view, String url, Bitmap favicon) {
//				super.onPageStarted(view, url, favicon);
//				if (!isNetworkConnected(MainActivity.this)) {
//					showDialog();
//					return;
//				}
//				view.loadUrl(url);
//				if (LOGIN_URL.equals(url)) {
//					getPreferences(MODE_PRIVATE).edit().putBoolean(isFirstLoad, false).commit();
//				}
//			}
			
			@Override
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (!isNetworkConnected(WebMainActivity.this)) {
					Toast.makeText(WebMainActivity.this, "网络连接失败，请检查网络", Toast.LENGTH_SHORT).show();
				}
			}
		});
		mWebView.loadUrl(LOGIN_URL);
	}
	
//	private class MyWebViewClient extends WebViewClient {
//		public boolean shouldOverrideUrlLoading(WebView view, String url) {
//			if (Uri.parse(url).getHost().equals("www.example.com")) {
//				return false;
//			}
//			Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
//			startActivity(intent);
//			return true;
//		}
//	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
			mWebView.goBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	// 网络状态
	public boolean isNetworkConnected(Context context) {
			if (context != null) {
				ConnectivityManager mConnectivityManager = (ConnectivityManager) context
						.getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo mNetworkInfo = mConnectivityManager
						.getActiveNetworkInfo();
				if (mNetworkInfo != null) {
					return mNetworkInfo.isAvailable();
				}
			}
			return false;
	}
}
