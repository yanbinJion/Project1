package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.CountyIndustryInfo;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CountyAdatper extends BaseAdapter{
	
	private Context context;
	private List<CountyIndustryInfo> mData;
	private int type;
	public CountyAdatper(Context context, List<CountyIndustryInfo> mData, int pagetypeone) {
		this.context = context;
		this.mData = mData;
		this.type = pagetypeone;
	}

	@Override
	public int getCount() {
		return mData.size()==0?null:mData.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.activity_country_item,
					null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
//			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);
//			hodler.tv_table04 = (TextView) convertView.findViewById(R.id.tv_table04);
//			hodler.tv_table05 = (TextView) convertView.findViewById(R.id.tv_table05);
//			hodler.tv_table06 = (TextView) convertView.findViewById(R.id.tv_table06);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		
		if(1==type){
	    	 hodler.tv_table1.setText(mData.get(position).getZbmc());
//	    	 hodler.tv_table01.setText(mData.get(position).getZndmb());
			 hodler.tv_table01.setText(mData.get(position).getZwc());
//			 hodler.tv_table03.setText(mData.get(position).getZzllqspm());
			 hodler.tv_table02.setText(mData.get(position).getZtbzz());
//			 hodler.tv_table05.setText(mData.get(position).getZzflqspm());
//			 hodler.tv_table06.setText(mData.get(position).getZwcmbjd());
	       }else if(2==type){
	    	 //工业增量
	    	 hodler.tv_table1.setText(mData.get(position).getZbmc());
//	    	 hodler.tv_table01.setText(mData.get(position).getGndmb());
			 hodler.tv_table01.setText(mData.get(position).getGwc());
//		     hodler.tv_table03.setText(mData.get(position).getGzllqspm());
			 hodler.tv_table02.setText(mData.get(position).getGtbzz());
//			 hodler.tv_table05.setText(mData.get(position).getGzflqspm());
//			 hodler.tv_table06.setText(mData.get(position).getGwcmbjd());
	     }else{
	    	 //利税
	    	 hodler.tv_table1.setText(mData.get(position).getZbmc());
//	    	 hodler.tv_table01.setText(mData.get(position).getLndmb());
			 hodler.tv_table01.setText(mData.get(position).getLwc());
//			 hodler.tv_table03.setText(mData.get(position).getLzllqspm());
			 hodler.tv_table02.setText(mData.get(position).getLtbzz());
//			 hodler.tv_table05.setText(mData.get(position).getLzflqspm());
//			 hodler.tv_table06.setText(mData.get(position).getLwcmbjd());
	     }
	
		
		return convertView;
	}
	
	final class ViewHolder {
		TextView tv_table1, tv_table01, tv_table02, tv_table03, tv_table04, tv_table05,tv_table06;
	}
}
