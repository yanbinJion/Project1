package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.IndustryTargetInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class IndustryTargetActivity extends BaseActivity {

	public static final String[] ITTILES = new String[] { "主营业务", "工业增加值", "利税总额" };
	private ListView lv_target1,lv_target2,lv_target3;
	private LayoutInflater layoutInflater;
	private LinearLayout layout;
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	private CommenViewPagerHelper helper;
	private View mainBusView;
	private View addIndustryView;
	private View profitView;
	List<IndustryTargetInfo> mList = new ArrayList<IndustryTargetInfo>();
	private IndustryTargetAdapter mAdapterOne;
	private IndustryTargetAdapter mAdapterTwo;
	private IndustryTargetAdapter mAdapterThree;
	private InvokeHelper invoke;
	public static final int PAGETYPEONE = 1;
	public static final int PAGETYPETWO = 2;
	public static final int PAGETYPETHREE = 3;
	private TextView time1,time2,time3;
	private String time;
	private static final String TAG = "WholeCityElectricActivity";
	
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
			
		}	
	};		
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_common_tabpageindicator);
		initTitleBar(R.string.city_industry_titile, backListener, null);
		invoke = new InvokeHelper(this);
		loadData();
		initView();
		initViewPagers(savedInstanceState);
		
	}
	
	private void loadData() {
		invoke.invoke(OAInterface.getQueryStatistics("2", "", ""), callBack);
	}
	
	private void initViewPagers(Bundle savedInstanceState) {
		helper = new CommenViewPagerHelper(IndustryTargetActivity.this, layout);
		helper.onCreate(savedInstanceState);
		List<View> views = new ArrayList<View>();
		mainBusView = layoutInflater.inflate(R.layout.activity_industry_target, null);
		views.add(mainBusView);
		addIndustryView = layoutInflater.inflate(R.layout.activity_industry_target, null);
		views.add(addIndustryView);
		profitView = layoutInflater.inflate(R.layout.activity_industry_target, null);
		views.add(profitView);
		
		for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));
		}
        helper.showViews(mListDatas);
        loadView();
	}
	
	private void loadView() {
		lv_target1 = (ListView)mainBusView.findViewById(R.id.lv_target);
		time1 = (TextView) mainBusView.findViewById(R.id.time);
		lv_target2 = (ListView)addIndustryView.findViewById(R.id.lv_target);
		time2 = (TextView) addIndustryView.findViewById(R.id.time);
		lv_target3 = (ListView)profitView.findViewById(R.id.lv_target);
		time3 = (TextView) profitView.findViewById(R.id.time);
	}
	
	private void initView() {
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.viewpage);
	}
	
	private  IRequestCallBack callBack = new BaseRequestCallBack(){
		 
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
					if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("DATA");
						for (ResultItem resultItem : items) {
							IndustryTargetInfo tgInfo = new IndustryTargetInfo();
							time = resultItem.getString("YF");
							tgInfo.setCompany(resultItem.getString("ZBMC"));
							//主营业务
							tgInfo.setMonthData(resultItem.getString("ZYYWSR_BYLJ"));
							tgInfo.setSortOne(resultItem.getString("ZYYWSR_BYLJ_PX"));
							tgInfo.setAddPercent(resultItem.getString("ZYYWSR_TB"));
							tgInfo.setSortTwo(resultItem.getString("ZYYWSR_TB_PX"));
							tgInfo.setCompletePlan(resultItem.getString("ZYYWSR_WCMBJD"));
							//工业增加值
							tgInfo.setgMonthData(resultItem.getString("GYZJZ_BYLJ"));
							tgInfo.setgSortOne(resultItem.getString("GYZJZ_BYLJ_PX"));
							tgInfo.setgAddPercent(resultItem.getString("GYZJZ_TB"));
							tgInfo.setgSortTwo(resultItem.getString("GYZJZ_TB_PX"));
							tgInfo.setgCompletePlan(resultItem.getString("GYZJZ_WCMBJD"));
							//利税总额
							tgInfo.setlMonthData(resultItem.getString("LSZE_BYLJ"));
							tgInfo.setlSortOne(resultItem.getString("LSZE_BYLJ_PX"));
							tgInfo.setlAddPercent(resultItem.getString("LSZE_TB"));
							tgInfo.setlSortTwo(resultItem.getString("LSZE_TB_PX"));
							tgInfo.setlCompletePlan(resultItem.getString("LSZE_WCMBJD"));
							char[] array = time.toCharArray();
							if(array[0]=='0'){
								time1.setText("区间:1-"+array[1]+"月");
								time2.setText("区间:1-"+array[1]+"月");
								time3.setText("区间:1-"+array[1]+"月");
							}else{
								time1.setText("区间:1-"+time+"月");
								time2.setText("区间:1-"+time+"月");
								time3.setText("区间:1-"+time+"月");
							}
							mList.add(tgInfo);
							if(mAdapterOne==null){
								mAdapterOne = new IndustryTargetAdapter(IndustryTargetActivity.this, mList,PAGETYPEONE);
								lv_target1.setAdapter(mAdapterOne);
							}else{
								mAdapterOne.notifyDataSetChanged();
							}
							if(mAdapterTwo==null){
								mAdapterTwo = new IndustryTargetAdapter(IndustryTargetActivity.this, mList,PAGETYPETWO);
								lv_target2.setAdapter(mAdapterTwo);
							}else{
								mAdapterTwo.notifyDataSetChanged();
							}
							if(mAdapterThree==null){
								mAdapterThree = new IndustryTargetAdapter(IndustryTargetActivity.this, mList,PAGETYPETHREE);
								lv_target3.setAdapter(mAdapterThree);
							}else{
								mAdapterThree.notifyDataSetChanged();
							}
						}
					}
				}
			}
		}
     };
}
