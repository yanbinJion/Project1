package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class EconomicIndicatorAdapter extends BaseAdapter {

	private Context context;
	private List<String> list;

	public EconomicIndicatorAdapter(Context context, List<String> list) {
		this.context = context;
		this.list = list;
	}

	@Override
	public int getCount() {
		return list ==null ? 0 :list.size();
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if(convertView == null){
			holder = new ViewHolder();
			convertView= View.inflate(context,R.layout.activity_indicator_list, null);
			holder.econ_indicator_img = (ImageView) convertView.findViewById(R.id.econ_indicator_img);
			holder.econ_indicator_tv = (TextView) convertView.findViewById(R.id.econ_indicator_tv);
			convertView.setTag(holder);
		}else{
			 holder = (ViewHolder) convertView.getTag();
		}
		holder.econ_indicator_img.setImageResource(R.drawable.economy_icon_06);
		holder.econ_indicator_tv.setText(list.get(position));
		return convertView;
	}

	class ViewHolder{
		private ImageView econ_indicator_img;
		private TextView econ_indicator_tv;
	}
}
