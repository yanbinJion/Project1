package com.gt.ytbf.oa.ui.view;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OnSelectedChangeListener;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;

public class SegmentButton extends LinearLayout implements OnClickListener{
	
	private TextView tvLeft;
	private TextView tvMid;
	private TextView tvRight;
	private boolean isLeftSelected;
	private boolean isMidSelected;
	private OnSelectedChangeListener onSelectedChangeListener;;
	
	public OnSelectedChangeListener getOnSelectedChangeListener() {
		return onSelectedChangeListener;
	}

	public void setOnSelectedChangeListener(OnSelectedChangeListener onSelectedChangeListener){
		
		this.onSelectedChangeListener =	onSelectedChangeListener;	
	}
	
	public SegmentButton(Context context, AttributeSet attrs) {
		super(context, attrs);
		View.inflate(context, R.layout.view_segment_button, this);
		tvLeft = (TextView) findViewById(R.id.tv_left);
		tvMid = (TextView) findViewById(R.id.tv_mid);
		tvRight = (TextView) findViewById(R.id.tv_right);
		
		TypedArray typedArray = context.obtainStyledAttributes(attrs,R.styleable.SegmentButton);
		String leftString = typedArray.getString(R.styleable.SegmentButton_leftText);
		String midString = typedArray.getString(R.styleable.SegmentButton_midText);
		String rightString = typedArray.getString(R.styleable.SegmentButton_rightText);
		typedArray.recycle();
		
		tvLeft.setText(leftString);
		tvMid.setText(midString);
		tvRight.setText(rightString);
		
		tvLeft.setOnClickListener(this);
		tvMid.setOnClickListener(this);
		tvRight.setOnClickListener(this);
		
		setSelected(true);
	}

	public boolean isSelected() {
		
		return true;		
	}
	
	public void setSelected(boolean isSelected){
		if (isLeftSelected) {
			tvLeft.setSelected(true);
			tvMid.setSelected(false);
			tvRight.setSelected(false);
		}else if (isMidSelected) {
			tvLeft.setSelected(false);
			tvMid.setSelected(true);
			tvRight.setSelected(false);
		}else {
			tvLeft.setSelected(false);
			tvMid.setSelected(false);
			tvRight.setSelected(true);
		}
		//this.isLeftSelected = isLeftSelected;
		
		if (onSelectedChangeListener!=null) {
			onSelectedChangeListener.onSelectedChange(isLeftSelected);
		}
	}
	
	@Override
	public void onClick(View v) {
		if (v.getId()==R.id.tv_left) {
			setSelected(true);
		}else if (v.getId()==R.id.tv_right) {
			setSelected(false);
		}else if (v.getId()==R.id.tv_mid) {
			setSelected(false);
		}
		
	}

	
}
