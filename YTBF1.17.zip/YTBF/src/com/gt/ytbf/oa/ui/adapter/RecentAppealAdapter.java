package com.gt.ytbf.oa.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.model.AppealCenterModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by root on 16-6-20.
 */
public class RecentAppealAdapter extends BaseAdapter {

    private Context mContext;
    private List<AppealCenterModel> mData;

    public RecentAppealAdapter(Context context, List<AppealCenterModel> data) {
        mContext = context;
        mData = new ArrayList<AppealCenterModel>();
        setData(data);
    }

    public void setData(List<AppealCenterModel> data) {
        if (null != data) {
            mData.clear();
            mData.addAll(data);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return mData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        AppealCenterModel model = mData.get(i);
        ViewHolder holder = null;
        if (null == view) {
            view = LayoutInflater.from(mContext).inflate(R.layout.appeal_recent_list_item, null);
            holder = new ViewHolder();
            holder.tv_appeal_type = (TextView) view.findViewById(R.id.tv_appeal_type);
            holder.tv_appeal_content = (TextView) view.findViewById(R.id.tv_appeal_content);
            holder.tv_appeal_state = (TextView) view.findViewById(R.id.tv_appeal_state);
            holder.tv_appeal_time = (TextView) view.findViewById(R.id.tv_appeal_time);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.tv_appeal_content.setText(model.getAppealContent());
        holder.tv_appeal_state.setText(model.getStatusType());
        holder.tv_appeal_time.setText(model.getAppealTime());
        holder.tv_appeal_type.setText(model.getAppealType());
        return view;
    }

    class ViewHolder {
        public TextView tv_appeal_type;
        public TextView tv_appeal_content;
        public TextView tv_appeal_state;
        public TextView tv_appeal_time;
    }
}
