package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.bean.NewsInfo;
import com.gt.ytbf.oa.bean.RollItem;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.NewsListAdapter;
import com.gt.ytbf.oa.ui.view.AutoRollLayout;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase.OnRefreshListener;

public class PolicyNewsActivity extends BaseActivity implements OnClickListener{

	private final int NEWS_PAGER = 1;
	private final int DOCUMENT_PAGER = 2;
	private final int FINANCE_PAGER = 4;
    private AutoRollLayout mAutoRollLayout;
    private List<NewsInfo> policyInfos = new ArrayList<NewsInfo>();
    //private SegmentButton sbNews;
    private TextView tvLeft;
	private TextView tvMid;
	private TextView tvRight;
	private PullToRefreshListView pullListView;
	private List<NewsInfo> newsInfos = new ArrayList<NewsInfo>();
	private List<NewsInfo> financeInfos = new ArrayList<NewsInfo>();
	private NewsListAdapter newsListAdapter;
	private ListView mListView;
	private int pagerIndex = NEWS_PAGER;
	private int index = 1;
	private int newsIndex = 1;
	private int financeIndex = 1;

    private View.OnClickListener backListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_news);
        initTitleBar(R.string.tab_news_title, null, null);
        setMainNavigator();
		initView();
		loadData(1);
    }

    private void initView() {    	
    	mAutoRollLayout = (AutoRollLayout) findViewById(R.id.autorolllayout);
    	tvLeft = (TextView) findViewById(R.id.tv_left);
    	tvMid = (TextView) findViewById(R.id.tv_mid);
    	tvRight = (TextView) findViewById(R.id.tv_right);
    	pullListView = (PullToRefreshListView) findViewById(R.id.news__pull_lv);
    	mListView = setProperty(pullListView);
    	
    	tvLeft.setOnClickListener(this);
    	tvMid.setOnClickListener(this);
    	tvRight.setOnClickListener(this);
    	/*sbNews.setOnSelectedChangeListener(new OnSelectedChangeListener() {
			
			@Override
			public void onSelectedChange(boolean isLeftSelected) {
				
				if (isLeftSelected) {
					pagerIndex = NEWS_PAGER;
				}else {
					pagerIndex = DOCUMENT_PAGER;
				}
				if (pagerIndex == NEWS_PAGER && newsInfos.size() == 0) {
					loadData(newsIndex);
				} else if (policyInfos.size() == 0) {
					loadData(index);
				} else {
					updateList();
				}
			}
		});*/
//    	List<RollItem> rollItemList=new ArrayList<RollItem>();
//        rollItemList.add(new RollItem("张晓明赴鹰潭开展“降低企业成本、优化发展环境”专项行动政策宣讲和调研",R.drawable.news_01));
//        rollItemList.add(new RollItem("张晓明赴鹰潭开展“降低企业成本、优化发展环境”专项行动政策宣讲和调研",R.drawable.news_02));
//        rollItemList.add(new RollItem("洪礼和赴挂点联系园区调研并作政策宣讲动员", R.drawable.news_03));
//        mAutoRollLayout.setData(rollItemList);
    	MainActivity.getInstance().setRollLayout(mAutoRollLayout);
        tvLeft.setSelected(true);
		tvMid.setSelected(false);
		tvRight.setSelected(false);
	}
		    
    @Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tv_left:
			tvLeft.setSelected(true);
			tvMid.setSelected(false);
			tvRight.setSelected(false);
			pagerIndex = NEWS_PAGER;
			if (newsInfos.size() == 0) {
				loadData(newsIndex);
			}else {
				updateList();
			}
			break;
		case R.id.tv_mid:
			tvLeft.setSelected(false);
			tvMid.setSelected(true);
			tvRight.setSelected(false);
			pagerIndex = DOCUMENT_PAGER;
			if (policyInfos.size() == 0) {
				loadData(index);
			}else {
				updateList();
			}
			break;
		case R.id.tv_right:
			tvLeft.setSelected(false);
			tvMid.setSelected(false);
			tvRight.setSelected(true);
			pagerIndex = FINANCE_PAGER;
			if (financeInfos.size() == 0) {
				loadData(financeIndex);
			}else {
				updateList();
			}
			break;
		default:
			break;
		}
		
	}
    
    private ListView setProperty(PullToRefreshListView pTListView) {
		pTListView.setPullRefreshEnabled(true);
		pTListView.setPullLoadEnabled(true);
        ListView myAppealList = pTListView.getRefreshableView();
        myAppealList.setCacheColorHint(Color.TRANSPARENT);
        myAppealList.setFadingEdgeLength(0);
        myAppealList.setSelector(android.R.color.transparent);
		return myAppealList;
	}
    
    private void updateList() {
    	if (null == newsListAdapter) {
    		newsListAdapter = new NewsListAdapter(this);
    		mListView.setAdapter(newsListAdapter);
    		mListView.setOnItemClickListener(new OnItemClickListener() {
    			
				private Intent intent;
				
				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					if (pagerIndex==NEWS_PAGER) {						
						intent = new Intent(PolicyNewsActivity.this, NewsDetailActivity.class);	
						intent.putExtra("id", newsInfos.get(position).getId());	
						intent.putExtra("title", newsInfos.get(position).getNewsTitle());
					} else if(pagerIndex==DOCUMENT_PAGER){
						intent = new Intent(PolicyNewsActivity.this, NewsDetailActivity.class);	
						intent.putExtra("id", policyInfos.get(position).getId());	
						intent.putExtra("title", policyInfos.get(position).getNewsTitle());
					} else if(pagerIndex==FINANCE_PAGER){
						intent = new Intent(PolicyNewsActivity.this, NewsDetailActivity.class);	
						intent.putExtra("id", financeInfos.get(position).getId());	
						intent.putExtra("title", financeInfos.get(position).getNewsTitle());
					}
		            startActivity(intent);
		            
				}
			});
    		
    		pullListView.setOnRefreshListener(new OnRefreshListener<ListView>() {
    			// 上拉刷新数据
				@Override
				public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
					Toast.makeText(PolicyNewsActivity.this, "刷新成功", Toast.LENGTH_SHORT).show();
					if (pagerIndex == NEWS_PAGER) {
						newsIndex=1;
						newsInfos.clear();
						loadData(newsIndex);
			            pullListView.onPullDownRefreshComplete();
					} else if (pagerIndex == DOCUMENT_PAGER) {
						index = 1;
						policyInfos.clear();
						loadData(index);
			            pullListView.onPullDownRefreshComplete();
					} else if (pagerIndex == FINANCE_PAGER) {
						financeIndex = 1;
						financeInfos.clear();
						loadData(financeIndex);
			            pullListView.onPullDownRefreshComplete();
					}
				}
				// 下拉加载下一页的数据
				@Override
				public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
					if (pagerIndex == NEWS_PAGER) {
						loadData(++newsIndex);
			            pullListView.onPullUpRefreshComplete();
					} else if (pagerIndex == DOCUMENT_PAGER) {
						loadData(++index);
			            pullListView.onPullUpRefreshComplete();
					} else if (pagerIndex == FINANCE_PAGER) {
						loadData(++financeIndex);
			            pullListView.onPullUpRefreshComplete();
					}
				}
			});
    		newsListAdapter.setData(newsInfos);
    	} else {
    		if (pagerIndex == NEWS_PAGER) {
    			newsListAdapter.setData(newsInfos);
    		} else if (pagerIndex == DOCUMENT_PAGER) {
    			newsListAdapter.setData(policyInfos);
    		} else if (pagerIndex == FINANCE_PAGER) {
    			newsListAdapter.setData(financeInfos);
    		}
    	}
    }
    
	private IRequestCallBack callBack= new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.get("code"))) {
					List<ResultItem> resultItems = item.getItems("data");
					if (BeanUtils.isEmpty(resultItems)) {
						return;
					}
					List<RollItem> rollList = new ArrayList<RollItem>();
					boolean isRefresh = false;
					for (ResultItem resultItem : resultItems) {
						String title=resultItem.getString("TITLE");
						String ctime=resultItem.getString("CTIME");
						String id = resultItem.getString("ID");
						String type = resultItem.getString("DESTYPE");
						String imgUrl = resultItem.getString("IMG");
						if (pagerIndex == NEWS_PAGER) {
							NewsInfo info = new NewsInfo(id, R.drawable.news_list_01,title, ctime, type);
							info.setImgUrl(imgUrl);
							newsInfos.add(info);
							if (rollList.size() >= 3) {
								if (!isRefresh) {
									MainActivity.getInstance().updateRolls(rollList);
									isRefresh = true;
								}
							} else {
								if (!BeanUtils.isNullOrEmpty(imgUrl)) {
									rollList.add(new RollItem(id, title, imgUrl));
								}
							}
						} else if (pagerIndex == DOCUMENT_PAGER) {
							String tempType = resultItem.getString("TYPE");
							int res = R.drawable.two_icon_provincia;
					        if ("5".equals(tempType)) {
					        	res = R.drawable.two_icon_country;
							} else if ("7".equals(tempType)) {
								res = R.drawable.two_icon_city;
							}
							policyInfos.add(new NewsInfo(id, res, title, ctime, type));
						} else if (pagerIndex == FINANCE_PAGER) {
							financeInfos.add(new NewsInfo(id, R.drawable.two_icon_finance,title, ctime, type));
						}
					}
					updateList();
				}
			}
									
		}
	};
	
	private void loadData(int index) {
        helper.invoke(OAInterface.getNewsList(String.valueOf(pagerIndex), String.valueOf(index)),callBack);
    }	

	@Override
	public void onBackPressed() {
		MainActivity.getInstance().onBackPressed();
	}

	
	

}
