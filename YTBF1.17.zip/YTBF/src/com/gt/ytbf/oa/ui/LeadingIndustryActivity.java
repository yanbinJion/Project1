package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.bean.LeadingIndustryInfo;
import com.gt.ytbf.oa.ui.adapter.LeadingIndustryAdapter;

public class LeadingIndustryActivity extends BaseActivity {

	private ListView lv_leading_industy;
    private List<LeadingIndustryInfo> leadingIndustryInfos = new ArrayList<LeadingIndustryInfo>();
    private static final String TAG = "LeadingIndustryActivity";
    private static LeadingIndustryActivity mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_leading_industry);
        initView();
        initData();
        getData();
    }
     
    private void initView() {
        lv_leading_industy = (ListView) findViewById(R.id.lv_leading_industy);
    }
    
    private void initData() {
		LeadingIndustryAdapter adapter = new LeadingIndustryAdapter(LeadingIndustryActivity.this, leadingIndustryInfos);
		lv_leading_industy.setAdapter(adapter);
		lv_leading_industy.setOnItemClickListener( new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
						Intent intent = new Intent (LeadingIndustryActivity.this,LeadingIndustryDetailActivity.class);
						intent.putExtra("type", leadingIndustryInfos.get(position).getType());
						intent.putExtra("title", leadingIndustryInfos.get(position).getTitle());
						startActivity(intent);
			}
		});
    }
	
    private void getData() {
    	int index = 13;
    	leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product01, "铜产业", "绿色世界铜都 中国铜产业基地", String.valueOf(index)));
        leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product02, "智能制造产业", "绿色水工 智能硬件", String.valueOf(++index)));
        leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product03, "光电新能源产业", "节能照明 眼镜制造 新能源", String.valueOf(++index)));
        leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product04, "大健康产业", "生物医药 食品加工", String.valueOf(++index)));
        leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product05, "创意制造产业", "雕刻之乡", String.valueOf(++index)));
        leadingIndustryInfos.add(new LeadingIndustryInfo(R.drawable.lending_product06, "精细化工产业", "硫磷化工基地", String.valueOf(++index)));
    }
    
  public static void finishMySelf() {
		mContext.finish();
 	}
}
