package com.gt.ytbf.oa.ui.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.ui.MainActivity;
import com.gt.ytbf.oa.ui.view.FloatManager.OnSwitchListener;

public class SwitchView extends LinearLayout implements OnClickListener {

	public static int viewWidth;
	public static int viewHeight;
	private Context mContext;
	private TextView switchTxt;
	private OnSwitchListener mListener;
	
	public SwitchView(Context context, OnSwitchListener listener) {
		super(context);
		mListener = listener;
		mContext = context;
		LayoutInflater.from(context).inflate(R.layout.switch_float_view, this);
		View view = findViewById(R.id.switch_float_lay);
		viewWidth = view.getLayoutParams().width;
		viewHeight = view.getLayoutParams().height;
		switchTxt = (TextView) findViewById(R.id.switch_user_txt);
		TextView backTxt = (TextView) findViewById(R.id.switch_back_txt);
		switchTxt.setOnClickListener(this);
		backTxt.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.switch_user_txt:
			UserInfo user = LoginUtils.getInstance().getUserInfo();
			user.setUserLevel("3".equals(user.getUserLevel()) ? "4" : "3");
			MainActivity.getInstance().setMainActivity();
			FloatManager.removeBigWindow(mContext);
			Toast.makeText(mContext, R.string.switch_user_success, Toast.LENGTH_SHORT).show();
			if (null != mListener) {
				mListener.onSwitchSuccess();
			}
			break;
		case R.id.switch_back_txt:
			FloatManager.removeBigWindow(mContext);
			break;
			default:
				break;
		}
	}
	
	public void showUserTips() {
		UserInfo user = LoginUtils.getInstance().getUserInfo();
		if (null != user) {
			if ("3".equals(user.getUserLevel())) {
				switchTxt.setText(R.string.user_level_to_4);
			} else if ("4".equals(user.getUserLevel())) {
				switchTxt.setText(R.string.user_level_to_3);
			}
		}
	}

}
