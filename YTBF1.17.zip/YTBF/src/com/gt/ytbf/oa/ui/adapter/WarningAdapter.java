package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.ViewHolderAdapter;
import com.gt.ytbf.oa.bean.WarningInfo;
import com.gt.ytbf.oa.tools.BeanUtils;

public class WarningAdapter extends ViewHolderAdapter<WarningInfo, WarningAdapter.ViewHolder> {

	private Float proFit;
	private Float tax;
	private Float indNow ;
	private Float busNow;
	
	public WarningAdapter(Context context, List<WarningInfo> listData) {
		super(context, listData);
	}

	@Override
	public View buildConvertView(LayoutInflater layoutInflater, WarningInfo t,
			int position) {
		return inflate(R.layout.warning_item);
	}

	@Override
	public ViewHolder buildViewHolder(View convertView, WarningInfo t,
			int position) {
		ViewHolder holder = new ViewHolder();
		holder.warn_img_ind=(ImageView)convertView.findViewById(R.id.warn_img_ind);
		holder.warn_img_bus=(ImageView)convertView.findViewById(R.id.warn_img_bus);
		holder.warn_img_tax=(ImageView)convertView.findViewById(R.id.warn_img_tax);
		holder.warn_img_profit=(ImageView)convertView.findViewById(R.id.warn_img_profit);
		holder.tv_companyName = (TextView) convertView.findViewById(R.id.tv_company_name);
		return holder;
	}

	@Override
	public void bindViewDatas(ViewHolder holder,WarningInfo t, int position) {
		//System.out.println("工业总额 "+t.getIndNow()+" 主要业务"+t.getBusNow()+" 利税"+t.getTax()+" 利润"+t.getProfit());
		if(!BeanUtils.isEmpty(t.getIndNow())){
			if("扭亏转盈".equals(t.getIndNow())){
				holder.warn_img_ind.setImageResource(R.drawable.yellow_corners_icon);
			} else {
				indNow = Float.valueOf(t.getIndNow());
			} 
		}
		
		if(!BeanUtils.isEmpty(t.getBusNow())){
			if("扭亏转盈".equals(t.getBusNow())){
				holder.warn_img_bus.setImageResource(R.drawable.yellow_corners_icon);
			} else {
				busNow = Float.valueOf(t.getBusNow());
			} 
		}
		
		if(!BeanUtils.isEmpty(t.getTax())){
			if("扭亏转盈".equals(t.getTax())){
				holder.warn_img_tax.setImageResource(R.drawable.yellow_corners_icon);
			}else{
				tax = Float.valueOf(t.getTax());
			}
		}
		
		if(!BeanUtils.isEmpty(t.getProfit())){
			if("扭亏转盈".equals(t.getProfit())){
				holder.warn_img_profit.setImageResource(R.drawable.yellow_corners_icon);
			}else{
				proFit = Float.valueOf(t.getProfit());
			}
		}
		
		
 		if(indNow >=20.0f){
			holder.warn_img_ind.setImageResource(R.drawable.green_corners_icon);
		}else if(10.0f<= indNow &&  indNow<20.0f){
			holder.warn_img_ind.setImageResource(R.drawable.blue_corners_icon);
		}else if(0.0f<=indNow && indNow <10.0f){
			holder.warn_img_ind.setImageResource(R.drawable.yellow_corners_icon);
		}else if(-10.0f<=indNow && indNow <0.0f){
			holder.warn_img_ind.setImageResource(R.drawable.purple_corners_icon);
		}else {
			holder.warn_img_ind.setImageResource(R.drawable.red_corners_icon);
		}
 		
 		if(busNow >=20.0f){
			holder.warn_img_bus.setImageResource(R.drawable.green_corners_icon);
		}else if(10.0f<= busNow &&  busNow<20.0f){
			holder.warn_img_bus.setImageResource(R.drawable.blue_corners_icon);
		}else if(0.0f<=busNow && busNow <10.0f){
			holder.warn_img_bus.setImageResource(R.drawable.yellow_corners_icon);
		}else if(-10.0f<=busNow && busNow <0.0f){
			holder.warn_img_bus.setImageResource(R.drawable.purple_corners_icon);
		}else {
			holder.warn_img_bus.setImageResource(R.drawable.red_corners_icon);
		}
 		
 		if(tax >=20.0f){
			holder.warn_img_tax.setImageResource(R.drawable.green_corners_icon);
    	}else if(10.0f<= busNow &&  busNow<20.0f){
			holder.warn_img_tax.setImageResource(R.drawable.blue_corners_icon);
		}else if(0.0f<=busNow && busNow <10.0f){
			holder.warn_img_tax.setImageResource(R.drawable.yellow_corners_icon);
		}else if(-10.0f<=busNow && busNow <0.0f){
			holder.warn_img_tax.setImageResource(R.drawable.purple_corners_icon);
		}else {
			holder.warn_img_tax.setImageResource(R.drawable.red_corners_icon);
		}
 		
		if(proFit >=20.0f){
			holder.warn_img_profit.setImageResource(R.drawable.green_corners_icon);
		}else if(10.0f<= proFit &&  proFit<20.0f){
			holder.warn_img_profit.setImageResource(R.drawable.blue_corners_icon);
		}else if(0.0f<=proFit && proFit <10.0f){
			holder.warn_img_profit.setImageResource(R.drawable.yellow_corners_icon);
		}else if(-10.0f<=proFit && proFit <0.0f){
			holder.warn_img_profit.setImageResource(R.drawable.purple_corners_icon);
		}else {
			holder.warn_img_profit.setImageResource(R.drawable.red_corners_icon);
		}
		holder.tv_companyName.setText(t.getCompanyName());
	}
	
	class ViewHolder {
		private ImageView warn_img_ind;
		private ImageView warn_img_bus;
		private ImageView warn_img_tax;
		private ImageView warn_img_profit;
		private TextView tv_companyName;
	}
	
}
