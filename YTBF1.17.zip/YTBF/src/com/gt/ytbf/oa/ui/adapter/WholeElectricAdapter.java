package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.WholeElectricInfo;
import com.gt.ytbf.oa.ui.adapter.IndustryTargetAdapter.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class WholeElectricAdapter extends BaseAdapter{

	private Context context;
	private List<WholeElectricInfo> mList;
	public WholeElectricAdapter(Context context, List<WholeElectricInfo> mList) {
		this.context = context;
		this.mList = mList;
	}

	@Override
	public int getCount() {
		return mList.size();
	}
	
	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.activity_electric_item,
					null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		hodler.tv_table1.setText(mList.get(position).getName());
		hodler.tv_table01.setText(mList.get(position).getMonthTotal());
		hodler.tv_table02.setText(mList.get(position).getAddTotal());
		hodler.tv_table03.setText(mList.get(position).getCommonRise());
		
		return convertView;
	}
	final class ViewHolder {
		TextView tv_table1, tv_table01, tv_table02, tv_table03;
	}
	
}
