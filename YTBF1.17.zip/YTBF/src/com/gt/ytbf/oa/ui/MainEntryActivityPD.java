package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import android.R.integer;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.RollItem;
import com.gt.ytbf.oa.common.LoadDataListener;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AdInfo;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.AppealListUtil;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.StringUtils;
import com.gt.ytbf.oa.ui.adapter.AppealAdapter;
import com.gt.ytbf.oa.ui.adapter.FunctionAdapter;
import com.gt.ytbf.oa.ui.adapter.ViewPagerAdapter;
import com.gt.ytbf.oa.ui.view.AutoRollLayout;
import com.gt.ytbf.oa.ui.view.ImageViewPagerHelper;
import com.gt.ytbf.oa.ui.view.MyScrollView;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
import com.gt.ytbf.oa.ui.view.MyScrollView.OnScrollListener;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;
import com.gt.ytbf.oa.ui.view.NoScrollGridView;
import com.gt.ytbf.oa.ui.view.NoScrollListView;

/**
 * 首页
 * */
public class MainEntryActivityPD extends BaseActivity implements LoadDataListener{
	
	private final String TAG = "MainEntryActivity";
	private final String FIRST = "5";
    private final String SECOND = "6";
    private static final int FIRST_PAGE = 1;
    private static final int TYPE = 2;
    private static final int GET_WAITDISTRIBUTE=0;
	private static final int GET_DISTRIBUTED=1;
    private int firstIndex = 1;
	private int secondIndex = 1;
	private ViewPager viewPager;
	/**
	 * 图片轮播适配器
	 * */
	private ViewPagerAdapter adapter;
	/**
	 * 功能列表
	 * */
	private NoScrollGridView mGridView;
	/**
	 * 功能列表适配器
	 * */
	private FunctionAdapter mGridAdapter;
    private LinearLayout mTabLayout;
    private ImageViewPagerHelper viewHelper;
    private InvokeHelper invoke;
	/**
	 * 图片轮播资源
	 * */
	private List<AdInfo> list = new ArrayList<AdInfo>();

	/**
	 * 定时循环显示图片
	 * */
	
	private String[] strings;
	private int[] res;
	private List<View> views;
	private PullToRefreshListView waitDistributeView;
	private PullToRefreshListView distributedView;
	private AppealAdapter waitDistributeAdapter;
    private AppealAdapter distributedAdapter;
	
    
    
	private AutoRollLayout mAutoRollLayout;
	private int mTabLayoutTop;
	private LinearLayout linearlayout;
	private LinearLayout linearlayout_gone;
	private List<AppealCenterModel> temper;
    
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_entry);
		initTitleBar(R.string.tab_home_title, null, null);
        mTabLayout = (LinearLayout) findViewById(R.id.main_tab_layout);
        viewHelper = new ImageViewPagerHelper(this, mTabLayout);
        viewHelper.onCreate(savedInstanceState);
        setMainNavigator();
		initView();
	}
	
	private void initView() {
		
		mAutoRollLayout = (AutoRollLayout) findViewById(R.id.autorolllayout);
		MainActivity.getInstance().setRollLayout(mAutoRollLayout);
//		MyScrollView myScrollView = (MyScrollView) findViewById(R.id.myScrollView);
//		myScrollView.setOnScrollListener(this);
		linearlayout = (LinearLayout) findViewById(R.id.linearlayout);
		linearlayout_gone = (LinearLayout) findViewById(R.id.linearlayout_gone);
		
		View view0 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view1 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		View view4 = getLayoutInflater().inflate(R.layout.common_noscroll_list_view, null);
		
			strings = new String[] {"待派发", "已派发", "诉求中心"};
			res = new int[] {R.drawable.dpf_selector, R.drawable.ypf_selector, R.drawable.qyxx_selector};
			views = new ArrayList<View>();
			views.add(view0);
			views.add(view1);
			views.add(view4);
		
       
        waitDistributeView = (PullToRefreshListView) view0.findViewById(R.id.common_pullToRefresh_list);
        waitDistributeList = AppealListUtil.setProperty(waitDistributeView);
        waitDistributeView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            // 下拉刷新数据
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		firstIndex=1;
            		waitDistributes.clear();
            		getDatas(FIRST, firstIndex, callBack,GET_WAITDISTRIBUTE);
            	}else {
            		waitDistributeView.onPullDownRefreshComplete();
				}
            }

            // 上拉加载下一页的数据
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		firstIndex+=1;
            		getDatas(FIRST, firstIndex, callBack,GET_WAITDISTRIBUTE);
            	}else {
            		waitDistributeView.onPullUpRefreshComplete();
				}
            }
        });
        
        distributedView = (PullToRefreshListView) view1.findViewById(R.id.common_pullToRefresh_list);
        distributedList = AppealListUtil.setProperty(distributedView);
        distributedView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
            // 下拉刷新数据
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		secondIndex=1;
            		distributedes.clear();
            		getDatas(SECOND,secondIndex,callBack,GET_DISTRIBUTED);
            	}else {
            		distributedView.onPullDownRefreshComplete();
				}
            }

            // 上拉加载下一页的数据
            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
            	if (checkNetworkState()) {
            		secondIndex+=1;
            		getDatas(SECOND,secondIndex,callBack,GET_DISTRIBUTED);
            	}else {
            		distributedView.onPullUpRefreshComplete();
				}
            }
        });
        updateUI();
        
	}
	
	protected void getDatas(String index, int pageIndex,
			IRequestCallBack callBack,int what) {
		invoke.invokeWidthDialog(OAInterface.getAppeals(index, pageIndex),callBack,what);
	}
	private void updateUI() {
		//加载轮播图数据
//		 List<RollItem> rollItemList=new ArrayList<RollItem>();
//		 rollItemList.add(new RollItem("全市降低企业成本优化发展环境政策宣讲会召开",R.drawable.main_homebanner_01));
//		 rollItemList.add(new RollItem("洪礼和赴挂点联系园区调研并作政策宣讲动员",R.drawable.news_02));
//		 rollItemList.add(new RollItem("陈兴超到高新区调研", R.drawable.main_homebanner_03));
//		 mAutoRollLayout.setData(rollItemList);
		
		List<ImageViewPagerHelper.PagerModel> pages = new ArrayList<ImageViewPagerHelper.PagerModel>();
        for (int i = 0; i < strings.length; i++) {
            pages.add(viewHelper.new PagerModel(strings[i], res[i], views.get(i), null));
        }
        
        viewHelper.showViews(pages,TYPE);
		
	}	
		
	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
						ResultItem countItem = (ResultItem) item.get("lstCount");
						parserUnread(countItem);
						List<ResultItem> resultItems=item.getItems("data");
						if (what==GET_WAITDISTRIBUTE) {
							showWaitDistributeList(resultItems);
						}else if (what==GET_DISTRIBUTED) {
							showDistributedList(resultItems);
						}
					}
				}
					
		}
		
	};
	
	private void parserUnread(ResultItem item) {
		if (null != item) {
			String wait = item.getString("pdydpf");
			String distributed = item.getString("pdyypf");
			int[] count = {
					StringUtils.isNullOrEmpty(wait) ? 0 : Integer.valueOf(wait),
					StringUtils.isNullOrEmpty(distributed) ? 0 : Integer.valueOf(distributed)};
			viewHelper.updateText(count);
		}
	}
	
	private void loadDatas(int position) {
		invoke = new InvokeHelper(this);
		 if (0 == position) {
			 firstIndex=1;
			 if (!BeanUtils.isEmpty(waitDistributes)) {
				 waitDistributes.clear();
			 }
			 invoke.invoke(OAInterface.getAppeals(FIRST, FIRST_PAGE),callBack,GET_WAITDISTRIBUTE);
		 }else if (1 == position){
			 secondIndex=1;
			 if (!BeanUtils.isEmpty(distributedes)) {
				 distributedes.clear();
			 }
			 invoke.invoke(OAInterface.getAppeals(SECOND,FIRST_PAGE), callBack,GET_DISTRIBUTED);
		 } 
		 
	 }
	private List<AppealCenterModel> waitDistributes = new ArrayList<AppealCenterModel>();
	private List<AppealCenterModel> distributedes = new ArrayList<AppealCenterModel>();
	private ListView waitDistributeList;
	private ListView distributedList;
	//列表个数，默认为0
	private String firstSize="0";
	private String secondSize="0";
	
	protected void showWaitDistributeList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,waitDistributeView,firstIndex,firstSize);
			waitDistributeAdapter.setData(waitDistributes);
			return;
		}
		waitDistributes.addAll(AppealListUtil.getAppeal(resultItems));
		firstSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == waitDistributeAdapter) {
	        	waitDistributeAdapter = new AppealAdapter(this, waitDistributes);
	            waitDistributeList.setAdapter(waitDistributeAdapter);
	            waitDistributeList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (waitDistributes.size() <= position) {
							return;
						}
						Intent intent = new Intent(new Intent(MainEntryActivityPD.this,AppealCenterActivity.class));
						Bundle bundle = new Bundle();
						bundle.putSerializable("appealInfo", waitDistributes.get(position));
						bundle.putBoolean("isHandler", true);
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
	            
	        } else {
	        	waitDistributeAdapter.setData(waitDistributes);
	        }
		AppealListUtil.checkDatas(resultItems,waitDistributeView,firstIndex,firstSize);
	}

	protected void showDistributedList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			AppealListUtil.checkDatas(resultItems,distributedView,secondIndex,secondSize);
			distributedAdapter.setData(distributedes);
			return;
		}
		distributedes.addAll(AppealListUtil.getAppeal(resultItems));
		secondSize = resultItems.get(0).getString("ID_PR_ALL");
		if (null == distributedAdapter) {
	            distributedAdapter = new AppealAdapter(this, distributedes);
	            distributedList.setAdapter(distributedAdapter);
	            distributedList.setOnItemClickListener(new OnItemClickListener() {

					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (distributedes.size() <= position) {
							return;
						}
						Intent intent = new Intent(new Intent(MainEntryActivityPD.this,AppealCenterActivity.class));
						Bundle bundle = new Bundle();
						bundle.putSerializable("appealInfo", distributedes.get(position));
						intent.putExtras(bundle);
						startActivity(intent);
					}
				});
	            
	        } else {
	            distributedAdapter.setData(distributedes);
	        }
		AppealListUtil.checkDatas(resultItems,distributedView,secondIndex,secondSize);
	}

	@Override
	protected void onResume() {
		super.onResume();
		viewHelper.updateUI();
		loadDatas(viewHelper.getCurrentIndex());
	}
	
	@Override
	public void onBackPressed() {
		MainActivity.getInstance().onBackPressed();
	}

	@Override
	public void loadData(int position) {
		loadDatas(position);
	}
	
}
