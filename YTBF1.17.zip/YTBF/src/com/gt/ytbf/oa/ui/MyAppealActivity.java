package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.AppealTypeInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by root on 16-6-20.
 */
public class MyAppealActivity extends BaseActivity implements View.OnClickListener {

	
	private static String SAVE="10";
	private static String COMMIT="0";
    
    private Button saveBtn;
    private Button commitBtn;
	private List<AppealTypeInfo> typeList;
	private String appealType;
	private EditText et_appeal_title;
	private EditText et_appeal_content;
	private InvokeHelper invoke;
	private List<String> types;
	private TextView tv_company_name;
	private TextView tv_appeal_name;
	private TextView tv_appeal_phone;
	private TextView tv_appeal_place;
	private Spinner spinner_type;
	private RadioButton cb_no ,cb_yes;
	private int status = 0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_appeal);
        initTitleBar(R.string.my_appeal_title, this, null);
        
        initData();
        initView();
    }
    private void sendData(String status,String title,String content,String appealType,String flag){
    	
    	invoke.invokeWidthDialog(OAInterface.saveOrSubmitAppeal(status, title, content,  appealType,flag), null);
    }
    
    private IRequestCallBack callBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
				ResultItem item = response.getResultItem(ResultItem.class);
				if (checkResult(item)) {
					if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
						List<ResultItem> resultItems=item.getItems("data");
						loadAppealTypes(resultItems);
					}
				}
		}
	};
	private IRequestCallBack myAppealBack = new BaseRequestCallBack() {
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
						item=item.getItems("data").get(0);
						String companyName = item.getString("COMPANY_NAME");
						String contact=item.getString("CONTACT");
						String contactPhone=item.getString("CONTACT_PHONE");
						String areas=item.getString("AREAS");
						tv_company_name.setText(companyName);
			        	tv_appeal_name.setText(contact);
			        	tv_appeal_phone.setText(contactPhone);
			        	tv_appeal_place.setText(areas);
				}
			}
		}
	};
	
    private void initData() {
    	invoke = new InvokeHelper(this);
    	invoke.invokeWidthDialog(OAInterface.myAppeal(), myAppealBack);
    	invoke.invokeWidthDialog(OAInterface.getAppealTypes(), callBack);
//		typeList = new ArrayList<String>();
//		typeList.add("请选择");
//		typeList.add("其他");
//		typeList.add("融资");
//		typeList.add("招工");
//		typeList.add("水、电、气");
//		typeList.add("环境");
//		typeList.add("物流");
//		typeList.add("生产配套");
//		typeList.add("共性平台");
//		typeList.add("技术需求");
		
	}

	protected void loadAppealTypes(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			return;
		}
		typeList = new ArrayList<AppealTypeInfo>(resultItems.size());
		types = new ArrayList<String>(resultItems.size());
		 for (ResultItem item : resultItems) {
			String id = item.getString("ID");
			String type = item.getString("NAME");
			types.add(type);
			typeList.add(new AppealTypeInfo(id,type));
		}
		 loadData();
	}
	private void initView() {
		tv_company_name = (TextView) findViewById(R.id.tv_company_name);
		tv_appeal_name = (TextView) findViewById(R.id.tv_appeal_name);
		tv_appeal_phone = (TextView) findViewById(R.id.tv_appeal_phone);
		tv_appeal_place = (TextView) findViewById(R.id.tv_appeal_place);
		et_appeal_title = (EditText) findViewById(R.id.et_appeal_title);
		et_appeal_content = (EditText) findViewById(R.id.et_appeal_content);
		cb_no = (RadioButton) findViewById(R.id.cb_no);
		cb_yes = (RadioButton) findViewById(R.id.cb_yes);
		saveBtn = (Button) findViewById(R.id.appeal_save_btn);
		commitBtn = (Button) findViewById(R.id.appeal_commit_btn);
		spinner_type = (Spinner) findViewById(R.id.spinner_type);
	}
	private void loadData() {
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item,types);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_type.setAdapter(arrayAdapter);
        spinner_type.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				appealType = typeList.get(position).getId();
				
			}
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
		});
        saveBtn.setOnClickListener(this);
        commitBtn.setOnClickListener(this);
        cb_no.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){ 
            @Override 
            public void onCheckedChanged(CompoundButton buttonView, 
                    boolean isChecked) { 
                // TODO Auto-generated method stub 
                if(isChecked){ 
                	status = 0;
                }
            } 
        });
        
        cb_yes.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){ 
            @Override 
            public void onCheckedChanged(CompoundButton buttonView, 
                    boolean isChecked) { 
                // TODO Auto-generated method stub 
                if(isChecked){ 
                	status = 1;
                }else{
                	status = 0;
                }
            } 
        });
    }

    @Override
    public void onClick(View view) {
    	String title = et_appeal_title.getText().toString().trim();
		String content = et_appeal_content.getText().toString().trim();
        int viewId = view.getId();
        switch (viewId) {
            case R.id.system_back:
//            	startActivity(new Intent(MyAppealActivity.this,MainActivity.class));
            	finish();
                break;
            case R.id.appeal_commit_btn:
            	if (BeanUtils.isEmpty(title)||BeanUtils.isEmpty(content)) {
            		Toast.makeText(MyAppealActivity.this, "亲！诉求标题或内容不能为空哦", Toast.LENGTH_SHORT).show();
            		return;
				}
				sendData(COMMIT, title, content, appealType,String.valueOf(status));
				Toast.makeText(MyAppealActivity.this, "提交成功", Toast.LENGTH_SHORT).show();
            	startActivity(new Intent(MyAppealActivity.this,MainActivity.class));
            	finish();
                break;
            case R.id.appeal_save_btn:
            	if (BeanUtils.isEmpty(title)||BeanUtils.isEmpty(content)) {
            		Toast.makeText(MyAppealActivity.this, "亲！诉求标题或内容不能为空哦", Toast.LENGTH_SHORT).show();
            		return;
				}
				sendData(SAVE, title, content, appealType,String.valueOf(status));
				Toast.makeText(MyAppealActivity.this, "保存成功", Toast.LENGTH_SHORT).show();
            	startActivity(new Intent(MyAppealActivity.this,MainActivity.class));
            	finish();
                break;
            default:
                break;
        }
    }
    
    @Override
	public void onBackPressed() {
//		startActivity(new Intent(MyAppealActivity.this,MainActivity.class));
		finish();
		super.onBackPressed();
	}
}
