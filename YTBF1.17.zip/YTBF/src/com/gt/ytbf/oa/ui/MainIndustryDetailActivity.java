package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.MainIndustryInfo;
import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.adapter.MainIndustryDetailAdapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainIndustryDetailActivity extends BaseActivity{
	
	public static final String[] ITTILES = new String[] { "主营业务", "工业增加值", "利润总额" };
	private LayoutInflater layoutInflater;
	private LinearLayout layout;
	private InvokeHelper invoke;
	private List<PagerModel> mListDatas = new ArrayList<CommenViewPagerHelper.PagerModel>();
	private CommenViewPagerHelper helper;
	private View mainBusView,addIndustryView, profitView;
	private ListView lv_target1,lv_target2,lv_target3;
	private List<MainIndustryInfo> mList = new ArrayList<MainIndustryInfo>();
	private MainIndustryDetailAdapter mAdapterOne,mAdapterTwo,mAdapterThree;
	private String zbmc;
	private List<MainIndustryInfo> mData = new ArrayList<MainIndustryInfo>();
	public static final int PAGETYPEONE = 1, PAGETYPETWO = 2,PAGETYPETHREE = 3;
	private TextView time1,time2,time3;
	private String time;
	
	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
			
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_common_tabpageindicator);
		initTitleBar(R.string.industry_target_title, backListener, null);
		zbmc = getIntent().getStringExtra("ZBMC");
		invoke = new InvokeHelper(this);
		loadData();
		initView();
		initViewPagers(savedInstanceState);
	}
	
	private void initViewPagers(Bundle savedInstanceState) {
		helper = new CommenViewPagerHelper(MainIndustryDetailActivity.this, layout);
		helper.onCreate(savedInstanceState);
		List<View> views = new ArrayList<View>();
		mainBusView = layoutInflater.inflate(R.layout.activity_main_industry_detail, null);
		views.add(mainBusView);
		addIndustryView = layoutInflater.inflate(R.layout.activity_main_industry_detail, null);
		views.add(addIndustryView);
		profitView = layoutInflater.inflate(R.layout.activity_main_industry_detail, null);
		views.add(profitView);
		
		for (int i = 0; i < ITTILES.length; i++) {
			mListDatas.add(helper.new PagerModel(ITTILES[i], views.get(i), null));
		}
        helper.showViews(mListDatas);
        loadView();
	}
	
	private void loadView() {
		lv_target1 = (ListView)mainBusView.findViewById(R.id.lv_target);
		time1 = (TextView) mainBusView.findViewById(R.id.time);
		lv_target2 = (ListView)addIndustryView.findViewById(R.id.lv_target);
		time2 = (TextView) addIndustryView.findViewById(R.id.time);
		lv_target3 = (ListView)profitView.findViewById(R.id.lv_target);
		time3 = (TextView) profitView.findViewById(R.id.time);
	}
	
	private void initView() {
		layoutInflater = getLayoutInflater();
		layout = (LinearLayout) findViewById(R.id.viewpage);
	}
	
	private void loadData() {
		invoke.invoke(OAInterface.getQueryStatistics("6", "", ""), callBack);
	}
	
	private  IRequestCallBack callBack = new BaseRequestCallBack(){
		
		@Override
		public void process(HttpResponse response, int what) {
			if(!BeanUtils.isEmpty(response)){
				ResultItem item = response.getResultItem(ResultItem.class);
				if(checkResult(item)){
					if(Constants.SUCCESS_CODE.equals(item.get("code"))){
						List<ResultItem> items = item.getItems("DATA");
						for (ResultItem resultItem : items) {
							MainIndustryInfo info = new MainIndustryInfo();
							time = resultItem.getString("YF");
							//主营
							info.setFl(resultItem.getString("FL"));
							info.setZbmc(resultItem.getString("ZBMC"));
							info.setQygs(resultItem.getString("QYGS"));
							info.setZbylj(resultItem.getString("ZYYWSR_BYLJ"));
							info.setZqntq(resultItem.getString("ZYYWSR_QNTQ"));
							info.setZtb(resultItem.getString("ZYYWSR_TB"));
							//工业
							info.setGbylj(resultItem.getString("GYZCZ_BYLJ"));
							info.setGqntq(resultItem.getString("GYZCZ_QNTQ"));
							info.setGtb(resultItem.getString("GYZCZ_TB"));
							//利税
							info.setLbylj(resultItem.getString("LRZE_BYLJ"));
							info.setLqntq(resultItem.getString("LRZE_QNTQ"));
							info.setLtb(resultItem.getString("LRZE_TB"));
							char[] array = time.toCharArray();
							if(array[0]=='0'){
								time1.setText("区间:1-"+array[1]+"月");
								time2.setText("区间:1-"+array[1]+"月");
								time3.setText("区间:1-"+array[1]+"月");
							}else{
								time1.setText("区间:1-"+time+"月");
								time2.setText("区间:1-"+time+"月");
								time3.setText("区间:1-"+time+"月");
							}
							mList.add(info);
							
						}
						
						if(!BeanUtils.isEmpty(zbmc)){
							for (int i = 0; i < mList.size(); i++) {
								if(zbmc.equals(mList.get(i).getZbmc())){
									mData.add(mList.get(i));
								}
							}
							
							if(mAdapterOne==null){
								mAdapterOne = new MainIndustryDetailAdapter(MainIndustryDetailActivity.this, mData,PAGETYPEONE);
								lv_target1.setAdapter(mAdapterOne);
							}else{
								mAdapterOne.notifyDataSetChanged();
							}
							if(mAdapterTwo==null){
								mAdapterTwo = new MainIndustryDetailAdapter(MainIndustryDetailActivity.this, mData,PAGETYPETWO);
								lv_target2.setAdapter(mAdapterTwo);
							}else{
								mAdapterTwo.notifyDataSetChanged();
							}
							if(mAdapterThree==null){
								mAdapterThree = new MainIndustryDetailAdapter(MainIndustryDetailActivity.this, mData,PAGETYPETHREE);
								lv_target3.setAdapter(mAdapterThree);
							}else{
								mAdapterThree.notifyDataSetChanged();
							}
						}
					}
				}
			}
		}
     };
	
}
