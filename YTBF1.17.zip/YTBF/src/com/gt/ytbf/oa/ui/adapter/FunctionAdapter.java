package com.gt.ytbf.oa.ui.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.ui.*;

public class FunctionAdapter extends BaseAdapter {

	private Context mContext;
	private ArrayList<Infor> infos = new ArrayList<Infor>();
	
	public FunctionAdapter(Context context) {
		this.mContext = context;
		initData();
	}
	
	@Override
	public int getCount() {
		return infos.size();
	}

	@Override
	public Object getItem(int position) {
		return infos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		Infor info = infos.get(position);
		ViewHolder holder = null;
		if (null == convertView) {
			holder = new ViewHolder();
			convertView = LayoutInflater.from(mContext).inflate(R.layout.main_funtion_grid_item, null);
			holder.img = (ImageView) convertView.findViewById(R.id.grid_item_img);
			holder.txt = (TextView) convertView.findViewById(R.id.grid_item_txt);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.img.setImageResource(info.imgRes);
		holder.txt.setText(info.txtRes);
		return convertView;
	}
	
	private void initData() {
		int[] mImags = new int[]{R.drawable.icon_qyxx, R.drawable.icon_qyxx, R.drawable.icon_qyxx,
				R.drawable.qyyj_selector, R.drawable.icon_jjyx, R.drawable.icon_qyxx,
				R.drawable.gygk_selector, R.drawable.zdcy_selector};
		int[] mTxts = new int[]{R.string.function_info, R.string.function_appeal_center,
				R.string.function_document, R.string.function_enterprise_warning, R.string.function_economical_operation,
				R.string.function_news, R.string.function_industry, R.string.function_leading_industry};
		Class[] clss = new Class[]{CompanyInfoActivity.class, AppealCenterActivity.class, OfficeDocumentActivity.class, EnterpriseWarningActivity.class,
                EconomicalActivity.class, PolicyNewsActivity.class, IndustryActivity.class, LeadingIndustryActivity.class};
		for (int i = 0; i < mImags.length; i++) {
			infos.add(new Infor(mImags[i], mTxts[i], clss[i]));
		}
	}
	
	class ViewHolder {
		public ImageView img;
		public TextView txt;
	}
	
	public class Infor {
		public int imgRes;
		public int txtRes;
		public Class cls;
		
		public Infor(int img, int txt, Class cls) {
			this.imgRes = img;
			this.txtRes = txt;
			this.cls = cls;
		}
	}

}
