package com.gt.ytbf.oa.ui;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.CompanyInfo;
import com.gt.ytbf.oa.bean.NewsInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.model.UserInfo;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.ui.adapter.CompanyInfoAdapter;

import java.util.ArrayList;
import java.util.List;

public class CompanyInfoActivity extends BaseActivity {

	private View.OnClickListener backListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
//			startActivity(new Intent(CompanyInfoActivity.this,MainActivity.class));
			finish();
		}
	};
	private static CompanyInfoActivity mContext;
	private ListView company_info_lv;
	private List<CompanyInfo> companyInfos;
	private InvokeHelper invoke;
	private EditText search_et;
	private String searchText;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_company_info);
		initTitleBar(R.string.function_info, backListener, null);
		initView();
		initData();
		mContext = this;
	}

	private IRequestCallBack callBack = new BaseRequestCallBack() {

		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			// Log.i("test", item.toString());
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					List<ResultItem> resultItems = item.getItems("data");
					showCompanyList(resultItems);
				}
			}
		}
	};

	private void initData() {
		invoke = new InvokeHelper(this);
		invoke.invokeWidthDialog(OAInterface.getCompanyLst(""), callBack);
	}

	protected void showCompanyList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			refreshUI();
			return;
		}
		companyInfos = new ArrayList<CompanyInfo>(resultItems.size());
		for (ResultItem item : resultItems) {
			String companyName = item.getString("COMPANY_NAME");
			String companyAddr = item.getString("COMPANY_ADDR");
			String contactPhone = item.getString("CONTACT_PHONE");
			String org_code = item.getString("ORG_CODE");
			companyInfos.add(new CompanyInfo(R.drawable.news_list_01,
					companyName, companyAddr, contactPhone, org_code));
		}
		refreshUI();
	}

	private void refreshUI() {
		search_et.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_ENTER) {
					searchText = search_et.getText().toString().trim();
					companyInfos.clear();
					invoke.invokeWidthDialog(OAInterface.getCompanyLst(searchText), callBack);
					return true;
				}
				return false;
			}
		});
		company_info_lv.setAdapter(new CompanyInfoAdapter(
				CompanyInfoActivity.this, companyInfos,searchText));
		company_info_lv
				.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view,
							int position, long id) {
						if (companyInfos.size()<=position) {
							return;
						}
						Intent intent = new Intent(CompanyInfoActivity.this,
								CompanyInfoDetailActivity.class);
						intent.putExtra("OrgCode", companyInfos.get(position)
								.getOrgCode());
						startActivity(intent);
					}
				});
	}

	/*
	 * private void loadData() { companyInfos = new ArrayList<CompanyInfo>(); if
	 * ("1".equals(userLevel)) { companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, companyName,
	 * companyAddr,contactPhone)); }else {
	 * 
	 * companyInfos.add(new CompanyInfo(R.drawable.news_list_01, "江西三川铜业有限公司",
	 * "江西鹰潭市月湖区鹰潭市工业区金桥路中段", "17870000040")); companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, "江西中晟金属有限公司",
	 * "江西省鹰潭市铜产业循环经济基地精深加工区", "13607019386")); companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, "余江天余生态农业科技股份有限公司",
	 * "江西省鹰潭市余江县311高速挂线", "13307015326")); companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, "江西康洁能源有限公司",
	 * "江西省鹰潭市余江县余江（国际）眼镜工业园", "18220502789")); companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, "江西康成铜业有限公司", "江西省鹰潭市三川大道6号",
	 * "888888")); companyInfos.add(new CompanyInfo(R.drawable.news_list_01,
	 * "江西新华米业有限公司", "xxxxxx", "888888")); companyInfos.add(new
	 * CompanyInfo(R.drawable.news_list_01, "江西三川铜业有限公司", "xxxxxx", "888888"));
	 * companyInfos.add(new CompanyInfo(R.drawable.news_list_01, "江西三川铜业有限公司",
	 * "xxxxxx", "888888")); }
	 * 
	 * }
	 */
	private void initView() {
		search_et = (EditText) findViewById(R.id.common_search_content_edt);
		company_info_lv = (ListView) findViewById(R.id.company_info_lv);
	}
	
	@Override
	public void onBackPressed() {
//		startActivity(new Intent(CompanyInfoActivity.this,MainActivity.class));
		finish();
		super.onBackPressed();
	}
	
	public static void finishMySelf() {
		mContext.finish();
	}
}
