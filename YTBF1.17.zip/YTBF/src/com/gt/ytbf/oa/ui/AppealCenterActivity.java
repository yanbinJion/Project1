package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.R.integer;
import com.gt.ytbf.oa.api.OAInterface;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.base.BaseRequestCallBack;
import com.gt.ytbf.oa.base.IRequestCallBack;
import com.gt.ytbf.oa.base.InvokeHelper;
import com.gt.ytbf.oa.bean.AppealDetailInfo;
import com.gt.ytbf.oa.common.ResultItem;
import com.gt.ytbf.oa.model.AppealCenterModel;
import com.gt.ytbf.oa.network.http.HttpResponse;
import com.gt.ytbf.oa.tools.BeanUtils;
import com.gt.ytbf.oa.tools.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.ui.adapter.AppealDetailAdapter;
import com.gt.ytbf.oa.ui.view.NoScrollListView;

public class AppealCenterActivity extends BaseActivity{

	private static int FIRST_PAGE=1;
	public static final int PROCESS_APPEAL = 1;
	private HashMap<String, String> types = new HashMap<String, String>();
	private AppealCenterModel appealInfo;
	private List<AppealDetailInfo> historyList;
	private TextView tv_name;
	private TextView tv_contact;
	private TextView tv_phone;
	private TextView tv_area;
	private TextView tv_appeal_type;
	private TextView tv_appeal_time;
	private TextView tv_appeal_title;
	private TextView tv_appeal_content;
	private TextView tv_appeal_state;
	private NoScrollListView lv_appeal_detail;
	private TextView tv_appeal_evaluate;
	private RatingBar rb_rating;
	
	private Button processBtn;
	
	private static AppealCenterActivity mContext;
	private boolean isHandler;
	private int appealType;
	private View.OnClickListener backListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_appeal_centerr);
		initTitleBar(R.string.function_appeal_center, backListener, null);
		initData();
		mContext = this;
	}

	private IRequestCallBack companyCallBack = new BaseRequestCallBack() {
		
		@Override
		public void process(HttpResponse response, int what) {
			ResultItem item = response.getResultItem(ResultItem.class);
			if (checkResult(item)) {
				if (Constants.SUCCESS_CODE.equals(item.getString("code"))) {
					List<ResultItem> resultItems=item.getItems("historyData");
					showHistoryList(resultItems);
					
					ResultItem companyData=item.getItems("companyData").get(0);
					String companyName = companyData.getString("COMPANY_NAME");
					String contact = companyData.getString("CONTACT");
					String contactPhone = companyData.getString("CONTACT_PHONE");
					String area_name = companyData.getString("AREAS");
					tv_name.setText(companyName);
					tv_contact.setText(contact);
					tv_phone.setText(contactPhone);
					tv_area.setText(area_name);
					
					ResultItem appealData=(ResultItem) item.get("appealData");
					tv_appeal_evaluate.setVisibility(View.VISIBLE);
					if (null != appealData) {
						String star=appealData.getString("STAR");
						if (!BeanUtils.isEmpty(star)) {
							tv_appeal_evaluate.setVisibility(View.GONE);
							rb_rating.setVisibility(View.VISIBLE);
							rb_rating.setRating(Integer.valueOf(star));
						}
					}
				}
			}
		}
		
	};
	
	
	private void initData() {
		types.put("1", "提交");
		types.put("2", "派单");
		types.put("3", "下发");
		types.put("4", "终止");
		types.put("5", "上报");
		types.put("6", "受理");
		types.put("7", "记录");
		types.put("8", "办结");
		types.put("9", "回退");
		types.put("10", "评价");
		appealInfo = (AppealCenterModel) getIntent().getSerializableExtra("appealInfo");
		isHandler = getIntent().getBooleanExtra("isHandler", false);
	    appealType = getIntent().getIntExtra("type", 0);
		initView();
		loadData();
	}

	@Override
	protected void onResume() {
		super.onResume();
		InvokeHelper invoke = new InvokeHelper(this);
		invoke.invokeWidthDialog(OAInterface.getAppealDetail(appealInfo.getBizId()), companyCallBack);
	}
	
	protected void showHistoryList(List<ResultItem> resultItems) {
		if (BeanUtils.isEmpty(resultItems)) {
			return;
		}
		historyList = new ArrayList<AppealDetailInfo>(resultItems.size());
		 for (ResultItem item : resultItems) {
			String content = item.getString("CONTENT");
			String time = item.getString("DATETIME");
			String next = item.getString("NEXT");
			String type = item.getString("TYPE");
			String advice = item.getString("ADVICE");
			String id = item.getString("ID");
			String leadContent = item.getString("LEADCONTENT");
			historyList.add(new AppealDetailInfo(id, time,content, next, types.get(type),advice, type,leadContent));
		}
		 loadHistoryData();
	}

	private void loadHistoryData() {
//		lv_appeal_detail.setFocusable(false);
		lv_appeal_detail.setAdapter(new AppealDetailAdapter(this, historyList));
		if ("5".equals(LoginUtils.getInstance().getUserInfo().getUserLevel()) && 2!=appealType) {
			lv_appeal_detail.setOnItemClickListener(new OnItemClickListener() {
	
				@Override
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
						long arg3) {
					AppealDetailInfo info = historyList.get(arg2);
					if ("1".equals(info.getType()) || "8".equals(info.getType()) || "10".equals(info.getType())) {
						return;
					}
					Intent intent = new Intent(AppealCenterActivity.this, ProcessActivity.class);
					intent.putExtra("processId", info.getAppealId());
					startActivityForResult(intent, PROCESS_APPEAL);
				}
				
			});
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK && PROCESS_APPEAL == requestCode) {
			boolean flag = data.getBooleanExtra("isProcess", false);
			if (flag) {
				processBtn.setVisibility(View.GONE);
			}
		}
	}

	private void loadData() {
		if(2==appealType){
			if("1".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("融资难");
			}else if("2".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("招工难、人才却");
			}else if("3".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("生产要素成本高");
			}else if("4".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("市场销售不畅");
			}else if("5".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("创新发展不足");
			}else if("6".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("企业税费压力大");
			}else if("7".equals(appealInfo.getAppealType())){
				tv_appeal_type.setText("小微企业创新创业难");
			}else{
				tv_appeal_type.setText("其他");
			}
		}else{
			tv_appeal_type.setText(appealInfo.getAppealType());
		}
		tv_appeal_time.setText(appealInfo.getAppealTime());
		tv_appeal_title.setText(appealInfo.getTitle());
//		Toast.makeText(this, appealInfo.getTitle()+appealInfo.getAppealContent(), Toast.LENGTH_SHORT).show();
		tv_appeal_content.setText(appealInfo.getAppealContent());
		tv_appeal_state.setText(appealInfo.getStatusType());

	}

	private void initView() {
		ScrollView scrollview = (ScrollView) findViewById(R.id.scrollview);
		scrollview.smoothScrollTo(0, 0);
		tv_name = (TextView) findViewById(R.id.tv_name);
		tv_contact = (TextView) findViewById(R.id.tv_contact);
		tv_phone = (TextView) findViewById(R.id.tv_phone);
		tv_area = (TextView) findViewById(R.id.tv_area);
		tv_appeal_type = (TextView) findViewById(R.id.tv_appeal_type);
		tv_appeal_time = (TextView) findViewById(R.id.tv_appeal_time);
		tv_appeal_title = (TextView) findViewById(R.id.tv_appeal_title);
		tv_appeal_content = (TextView) findViewById(R.id.tv_appeal_content);
		tv_appeal_state = (TextView) findViewById(R.id.tv_appeal_state);
		lv_appeal_detail = (NoScrollListView) findViewById(R.id.lv_appeal_detail);
		tv_appeal_evaluate = (TextView) findViewById(R.id.tv_appeal_evaluate);
		rb_rating = (RatingBar) findViewById(R.id.rb_rating);
		processBtn = (Button) findViewById(R.id.appeal_detail_process_btn);
		processBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(AppealCenterActivity.this,ProcessActivity.class);
				intent.putExtra("appealId", appealInfo.getAppealId());
				intent.putExtra("status", appealInfo.getAppealState());
				intent.putExtra("timeLimit", appealInfo.getTimeLimit());
				intent.putExtra("tzt", appealInfo.getTzt());
				startActivityForResult(intent, PROCESS_APPEAL);			
			}
			
		});
		if (!isHandler || "4".equals(LoginUtils.getInstance().getUserInfo().getDepLevel())) {
			processBtn.setVisibility(View.GONE);
		}
	}
	
	public static void finishMySelf() {
		mContext.finish();
	}
}
