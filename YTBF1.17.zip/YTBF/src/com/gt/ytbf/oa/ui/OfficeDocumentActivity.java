package com.gt.ytbf.oa.ui;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.base.BaseActivity;
import com.gt.ytbf.oa.bean.OfficeInfo;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper;
import com.gt.ytbf.oa.ui.adapter.OfficeAdapter;
import com.gt.ytbf.oa.ui.adapter.CommenViewPagerHelper.PagerModel;
import com.gt.ytbf.oa.ui.view.PullToRefreshListView;
import com.gt.ytbf.oa.ui.view.pull.PullToRefreshBase;

public class OfficeDocumentActivity extends BaseActivity {



    private View.OnClickListener backListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
        }
    };

    private View.OnClickListener homeListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(OfficeDocumentActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    };
    
    private List<PagerModel> paList=new ArrayList<PagerModel>();
	private List<View> views;
	private String[] arrs;
	private CommenViewPagerHelper pagerHeplper;
	private List<OfficeInfo> mOfficeCategories;

	private LayoutInflater linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_tabpageindicator);
        initTitleBar(R.string.function_document,backListener,homeListener);
        initData();
        
        linearLayout = getLayoutInflater();
        LinearLayout layout = (LinearLayout) findViewById(R.id.viewpage);
        pagerHeplper = new CommenViewPagerHelper(this, layout);
        arrs = new String[] {"国家", "江西省", "鹰潭市"};
        pagerHeplper.onCreate(savedInstanceState);
        initViews();
        
//        views = new ArrayList<View>();
//        views.add(linearLayout.inflate(R.layout.view_pager_layout, null));
//        views.add(linearLayout.inflate(R.layout.view_pager_layout, null));
//        views.add(linearLayout.inflate(R.layout.view_pager_layout, null));
        initViewPagers();
        pagerHeplper.showViews(paList);
    }


    private void initViews() {
    	views = new ArrayList<View>();
		for (int i = 0; i < arrs.length; i++) {
			View mRootView = linearLayout.inflate(R.layout.view_pager_layout, null);
			final PullToRefreshListView vp_pulltorefreshlv = (PullToRefreshListView) mRootView.findViewById(R.id.vp_pulltorefreshlv);
			vp_pulltorefreshlv.setPullRefreshEnabled(true);
			vp_pulltorefreshlv.setPullLoadEnabled(true);
	        ListView vp_list = vp_pulltorefreshlv.getRefreshableView();
	        vp_list.setCacheColorHint(Color.TRANSPARENT);
	        vp_list.setFadingEdgeLength(0);
	        vp_list.setSelector(android.R.color.transparent);
	        vp_list.setAdapter(new OfficeAdapter(this, mOfficeCategories));

	        vp_pulltorefreshlv.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
	            // 下拉加载数据
	            @Override
	            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
	                Toast.makeText(OfficeDocumentActivity.this, "刷新成功", Toast.LENGTH_SHORT).show();
	                vp_pulltorefreshlv.onPullDownRefreshComplete();
	            }

	            // 上拉加载下一页的数据
	            @Override
	            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
	                Toast.makeText(OfficeDocumentActivity.this, "没有更多数据了", Toast.LENGTH_SHORT).show();
	                vp_pulltorefreshlv.onPullUpRefreshComplete();
	            }
	        });
			views.add(mRootView);
		}
		
	}


	private void initData() {
    	OfficeInfo officeCategory1 = new OfficeInfo(R.drawable.office_icon_country, "区域经济的迅速发展历程", "2016-01-01");
        OfficeInfo officeCategory2 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory3 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory4 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory5 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory6 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory7 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-01-01");
        OfficeInfo officeCategory8 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory9 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory10 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        OfficeInfo officeCategory11 = new OfficeInfo(R.drawable.office_icon_country, "用新发展理念指导转型升级", "2016-04-20");
        mOfficeCategories = new ArrayList<OfficeInfo>();
        mOfficeCategories.add(officeCategory1);
        mOfficeCategories.add(officeCategory2);
        mOfficeCategories.add(officeCategory3);
        mOfficeCategories.add(officeCategory4);
        mOfficeCategories.add(officeCategory5);
        mOfficeCategories.add(officeCategory6);
        mOfficeCategories.add(officeCategory7);
        mOfficeCategories.add(officeCategory8);
        mOfficeCategories.add(officeCategory9);
        mOfficeCategories.add(officeCategory10);
        mOfficeCategories.add(officeCategory11);
	}


	private void initViewPagers() {
//        if (mViewsPagers ==null){
//            //添加三个ViewPager
//            mViewsPagers = new ArrayList<CommonViewPager>(3);
//                CommonViewPager viewPager1 = new CommonViewPager(this,null,null,0);
//                CommonViewPager viewPager2 = new CommonViewPager(this,null,null,0);
//                CommonViewPager viewPager3 = new CommonViewPager(this,null,null,0);
//
//                mViewsPagers.add(viewPager1);
//                mViewsPagers.add(viewPager2);
//                mViewsPagers.add(viewPager3);
//            }
//            InPagerAdapter.notifyDataSetChanged();
//            mTabPageIndicator.notifyDataSetChanged();
		
    	for (int i = 0; i < arrs.length; i++) {
    		View view = views.get(i);
    		String arr = arrs[i];
    		PagerModel model =  pagerHeplper.new PagerModel(arr, view, null);
    		paList.add(model);
			
		}
    	
    }

    /*class OfPagerAdapter extends PagerAdapter{
        @Override
        public CharSequence getPageTitle(int position) {
//            Toast.makeText(OfficeDocumentActivity.this, ITTILES[position], Toast.LENGTH_SHORT).show();
            return ITTILES[position];
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            CommonViewPager viewsPager = mViewsPagers.get(position);
            View view=viewsPager.getView();
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);

        }

        @Override
        public int getCount() {
            return ITTILES.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view==object;
        }
    };
*/
}
