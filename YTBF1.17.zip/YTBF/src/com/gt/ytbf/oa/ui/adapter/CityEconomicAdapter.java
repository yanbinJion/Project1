package com.gt.ytbf.oa.ui.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gt.ytbf.oa.R;
import com.gt.ytbf.oa.bean.CityEconomicTargetInfo;

public class CityEconomicAdapter extends BaseAdapter {

	private Context mContext;
	private List<CityEconomicTargetInfo> mData;
	private int type;
	public  CityEconomicAdapter(Context context,List<CityEconomicTargetInfo> mData, int type) {
		this.mContext = context;
		this.mData = mData;
		this.type = type;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mData.size()==0?null:mData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder hodler = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(mContext).inflate(R.layout.city_economic_item,null);
			hodler = new ViewHolder();
			hodler.tv_table1 = (TextView) convertView.findViewById(R.id.tv_table1);
			hodler.tv_table2 = (TextView) convertView.findViewById(R.id.tv_table2);
			hodler.tv_table01 = (TextView) convertView.findViewById(R.id.tv_table01);
			hodler.tv_table02 = (TextView) convertView.findViewById(R.id.tv_table02);
			hodler.tv_table03 = (TextView) convertView.findViewById(R.id.tv_table03);			
			convertView.setTag(hodler);
		} else {
			hodler = (ViewHolder) convertView.getTag();
		}
		if(1==type){
	    	 hodler.tv_table1.setText(mData.get(position).getCity());
	    	 hodler.tv_table2.setText(mData.get(position).getCompanyTotal());
			 hodler.tv_table01.setText(mData.get(position).getMonthData());
			 hodler.tv_table02.setText(mData.get(position).getAddPercent());
			 hodler.tv_table03.setText(mData.get(position).getCompletePlan());
	     }else if(2==type){
	    	 hodler.tv_table1.setText(mData.get(position).getCity());
	    	 hodler.tv_table2.setText(mData.get(position).getCompanyTotal());
			 hodler.tv_table01.setText(mData.get(position).getzMonthData());
			 hodler.tv_table02.setText(mData.get(position).getzAddPercent());
			 hodler.tv_table03.setText(mData.get(position).getzCompletePlan());
	     }else if (3==type) {
	    	 hodler.tv_table1.setText(mData.get(position).getCity());
	    	 hodler.tv_table2.setText(mData.get(position).getCompanyTotal());
			 hodler.tv_table01.setText(mData.get(position).getlMonthData());
			 hodler.tv_table02.setText(mData.get(position).getlAddPercent());
			convertView.findViewById(R.id.tv_table03).setVisibility(View.GONE);;
		}
		return convertView;
	}

	final class ViewHolder {
		TextView tv_table1, tv_table2, tv_table01, tv_table02, tv_table03;
	}
}
