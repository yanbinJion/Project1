package com.gt.ytbf.oa.api;

public interface OnSelectedChangeListener {

	public void onSelectedChange(boolean isLeftSelected);
}
