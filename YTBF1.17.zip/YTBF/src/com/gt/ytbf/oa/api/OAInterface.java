package com.gt.ytbf.oa.api;

import java.util.Calendar;

import com.gt.ytbf.oa.common.Constants;
import com.gt.ytbf.oa.tools.LoginUtils;
import com.gt.ytbf.oa.tools.StringUtils;

public class OAInterface {

	public static ApiRequest logon(String userId, String pwd) {
		ApiRequest request = new ApiRequest("logon");
		request.addParam("user_code", userId);
		request.addParam("password", pwd);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL);
		return request;
	}
	
	/** 主导产业详情*/
	public static ApiRequest getNew(String type){
		ApiRequest request = new ApiRequest("getcy");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("type", type);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/** 企业预警*/
	public static ApiRequest getWaringInfo(String compname, String year ,String month, String iPageIndex){
		ApiRequest request = new ApiRequest("getwarninfo");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("compname", compname);
		request.addParam("Year", year);
		request.addParam("Month", month);
		request.addParam("iPageIndex", iPageIndex);
		request.addParam("iPageSize", String.valueOf(Constants.COMMON_PAGE_SIZE));
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/** 工业概况列表**/
	public static  ApiRequest getNewsList(String flag, String iPageIndex){
		ApiRequest request = new ApiRequest("getnewslist");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("flag", flag);
		request.addParam("iPageIndex", iPageIndex);
		request.addParam("iPageSize", String.valueOf(Constants.COMMON_PAGE_SIZE));
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/** 工业概况列表**/
	public static ApiRequest getNewDetails(String id){
		ApiRequest request = new ApiRequest("getnew");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("id", id);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/**
	 * 修改密码
	 * */
	public static ApiRequest modifyPass(String oldPassword,String newPassword) {
		ApiRequest request = new ApiRequest("modifypass");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("oldPassword", oldPassword);
		request.addParam("newPassword", newPassword);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL);
		return request;
	}
	
	/**
	 * 企业信息
	 * */
	public static ApiRequest getCompanyInfo(String orgCode) {
		ApiRequest request = new ApiRequest("getCompanyInfo");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("org_code", orgCode);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 诉求类别列表
	 * */
	public static ApiRequest getAppealTypes() {
		ApiRequest request = new ApiRequest("getAppealTypes");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 提交或保存诉求
	 * */
	public static ApiRequest saveOrSubmitAppeal(String status,String title,String content,String appealType,String issecret) {
		ApiRequest request = new ApiRequest("saveOrSubmitAppeal");
		request.addParam("token",LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("status", status);
		request.addParam("title", title);
		request.addParam("content", content);
		request.addParam("appealType", appealType);
		request.addParam("issecret", issecret);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	/**
	 * 诉求列表
	 * */
	public static ApiRequest getAppeals(String status,int iPage) {
		ApiRequest request = new ApiRequest("getAppeals");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("status", status);
		request.addParam("iPage", iPage);
		request.addParam("pageSize", Constants.COMMON_PAGE_SIZE);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 部门列表
	 * */
	public static ApiRequest getDepts(String bizId) {
		ApiRequest request = new ApiRequest("getDepts");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("bizId", bizId);
		request.addParam("deptName", "");
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 诉求历史信息列表
	 * */
	public static ApiRequest getAppealHistory(String bizId) {
		ApiRequest request = new ApiRequest("getAppealHistory");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("bizId", bizId);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 诉求处理
	 * **/
	public static ApiRequest handleAppeal(String status, String id, String option, 
			String xj, String deptIds, String depts, String timelimit) {
		ApiRequest request = new ApiRequest("handleAppeal");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("status", status);
		request.addParam("appealId", id);
		request.addParam("opinion", option);
		request.addParam("Pjjb", xj);
		request.addParam("deptIds", deptIds);
		request.addParam("depts", depts);
		request.addParam("timelimit", timelimit);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 新增批示
	 * */
	public static ApiRequest insertOrUpdateLeaderNotes(String id, String content) {
		ApiRequest request = new ApiRequest("insertOrUpdateLeaderNotes");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("hisId", id);
		request.addParam("notes", content);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	 * 诉求详情
	 * */
	public static ApiRequest getAppealDetail(String bizId) {
		ApiRequest request = new ApiRequest("getAppealInfo");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
//		request.addParam("org_code", LoginUtils.getInstance().getUserInfo().getOrgCode());
		request.addParam("bizId", bizId);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/**
	*版本更新
	*/
	public static ApiRequest getVersion(String status) {
		ApiRequest request = new ApiRequest("getVersion");
		request.addParam("Status", status);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL);
		return request;
	}
	/**
	 *我要诉求
	 */
	public static ApiRequest myAppeal() {
		ApiRequest request = new ApiRequest("myAppeal");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	/**
	 *获取企业信息列表
	 */
	public static ApiRequest getCompanyLst(String companyName) {
		ApiRequest request = new ApiRequest("getCompanyLst");
		request.addParam("token", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("companyName", companyName);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/** 
	 * 新闻列表
	 **/
	public static  ApiRequest getNewsList(String authToken, String flag,String iPageIndex , String iPageSize){
		ApiRequest request = new ApiRequest("getnewslist");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("flag", flag);
		request.addParam("iPageIndex", iPageIndex);
		request.addParam("iPageSize",iPageSize );
		request.setUrl("http://218.17.204.4:8889/platform/services/appQuery");
		return request;
	}
	
	/** 
	 * 公文详情
	 **/
	public static ApiRequest getNew(String authToken, String id){
		ApiRequest request = new ApiRequest("getnew");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("id", id);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/** 
	 * 修改企业信息
	 **/
	public static ApiRequest updateCompanyInfo(String org_code,String register_date,String register_money,
			String all_money,String bank_credit_rating,String employees_num,String company_addr,
			String contact_phone,String manager_phone,String company_profile,String owenership_type){
		ApiRequest request = new ApiRequest("updateCompanyInfo");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("org_code", org_code);
		request.addParam("register_date", register_date);
		request.addParam("register_money", register_money);
		request.addParam("all_money", all_money);
		request.addParam("bank_credit_rating", bank_credit_rating);
		request.addParam("employees_num", employees_num);
		request.addParam("company_addr", company_addr);
		request.addParam("contact_phone", contact_phone);
		request.addParam("manager_phone", manager_phone);
		request.addParam("company_profile", company_profile);
		request.addParam("owenership_type", owenership_type);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}

	/** 
	 * 经济指标
	 **/
	public static ApiRequest getTarget(String xtype, String ytype,String startyear,String startmonth,String endyear,String endmonth){
		ApiRequest request = new ApiRequest("getjjzb");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("xtype", xtype);
		request.addParam("ytype", ytype);
		Calendar c = Calendar.getInstance();
		if (StringUtils.isNullOrEmpty(startyear)) {
			startyear = String.valueOf(c.get(Calendar.YEAR) - 1);
		}
		if (StringUtils.isNullOrEmpty(startmonth)) {
			startmonth = String.valueOf("1");
		}
		if (StringUtils.isNullOrEmpty(endyear)) {
			endyear = String.valueOf(c.get(Calendar.YEAR));
		}
		if (StringUtils.isNullOrEmpty(endmonth)) {
			endmonth = String.valueOf(c.get(Calendar.MONTH) + 1);
		}
		request.addParam("startyear", startyear);
		request.addParam("startmonth", startmonth);
		request.addParam("endyear", endyear);
		request.addParam("endmonth", endmonth);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}

	/** 
	 * 发展规划
	 **/
	public static ApiRequest getPlan(){
		ApiRequest request = new ApiRequest("getfzgh");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("org_code", LoginUtils.getInstance().getUserInfo().getOrgCode());
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	}
	
	/** 
	 * 科技创新
	 **/
	public static ApiRequest getTechnology(){
		ApiRequest request = new ApiRequest("getkjcx");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("org_code", LoginUtils.getInstance().getUserInfo().getOrgCode());
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_APPEAL);
		return request;
	} 
	
	/** 
	 * 获取诉求所有诉求列表
	 **/
	public static ApiRequest getAllAppeals(String status,int iPage){
		ApiRequest request = new ApiRequest("getAllAppeals");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("Status", status);
		request.addParam("iPage", iPage);
		request.addParam("iPageSize", Integer.valueOf(Constants.COMMON_PAGE_SIZE));
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/** 
	 * 获取诉求统计
	 **/
	public static ApiRequest getAppealStatistics(){
		ApiRequest request = new ApiRequest("getAppealStatistics");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
	
	/** 
	 * 查询统计
	 **/
	
	public static ApiRequest getQueryStatistics(String status,String year,String month){
		ApiRequest request = new ApiRequest("queryStatistics");
		request.addParam("authToken", LoginUtils.getInstance().getUserInfo().getAuthtoken());
		request.addParam("status", status);
		request.addParam("nf", year);
		request.addParam("yf", month);
		request.setUrl(com.gt.ytbf.oa.tools.Constants.URL_GETCOMPANYINFO);
		return request;
	}
}
