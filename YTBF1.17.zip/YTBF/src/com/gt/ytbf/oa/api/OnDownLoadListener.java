package com.gt.ytbf.oa.api;

import java.io.File;

public interface OnDownLoadListener {
	
	public void onSuccess(File file);
	
	public void onFail();
	
}
