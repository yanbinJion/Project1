package com.gt.ytbf.oa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread.UncaughtExceptionHandler;
import java.lang.reflect.Field;
import java.util.Date;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.widget.Toast;

import com.gt.ytbf.oa.tools.DateUtils;

/**
 * 类描述：<br> 
 * 异常捕获类
 */
public class MyExceptionHandler implements UncaughtExceptionHandler {

	private static final String TAG = "MyExceptionHandler";
	
	private static MyExceptionHandler mHandler;
	private static Context mContext;
	private final String file_name = "BUG_STACK.txt";
	private StringWriter sw;
	
	private MyExceptionHandler(){}
	public synchronized static MyExceptionHandler getInstance(Context context){
		if(mHandler==null){
			mHandler = new MyExceptionHandler();
			mContext = context;
		}
		return mHandler;
	}
	
	@Override
	public void uncaughtException(Thread arg0, Throwable ex) {
		try {
			sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			ex.printStackTrace(pw);
			System.out.println("错误信息" + sw.toString());
			//File dir = Environment.getDataDirectory();
			File dir = Environment.getExternalStorageDirectory();
			File file = null;
			FileOutputStream fos = null;
			if (dir != null) {
				file = new File(dir, file_name);
				fos = new FileOutputStream(file);
				fos.write(("time:"+DateUtils.formatDate(new Date(), DateUtils.DATE_TIME_FORMAT)+"\n").getBytes());
				fos.flush();
			}
			
			sw.append("\n");

			// 获取手机的版本信息
			Field[] fields = Build.class.getFields();
			for (Field field : fields) {
				field.setAccessible(true); // 暴力反射
				String key = field.getName();
				String value = field.get(null).toString();
				sw.append(key+"="+value+"\n");
			}
			
			if(dir!=null){
				fos.write(sw.toString().getBytes());
				fos.flush();
				fos.close();
			}

			new Thread(){public void run() {
				Looper.prepare();
				OADroid.getInstance().onTerminate();
				Toast.makeText(mContext, "不好了，系统病了，正在抢救中！", 3000).show();
				Looper.loop();
				System.exit(0);
			};}.start();
		
			fos.close();
			//System.out.println("程序发生了异常,但是被哥捕获了");
	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
